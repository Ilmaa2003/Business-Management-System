﻿namespace FinalProject
{
    partial class AssistantAccountant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AssistantAccountant));
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.guna2TileButton7 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton6 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.accDeadline = new Guna.UI2.WinForms.Guna2TextBox();
            this.acctask = new Guna.UI2.WinForms.Guna2DataGridView();
            this.accPriority = new Guna.UI2.WinForms.Guna2TextBox();
            this.cmbaccStatuss = new Guna.UI2.WinForms.Guna2ComboBox();
            this.accTaskNames = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel40 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel38 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel37 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel36 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.updbtnacc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel42 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.guna2DataGridView4 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2DateTimePicker2 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel18 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.Feetbackdgv = new Guna.UI2.WinForms.Guna2DataGridView();
            this.accsend = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel47 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbFeedbackType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtFeedback = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel41 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel44 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtEmpName = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtEmpId = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel27 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel24 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2CircleButton3 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton4 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlToolTip1 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip2 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip3 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip4 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip5 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip6 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlLabel48 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel46 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel52 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel49 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton5 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2HtmlLabel45 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton3 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton2 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage5.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).BeginInit();
            this.guna2TabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView4)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Feetbackdgv)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage5.Controls.Add(this.guna2HtmlLabel48);
            this.tabPage5.Controls.Add(this.guna2TextBox2);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel46);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel52);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel49);
            this.tabPage5.Controls.Add(this.guna2TextBox6);
            this.tabPage5.Controls.Add(this.guna2TextBox5);
            this.tabPage5.Controls.Add(this.guna2Button8);
            this.tabPage5.Controls.Add(this.guna2Button4);
            this.tabPage5.Controls.Add(this.guna2TileButton5);
            this.tabPage5.Controls.Add(this.guna2TileButton4);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel45);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel4);
            this.tabPage5.Controls.Add(this.guna2TextBox1);
            this.tabPage5.Controls.Add(this.guna2TextBox3);
            this.tabPage5.Controls.Add(this.guna2Button6);
            this.tabPage5.Controls.Add(this.guna2TileButton3);
            this.tabPage5.Controls.Add(this.guna2Button3);
            this.tabPage5.Controls.Add(this.guna2TileButton1);
            this.tabPage5.Controls.Add(this.guna2Button1);
            this.tabPage5.Controls.Add(this.guna2TileButton2);
            this.tabPage5.Location = new System.Drawing.Point(194, 4);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1153, 671);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Dashboard";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.guna2TileButton7);
            this.tabPage1.Controls.Add(this.guna2TileButton6);
            this.tabPage1.Location = new System.Drawing.Point(194, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1153, 671);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Employee Management";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // guna2TileButton7
            // 
            this.guna2TileButton7.BorderRadius = 30;
            this.guna2TileButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton7.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton7.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton7.Location = new System.Drawing.Point(76, 393);
            this.guna2TileButton7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton7.Name = "guna2TileButton7";
            this.guna2TileButton7.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton7.TabIndex = 20;
            this.guna2TileButton7.Text = "Employee Salary";
            this.guna2TileButton7.Click += new System.EventHandler(this.guna2TileButton7_Click);
            // 
            // guna2TileButton6
            // 
            this.guna2TileButton6.BorderRadius = 30;
            this.guna2TileButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold);
            this.guna2TileButton6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton6.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton6.Location = new System.Drawing.Point(76, 177);
            this.guna2TileButton6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton6.Name = "guna2TileButton6";
            this.guna2TileButton6.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton6.TabIndex = 19;
            this.guna2TileButton6.Text = "Employee Attendance";
            this.guna2TileButton6.Click += new System.EventHandler(this.guna2TileButton6_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage3.Controls.Add(this.accDeadline);
            this.tabPage3.Controls.Add(this.acctask);
            this.tabPage3.Controls.Add(this.accPriority);
            this.tabPage3.Controls.Add(this.cmbaccStatuss);
            this.tabPage3.Controls.Add(this.accTaskNames);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel40);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel38);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel37);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel36);
            this.tabPage3.Controls.Add(this.updbtnacc);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel42);
            this.tabPage3.Location = new System.Drawing.Point(194, 4);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1153, 671);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Task Management";
            // 
            // accDeadline
            // 
            this.accDeadline.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accDeadline.BorderRadius = 5;
            this.accDeadline.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accDeadline.DefaultText = "";
            this.accDeadline.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accDeadline.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accDeadline.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accDeadline.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Location = new System.Drawing.Point(193, 158);
            this.accDeadline.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accDeadline.Name = "accDeadline";
            this.accDeadline.PasswordChar = '\0';
            this.accDeadline.PlaceholderText = "";
            this.accDeadline.ReadOnly = true;
            this.accDeadline.SelectedText = "";
            this.accDeadline.Size = new System.Drawing.Size(232, 48);
            this.accDeadline.TabIndex = 255;
            // 
            // acctask
            // 
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.White;
            this.acctask.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle14;
            this.acctask.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.acctask.ColumnHeadersHeight = 30;
            this.acctask.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.acctask.DefaultCellStyle = dataGridViewCellStyle16;
            this.acctask.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.Location = new System.Drawing.Point(474, 98);
            this.acctask.Name = "acctask";
            this.acctask.ReadOnly = true;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.RowHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.acctask.RowHeadersVisible = false;
            this.acctask.RowHeadersWidth = 51;
            dataGridViewCellStyle18.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.acctask.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.acctask.RowTemplate.Height = 24;
            this.acctask.Size = new System.Drawing.Size(584, 514);
            this.acctask.TabIndex = 254;
            this.acctask.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.acctask.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.acctask.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.acctask.ThemeStyle.HeaderStyle.Height = 30;
            this.acctask.ThemeStyle.ReadOnly = true;
            this.acctask.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.acctask.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.ThemeStyle.RowsStyle.Height = 24;
            this.acctask.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.acctask_CellContentClick_1);
            // 
            // accPriority
            // 
            this.accPriority.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accPriority.BorderRadius = 5;
            this.accPriority.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accPriority.DefaultText = "";
            this.accPriority.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accPriority.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accPriority.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accPriority.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Location = new System.Drawing.Point(194, 217);
            this.accPriority.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accPriority.Name = "accPriority";
            this.accPriority.PasswordChar = '\0';
            this.accPriority.PlaceholderText = "";
            this.accPriority.ReadOnly = true;
            this.accPriority.SelectedText = "";
            this.accPriority.Size = new System.Drawing.Size(232, 48);
            this.accPriority.TabIndex = 253;
            // 
            // cmbaccStatuss
            // 
            this.cmbaccStatuss.BackColor = System.Drawing.Color.Transparent;
            this.cmbaccStatuss.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbaccStatuss.BorderRadius = 5;
            this.cmbaccStatuss.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbaccStatuss.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbaccStatuss.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbaccStatuss.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbaccStatuss.ItemHeight = 30;
            this.cmbaccStatuss.Items.AddRange(new object[] {
            "Pending",
            "Completed"});
            this.cmbaccStatuss.Location = new System.Drawing.Point(194, 276);
            this.cmbaccStatuss.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbaccStatuss.Name = "cmbaccStatuss";
            this.cmbaccStatuss.Size = new System.Drawing.Size(232, 36);
            this.cmbaccStatuss.TabIndex = 252;
            // 
            // accTaskNames
            // 
            this.accTaskNames.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accTaskNames.BorderRadius = 5;
            this.accTaskNames.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accTaskNames.DefaultText = "";
            this.accTaskNames.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accTaskNames.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accTaskNames.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accTaskNames.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Location = new System.Drawing.Point(194, 98);
            this.accTaskNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accTaskNames.Name = "accTaskNames";
            this.accTaskNames.PasswordChar = '\0';
            this.accTaskNames.PlaceholderText = "";
            this.accTaskNames.ReadOnly = true;
            this.accTaskNames.SelectedText = "";
            this.accTaskNames.Size = new System.Drawing.Size(232, 48);
            this.accTaskNames.TabIndex = 251;
            // 
            // guna2HtmlLabel40
            // 
            this.guna2HtmlLabel40.AutoSize = false;
            this.guna2HtmlLabel40.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel40.Location = new System.Drawing.Point(50, 228);
            this.guna2HtmlLabel40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel40.Name = "guna2HtmlLabel40";
            this.guna2HtmlLabel40.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel40.TabIndex = 250;
            this.guna2HtmlLabel40.Text = "Priority";
            // 
            // guna2HtmlLabel38
            // 
            this.guna2HtmlLabel38.AutoSize = false;
            this.guna2HtmlLabel38.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel38.Location = new System.Drawing.Point(50, 286);
            this.guna2HtmlLabel38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel38.Name = "guna2HtmlLabel38";
            this.guna2HtmlLabel38.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel38.TabIndex = 249;
            this.guna2HtmlLabel38.Text = "Status";
            // 
            // guna2HtmlLabel37
            // 
            this.guna2HtmlLabel37.AutoSize = false;
            this.guna2HtmlLabel37.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel37.Location = new System.Drawing.Point(50, 110);
            this.guna2HtmlLabel37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel37.Name = "guna2HtmlLabel37";
            this.guna2HtmlLabel37.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel37.TabIndex = 248;
            this.guna2HtmlLabel37.Text = "Task Name";
            // 
            // guna2HtmlLabel36
            // 
            this.guna2HtmlLabel36.AutoSize = false;
            this.guna2HtmlLabel36.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel36.Location = new System.Drawing.Point(50, 167);
            this.guna2HtmlLabel36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel36.Name = "guna2HtmlLabel36";
            this.guna2HtmlLabel36.Size = new System.Drawing.Size(245, 39);
            this.guna2HtmlLabel36.TabIndex = 247;
            this.guna2HtmlLabel36.Text = "Deadline";
            // 
            // updbtnacc
            // 
            this.updbtnacc.BorderRadius = 5;
            this.updbtnacc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtnacc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtnacc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtnacc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtnacc.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.Location = new System.Drawing.Point(280, 334);
            this.updbtnacc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtnacc.Name = "updbtnacc";
            this.updbtnacc.Size = new System.Drawing.Size(145, 46);
            this.updbtnacc.TabIndex = 246;
            this.updbtnacc.Text = "Update";
            this.updbtnacc.Click += new System.EventHandler(this.updbtnacc_Click_1);
            // 
            // guna2HtmlLabel42
            // 
            this.guna2HtmlLabel42.AutoSize = false;
            this.guna2HtmlLabel42.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel42.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel42.Location = new System.Drawing.Point(264, 17);
            this.guna2HtmlLabel42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel42.Name = "guna2HtmlLabel42";
            this.guna2HtmlLabel42.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel42.TabIndex = 245;
            this.guna2HtmlLabel42.Text = "My Tasks";
            this.guna2HtmlLabel42.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // guna2TabControl1
            // 
            this.guna2TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.guna2TabControl1.Controls.Add(this.tabPage5);
            this.guna2TabControl1.Controls.Add(this.tabPage3);
            this.guna2TabControl1.Controls.Add(this.tabPage1);
            this.guna2TabControl1.Controls.Add(this.tabPage2);
            this.guna2TabControl1.Controls.Add(this.tabPage4);
            this.guna2TabControl1.ItemSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.Location = new System.Drawing.Point(1, 114);
            this.guna2TabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TabControl1.Name = "guna2TabControl1";
            this.guna2TabControl1.SelectedIndex = 0;
            this.guna2TabControl1.Size = new System.Drawing.Size(1351, 679);
            this.guna2TabControl1.TabButtonHoverState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonHoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonHoverState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonHoverState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonIdleState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonIdleState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(160)))), ((int)(((byte)(167)))));
            this.guna2TabControl1.TabButtonIdleState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonSelectedState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonSelectedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(37)))), ((int)(((byte)(49)))));
            this.guna2TabControl1.TabButtonSelectedState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonSelectedState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonSelectedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(132)))), ((int)(((byte)(255)))));
            this.guna2TabControl1.TabButtonSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.TabIndex = 32;
            this.guna2TabControl1.TabMenuBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage2.Controls.Add(this.guna2DataGridView4);
            this.tabPage2.Controls.Add(this.guna2DateTimePicker1);
            this.tabPage2.Controls.Add(this.guna2DateTimePicker2);
            this.tabPage2.Controls.Add(this.guna2HtmlLabel13);
            this.tabPage2.Controls.Add(this.guna2HtmlLabel14);
            this.tabPage2.Controls.Add(this.guna2HtmlLabel18);
            this.tabPage2.Location = new System.Drawing.Point(194, 4);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1153, 671);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Financial Report";
            // 
            // guna2DataGridView4
            // 
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.guna2DataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.guna2DataGridView4.ColumnHeadersHeight = 4;
            this.guna2DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView4.DefaultCellStyle = dataGridViewCellStyle21;
            this.guna2DataGridView4.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView4.Location = new System.Drawing.Point(27, 210);
            this.guna2DataGridView4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2DataGridView4.Name = "guna2DataGridView4";
            this.guna2DataGridView4.ReadOnly = true;
            this.guna2DataGridView4.RowHeadersVisible = false;
            this.guna2DataGridView4.RowHeadersWidth = 51;
            this.guna2DataGridView4.RowTemplate.Height = 24;
            this.guna2DataGridView4.Size = new System.Drawing.Size(1027, 378);
            this.guna2DataGridView4.TabIndex = 241;
            this.guna2DataGridView4.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView4.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView4.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView4.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView4.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView4.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView4.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView4.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView4.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView4.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView4.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView4.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView4.ThemeStyle.HeaderStyle.Height = 4;
            this.guna2DataGridView4.ThemeStyle.ReadOnly = true;
            this.guna2DataGridView4.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView4.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView4.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView4.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView4.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView4.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView4.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // guna2DateTimePicker1
            // 
            this.guna2DateTimePicker1.BackColor = System.Drawing.Color.Transparent;
            this.guna2DateTimePicker1.BorderRadius = 5;
            this.guna2DateTimePicker1.BorderThickness = 1;
            this.guna2DateTimePicker1.Checked = true;
            this.guna2DateTimePicker1.FillColor = System.Drawing.Color.White;
            this.guna2DateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.guna2DateTimePicker1.Location = new System.Drawing.Point(819, 154);
            this.guna2DateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2DateTimePicker1.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker1.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker1.Name = "guna2DateTimePicker1";
            this.guna2DateTimePicker1.Size = new System.Drawing.Size(233, 48);
            this.guna2DateTimePicker1.TabIndex = 240;
            this.guna2DateTimePicker1.Value = new System.DateTime(2024, 10, 3, 6, 26, 41, 707);
            // 
            // guna2DateTimePicker2
            // 
            this.guna2DateTimePicker2.BackColor = System.Drawing.Color.Transparent;
            this.guna2DateTimePicker2.BorderRadius = 5;
            this.guna2DateTimePicker2.BorderThickness = 1;
            this.guna2DateTimePicker2.Checked = true;
            this.guna2DateTimePicker2.FillColor = System.Drawing.Color.White;
            this.guna2DateTimePicker2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.guna2DateTimePicker2.Location = new System.Drawing.Point(820, 98);
            this.guna2DateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2DateTimePicker2.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker2.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker2.Name = "guna2DateTimePicker2";
            this.guna2DateTimePicker2.Size = new System.Drawing.Size(233, 48);
            this.guna2DateTimePicker2.TabIndex = 239;
            this.guna2DateTimePicker2.Value = new System.DateTime(2024, 10, 3, 6, 26, 41, 707);
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.AutoSize = false;
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(671, 169);
            this.guna2HtmlLabel13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(280, 34);
            this.guna2HtmlLabel13.TabIndex = 85;
            this.guna2HtmlLabel13.Text = "End Date";
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.AutoSize = false;
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(115, 16);
            this.guna2HtmlLabel14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(1100, 48);
            this.guna2HtmlLabel14.TabIndex = 82;
            this.guna2HtmlLabel14.Text = " Generated Financial Reports";
            this.guna2HtmlLabel14.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // guna2HtmlLabel18
            // 
            this.guna2HtmlLabel18.AutoSize = false;
            this.guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel18.Location = new System.Drawing.Point(671, 112);
            this.guna2HtmlLabel18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel18.Name = "guna2HtmlLabel18";
            this.guna2HtmlLabel18.Size = new System.Drawing.Size(227, 48);
            this.guna2HtmlLabel18.TabIndex = 81;
            this.guna2HtmlLabel18.Text = "Start Date";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage4.Controls.Add(this.Feetbackdgv);
            this.tabPage4.Controls.Add(this.accsend);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel47);
            this.tabPage4.Controls.Add(this.cmbFeedbackType);
            this.tabPage4.Controls.Add(this.txtFeedback);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel41);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel44);
            this.tabPage4.Controls.Add(this.txtEmpName);
            this.tabPage4.Controls.Add(this.txtEmpId);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel27);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel24);
            this.tabPage4.Location = new System.Drawing.Point(194, 4);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1153, 671);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Feedback Management";
            // 
            // Feetbackdgv
            // 
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle22;
            this.Feetbackdgv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Feetbackdgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.Feetbackdgv.ColumnHeadersHeight = 30;
            this.Feetbackdgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Feetbackdgv.DefaultCellStyle = dataGridViewCellStyle24;
            this.Feetbackdgv.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.Location = new System.Drawing.Point(485, 97);
            this.Feetbackdgv.Name = "Feetbackdgv";
            this.Feetbackdgv.ReadOnly = true;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Feetbackdgv.RowHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.Feetbackdgv.RowHeadersVisible = false;
            this.Feetbackdgv.RowHeadersWidth = 51;
            dataGridViewCellStyle26.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.Feetbackdgv.RowsDefaultCellStyle = dataGridViewCellStyle26;
            this.Feetbackdgv.RowTemplate.Height = 24;
            this.Feetbackdgv.Size = new System.Drawing.Size(584, 514);
            this.Feetbackdgv.TabIndex = 255;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Feetbackdgv.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Feetbackdgv.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Feetbackdgv.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Feetbackdgv.ThemeStyle.HeaderStyle.Height = 30;
            this.Feetbackdgv.ThemeStyle.ReadOnly = true;
            this.Feetbackdgv.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Feetbackdgv.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Feetbackdgv.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Feetbackdgv.ThemeStyle.RowsStyle.Height = 24;
            this.Feetbackdgv.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Feetbackdgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Feetbackdgv_CellContentClick_1);
            // 
            // accsend
            // 
            this.accsend.BorderRadius = 5;
            this.accsend.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.accsend.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.accsend.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.accsend.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.accsend.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accsend.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accsend.ForeColor = System.Drawing.Color.DarkGray;
            this.accsend.Location = new System.Drawing.Point(294, 375);
            this.accsend.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.accsend.Name = "accsend";
            this.accsend.Size = new System.Drawing.Size(145, 46);
            this.accsend.TabIndex = 254;
            this.accsend.Text = "Send";
            this.accsend.Click += new System.EventHandler(this.accsend_Click_1);
            // 
            // guna2HtmlLabel47
            // 
            this.guna2HtmlLabel47.AutoSize = false;
            this.guna2HtmlLabel47.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel47.Location = new System.Drawing.Point(46, 167);
            this.guna2HtmlLabel47.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel47.Name = "guna2HtmlLabel47";
            this.guna2HtmlLabel47.Size = new System.Drawing.Size(272, 48);
            this.guna2HtmlLabel47.TabIndex = 253;
            this.guna2HtmlLabel47.Text = "Employee Name";
            // 
            // cmbFeedbackType
            // 
            this.cmbFeedbackType.BackColor = System.Drawing.Color.Transparent;
            this.cmbFeedbackType.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbFeedbackType.BorderRadius = 5;
            this.cmbFeedbackType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbFeedbackType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFeedbackType.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbFeedbackType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbFeedbackType.ItemHeight = 30;
            this.cmbFeedbackType.Items.AddRange(new object[] {
            "Complaint",
            "Suggestion",
            "Inquiry"});
            this.cmbFeedbackType.Location = new System.Drawing.Point(207, 217);
            this.cmbFeedbackType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbFeedbackType.Name = "cmbFeedbackType";
            this.cmbFeedbackType.Size = new System.Drawing.Size(232, 36);
            this.cmbFeedbackType.TabIndex = 252;
            // 
            // txtFeedback
            // 
            this.txtFeedback.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtFeedback.BorderRadius = 5;
            this.txtFeedback.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFeedback.DefaultText = "";
            this.txtFeedback.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtFeedback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtFeedback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtFeedback.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Location = new System.Drawing.Point(207, 270);
            this.txtFeedback.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.PasswordChar = '\0';
            this.txtFeedback.PlaceholderText = "";
            this.txtFeedback.SelectedText = "";
            this.txtFeedback.Size = new System.Drawing.Size(232, 82);
            this.txtFeedback.TabIndex = 251;
            // 
            // guna2HtmlLabel41
            // 
            this.guna2HtmlLabel41.AutoSize = false;
            this.guna2HtmlLabel41.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel41.Location = new System.Drawing.Point(46, 225);
            this.guna2HtmlLabel41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel41.Name = "guna2HtmlLabel41";
            this.guna2HtmlLabel41.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel41.TabIndex = 250;
            this.guna2HtmlLabel41.Text = "Feedback Type";
            // 
            // guna2HtmlLabel44
            // 
            this.guna2HtmlLabel44.AutoSize = false;
            this.guna2HtmlLabel44.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel44.Location = new System.Drawing.Point(46, 111);
            this.guna2HtmlLabel44.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel44.Name = "guna2HtmlLabel44";
            this.guna2HtmlLabel44.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel44.TabIndex = 249;
            this.guna2HtmlLabel44.Text = "Employee Id";
            // 
            // txtEmpName
            // 
            this.txtEmpName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpName.BorderRadius = 5;
            this.txtEmpName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpName.DefaultText = "";
            this.txtEmpName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Location = new System.Drawing.Point(207, 154);
            this.txtEmpName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.PasswordChar = '\0';
            this.txtEmpName.PlaceholderText = "";
            this.txtEmpName.ReadOnly = true;
            this.txtEmpName.SelectedText = "";
            this.txtEmpName.Size = new System.Drawing.Size(232, 48);
            this.txtEmpName.TabIndex = 248;
            // 
            // txtEmpId
            // 
            this.txtEmpId.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpId.BorderRadius = 5;
            this.txtEmpId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpId.DefaultText = "";
            this.txtEmpId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Location = new System.Drawing.Point(207, 97);
            this.txtEmpId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.PasswordChar = '\0';
            this.txtEmpId.PlaceholderText = "";
            this.txtEmpId.ReadOnly = true;
            this.txtEmpId.SelectedText = "";
            this.txtEmpId.Size = new System.Drawing.Size(232, 48);
            this.txtEmpId.TabIndex = 247;
            // 
            // guna2HtmlLabel27
            // 
            this.guna2HtmlLabel27.AutoSize = false;
            this.guna2HtmlLabel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel27.Location = new System.Drawing.Point(46, 294);
            this.guna2HtmlLabel27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel27.Name = "guna2HtmlLabel27";
            this.guna2HtmlLabel27.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel27.TabIndex = 246;
            this.guna2HtmlLabel27.Text = "Feedback";
            // 
            // guna2HtmlLabel24
            // 
            this.guna2HtmlLabel24.AutoSize = false;
            this.guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel24.Location = new System.Drawing.Point(299, 16);
            this.guna2HtmlLabel24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel24.Name = "guna2HtmlLabel24";
            this.guna2HtmlLabel24.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel24.TabIndex = 245;
            this.guna2HtmlLabel24.Text = "Send Feedback";
            this.guna2HtmlLabel24.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // guna2CircleButton3
            // 
            this.guna2CircleButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton3.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton3.Image")));
            this.guna2CircleButton3.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton3.Location = new System.Drawing.Point(1187, 17);
            this.guna2CircleButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton3.Name = "guna2CircleButton3";
            this.guna2CircleButton3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton3.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton3.TabIndex = 47;
            this.guna2CircleButton3.Click += new System.EventHandler(this.guna2CircleButton3_Click);
            // 
            // guna2CircleButton4
            // 
            this.guna2CircleButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton4.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton4.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton4.Image")));
            this.guna2CircleButton4.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton4.Location = new System.Drawing.Point(1261, 17);
            this.guna2CircleButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton4.Name = "guna2CircleButton4";
            this.guna2CircleButton4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton4.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton4.TabIndex = 46;
            this.guna2CircleButton4.Click += new System.EventHandler(this.guna2CircleButton4_Click);
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2ImageButton1.Location = new System.Drawing.Point(99, 17);
            this.guna2ImageButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton1.Size = new System.Drawing.Size(64, 59);
            this.guna2ImageButton1.TabIndex = 45;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click);
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.AutoSize = false;
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel12.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(-32, 69);
            this.guna2HtmlLabel12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(249, 32);
            this.guna2HtmlLabel12.TabIndex = 44;
            this.guna2HtmlLabel12.Text = "Assistant Accountant";
            this.guna2HtmlLabel12.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(472, 27);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(583, 75);
            this.guna2HtmlLabel1.TabIndex = 43;
            this.guna2HtmlLabel1.Text = "Kitchen & Bedroom";
            // 
            // guna2CircleButton2
            // 
            this.guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton2.Image")));
            this.guna2CircleButton2.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton2.Location = new System.Drawing.Point(1187, 18);
            this.guna2CircleButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton2.TabIndex = 42;
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton1.Image")));
            this.guna2CircleButton1.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton1.Location = new System.Drawing.Point(1261, 18);
            this.guna2CircleButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton1.TabIndex = 41;
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2ImageButton3.Location = new System.Drawing.Point(99, 18);
            this.guna2ImageButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Size = new System.Drawing.Size(64, 59);
            this.guna2ImageButton3.TabIndex = 40;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(53, 75);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(115, 32);
            this.guna2HtmlLabel2.TabIndex = 39;
            this.guna2HtmlLabel2.Text = "Accountant";
            this.guna2HtmlLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.AutoSize = false;
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(471, 28);
            this.guna2HtmlLabel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(583, 75);
            this.guna2HtmlLabel3.TabIndex = 38;
            this.guna2HtmlLabel3.Text = "Kitchen & Bedroom";
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button2.Image")));
            this.guna2Button2.ImageSize = new System.Drawing.Size(33, 33);
            this.guna2Button2.Location = new System.Drawing.Point(45, 784);
            this.guna2Button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(152, 57);
            this.guna2Button2.TabIndex = 49;
            this.guna2Button2.Text = "  Logout";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.DarkGray;
            this.guna2Panel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel3.Location = new System.Drawing.Point(255, 790);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(1097, 62);
            this.guna2Panel3.TabIndex = 48;
            // 
            // guna2HtmlToolTip1
            // 
            this.guna2HtmlToolTip1.AllowLinksHandling = true;
            this.guna2HtmlToolTip1.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip2
            // 
            this.guna2HtmlToolTip2.AllowLinksHandling = true;
            this.guna2HtmlToolTip2.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip3
            // 
            this.guna2HtmlToolTip3.AllowLinksHandling = true;
            this.guna2HtmlToolTip3.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip4
            // 
            this.guna2HtmlToolTip4.AllowLinksHandling = true;
            this.guna2HtmlToolTip4.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip5
            // 
            this.guna2HtmlToolTip5.AllowLinksHandling = true;
            this.guna2HtmlToolTip5.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip6
            // 
            this.guna2HtmlToolTip6.AllowLinksHandling = true;
            this.guna2HtmlToolTip6.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlLabel48
            // 
            this.guna2HtmlLabel48.AutoSize = false;
            this.guna2HtmlLabel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel48.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel48.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel48.Location = new System.Drawing.Point(782, 212);
            this.guna2HtmlLabel48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel48.Name = "guna2HtmlLabel48";
            this.guna2HtmlLabel48.Size = new System.Drawing.Size(239, 44);
            this.guna2HtmlLabel48.TabIndex = 198;
            this.guna2HtmlLabel48.Text = "Salary";
            this.guna2HtmlLabel48.Click += new System.EventHandler(this.guna2HtmlLabel48_Click);
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.AutoSize = false;
            this.guna2TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox2.Location = new System.Drawing.Point(880, 170);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.Size = new System.Drawing.Size(194, 98);
            this.guna2TextBox2.TabIndex = 197;
            this.guna2TextBox2.Text = null;
            this.guna2TextBox2.Click += new System.EventHandler(this.guna2TextBox2_Click);
            // 
            // guna2HtmlLabel46
            // 
            this.guna2HtmlLabel46.AutoSize = false;
            this.guna2HtmlLabel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel46.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel46.Location = new System.Drawing.Point(789, 499);
            this.guna2HtmlLabel46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel46.Name = "guna2HtmlLabel46";
            this.guna2HtmlLabel46.Size = new System.Drawing.Size(122, 44);
            this.guna2HtmlLabel46.TabIndex = 196;
            this.guna2HtmlLabel46.Text = "Tasks";
            this.guna2HtmlLabel46.Click += new System.EventHandler(this.guna2HtmlLabel46_Click);
            // 
            // guna2HtmlLabel52
            // 
            this.guna2HtmlLabel52.AutoSize = false;
            this.guna2HtmlLabel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel52.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel52.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel52.Location = new System.Drawing.Point(125, 530);
            this.guna2HtmlLabel52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel52.Name = "guna2HtmlLabel52";
            this.guna2HtmlLabel52.Size = new System.Drawing.Size(327, 44);
            this.guna2HtmlLabel52.TabIndex = 195;
            this.guna2HtmlLabel52.Text = "Alert";
            this.guna2HtmlLabel52.Click += new System.EventHandler(this.guna2HtmlLabel52_Click);
            // 
            // guna2HtmlLabel49
            // 
            this.guna2HtmlLabel49.AutoSize = false;
            this.guna2HtmlLabel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel49.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel49.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel49.Location = new System.Drawing.Point(116, 500);
            this.guna2HtmlLabel49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel49.Name = "guna2HtmlLabel49";
            this.guna2HtmlLabel49.Size = new System.Drawing.Size(349, 44);
            this.guna2HtmlLabel49.TabIndex = 194;
            this.guna2HtmlLabel49.Text = "Meeting";
            this.guna2HtmlLabel49.Click += new System.EventHandler(this.guna2HtmlLabel49_Click);
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.AutoSize = false;
            this.guna2TextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox6.Location = new System.Drawing.Point(237, 456);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.Size = new System.Drawing.Size(785, 82);
            this.guna2TextBox6.TabIndex = 193;
            this.guna2TextBox6.Text = null;
            this.guna2TextBox6.Click += new System.EventHandler(this.guna2TextBox6_Click);
            // 
            // guna2TextBox5
            // 
            this.guna2TextBox5.AutoSize = false;
            this.guna2TextBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox5.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox5.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox5.Location = new System.Drawing.Point(899, 435);
            this.guna2TextBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox5.Name = "guna2TextBox5";
            this.guna2TextBox5.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox5.TabIndex = 192;
            this.guna2TextBox5.Text = null;
            this.guna2TextBox5.Click += new System.EventHandler(this.guna2TextBox10_Click);
            // 
            // guna2Button8
            // 
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button8.Image")));
            this.guna2Button8.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button8.Location = new System.Drawing.Point(785, 403);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.Size = new System.Drawing.Size(72, 88);
            this.guna2Button8.TabIndex = 191;
            this.guna2Button8.Click += new System.EventHandler(this.guna2Button8_Click);
            // 
            // guna2Button4
            // 
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button4.Image")));
            this.guna2Button4.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button4.Location = new System.Drawing.Point(102, 409);
            this.guna2Button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.Size = new System.Drawing.Size(105, 89);
            this.guna2Button4.TabIndex = 190;
            this.guna2Button4.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // guna2TileButton5
            // 
            this.guna2TileButton5.BorderRadius = 30;
            this.guna2TileButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton5.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton5.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton5.Location = new System.Drawing.Point(78, 362);
            this.guna2TileButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton5.Name = "guna2TileButton5";
            this.guna2TileButton5.Size = new System.Drawing.Size(635, 226);
            this.guna2TileButton5.TabIndex = 189;
            this.guna2TileButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton5.Click += new System.EventHandler(this.guna2TileButton5_Click);
            // 
            // guna2TileButton4
            // 
            this.guna2TileButton4.BorderRadius = 30;
            this.guna2TileButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton4.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton4.Location = new System.Drawing.Point(743, 362);
            this.guna2TileButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton4.Name = "guna2TileButton4";
            this.guna2TileButton4.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton4.TabIndex = 188;
            // 
            // guna2HtmlLabel45
            // 
            this.guna2HtmlLabel45.AutoSize = false;
            this.guna2HtmlLabel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel45.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel45.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel45.Location = new System.Drawing.Point(445, 210);
            this.guna2HtmlLabel45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel45.Name = "guna2HtmlLabel45";
            this.guna2HtmlLabel45.Size = new System.Drawing.Size(213, 44);
            this.guna2HtmlLabel45.TabIndex = 187;
            this.guna2HtmlLabel45.Text = "Suppliers\r\n";
            this.guna2HtmlLabel45.Click += new System.EventHandler(this.guna2HtmlLabel45_Click);
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.AutoSize = false;
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(102, 210);
            this.guna2HtmlLabel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(215, 44);
            this.guna2HtmlLabel4.TabIndex = 186;
            this.guna2HtmlLabel4.Text = "Employees";
            this.guna2HtmlLabel4.Click += new System.EventHandler(this.guna2HtmlLabel4_Click);
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.AutoSize = false;
            this.guna2TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox1.Location = new System.Drawing.Point(589, 148);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox1.TabIndex = 185;
            this.guna2TextBox1.Text = null;
            this.guna2TextBox1.Click += new System.EventHandler(this.guna2TextBox1_Click);
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.AutoSize = false;
            this.guna2TextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox3.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox3.Location = new System.Drawing.Point(236, 148);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox3.TabIndex = 184;
            this.guna2TextBox3.Text = null;
            this.guna2TextBox3.Click += new System.EventHandler(this.guna2TextBox4_Click);
            // 
            // guna2Button6
            // 
            this.guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button6.Image")));
            this.guna2Button6.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button6.Location = new System.Drawing.Point(763, 121);
            this.guna2Button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.Size = new System.Drawing.Size(87, 89);
            this.guna2Button6.TabIndex = 183;
            this.guna2Button6.Click += new System.EventHandler(this.guna2Button6_Click);
            // 
            // guna2TileButton3
            // 
            this.guna2TileButton3.BorderRadius = 30;
            this.guna2TileButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton3.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton3.Location = new System.Drawing.Point(745, 83);
            this.guna2TileButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton3.Name = "guna2TileButton3";
            this.guna2TileButton3.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton3.TabIndex = 182;
            this.guna2TileButton3.Click += new System.EventHandler(this.guna2TileButton3_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.guna2Button3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button3.Image")));
            this.guna2Button3.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button3.Location = new System.Drawing.Point(120, 117);
            this.guna2Button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(71, 89);
            this.guna2Button3.TabIndex = 181;
            this.guna2Button3.UseTransparentBackground = true;
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // guna2TileButton1
            // 
            this.guna2TileButton1.BorderRadius = 30;
            this.guna2TileButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton1.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton1.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton1.Location = new System.Drawing.Point(80, 83);
            this.guna2TileButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton1.Name = "guna2TileButton1";
            this.guna2TileButton1.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton1.TabIndex = 180;
            this.guna2TileButton1.Click += new System.EventHandler(this.guna2TileButton1_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button1.Location = new System.Drawing.Point(434, 121);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(120, 89);
            this.guna2Button1.TabIndex = 179;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2TileButton2
            // 
            this.guna2TileButton2.BorderRadius = 30;
            this.guna2TileButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton2.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton2.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton2.Location = new System.Drawing.Point(421, 86);
            this.guna2TileButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton2.Name = "guna2TileButton2";
            this.guna2TileButton2.Size = new System.Drawing.Size(281, 226);
            this.guna2TileButton2.TabIndex = 178;
            this.guna2TileButton2.Click += new System.EventHandler(this.guna2TileButton2_Click);
            // 
            // AssistantAccountant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(1349, 850);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2CircleButton3);
            this.Controls.Add(this.guna2CircleButton4);
            this.Controls.Add(this.guna2ImageButton1);
            this.Controls.Add(this.guna2HtmlLabel12);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.guna2CircleButton2);
            this.Controls.Add(this.guna2CircleButton1);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.guna2HtmlLabel3);
            this.Controls.Add(this.guna2TabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AssistantAccountant";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AssistantAccountant";
            this.Load += new System.EventHandler(this.AssistantAccountant_Load);
            this.tabPage5.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).EndInit();
            this.guna2TabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView4)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Feetbackdgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private System.Windows.Forms.TabPage tabPage4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton7;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton6;
        private System.Windows.Forms.TabPage tabPage2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel18;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton4;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker2;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView4;
        private Guna.UI2.WinForms.Guna2TextBox accDeadline;
        private Guna.UI2.WinForms.Guna2DataGridView acctask;
        private Guna.UI2.WinForms.Guna2TextBox accPriority;
        private Guna.UI2.WinForms.Guna2ComboBox cmbaccStatuss;
        private Guna.UI2.WinForms.Guna2TextBox accTaskNames;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel40;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel38;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel37;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel36;
        private Guna.UI2.WinForms.Guna2Button updbtnacc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel42;
        private Guna.UI2.WinForms.Guna2DataGridView Feetbackdgv;
        private Guna.UI2.WinForms.Guna2Button accsend;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel47;
        private Guna.UI2.WinForms.Guna2ComboBox cmbFeedbackType;
        private Guna.UI2.WinForms.Guna2TextBox txtFeedback;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel41;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel44;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpName;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpId;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel27;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel24;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip1;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip2;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip3;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip4;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip5;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel48;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel46;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel52;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel49;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox5;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton5;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel45;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox3;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton3;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton2;
    }
}