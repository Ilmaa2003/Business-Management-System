﻿namespace FinalProject
{
    partial class Storekeeper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Storekeeper));
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgvFeedback = new Guna.UI2.WinForms.Guna2DataGridView();
            this.sendc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel47 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbFeedbackType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtFeedback = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtEmpName = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtEmpId = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel27 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel24 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.accDeadline = new Guna.UI2.WinForms.Guna2TextBox();
            this.acctask = new Guna.UI2.WinForms.Guna2DataGridView();
            this.accPriority = new Guna.UI2.WinForms.Guna2TextBox();
            this.cmbaccStatuss = new Guna.UI2.WinForms.Guna2ComboBox();
            this.accTaskNames = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel40 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel38 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel37 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel36 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.updbtnacc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel42 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvinventory = new Guna.UI2.WinForms.Guna2DataGridView();
            this.productbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.supnamebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.datebox = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.supcmbbox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.qtybox = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.typecombo = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel16 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel19 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel15 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.removebtn = new Guna.UI2.WinForms.Guna2Button();
            this.addbtn = new Guna.UI2.WinForms.Guna2Button();
            this.clearbtn = new Guna.UI2.WinForms.Guna2Button();
            this.updatebtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlToolTip1 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip2 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip3 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip4 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip5 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip6 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlLabel48 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel46 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel52 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel49 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton5 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2HtmlLabel45 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel20 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton3 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton2 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.guna2TabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvinventory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtybox)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage4.Controls.Add(this.dgvFeedback);
            this.tabPage4.Controls.Add(this.sendc);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel47);
            this.tabPage4.Controls.Add(this.cmbFeedbackType);
            this.tabPage4.Controls.Add(this.txtFeedback);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel5);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel8);
            this.tabPage4.Controls.Add(this.txtEmpName);
            this.tabPage4.Controls.Add(this.txtEmpId);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel27);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel24);
            this.tabPage4.Location = new System.Drawing.Point(194, 4);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1153, 671);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Feedback Management";
            // 
            // dgvFeedback
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFeedback.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFeedback.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvFeedback.ColumnHeadersHeight = 30;
            this.dgvFeedback.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFeedback.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvFeedback.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.Location = new System.Drawing.Point(469, 98);
            this.dgvFeedback.Name = "dgvFeedback";
            this.dgvFeedback.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFeedback.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvFeedback.RowHeadersVisible = false;
            this.dgvFeedback.RowHeadersWidth = 51;
            dataGridViewCellStyle5.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvFeedback.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvFeedback.RowTemplate.Height = 24;
            this.dgvFeedback.Size = new System.Drawing.Size(584, 514);
            this.dgvFeedback.TabIndex = 264;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvFeedback.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvFeedback.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvFeedback.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvFeedback.ThemeStyle.ReadOnly = true;
            this.dgvFeedback.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvFeedback.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvFeedback.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvFeedback.ThemeStyle.RowsStyle.Height = 24;
            this.dgvFeedback.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvFeedback.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFeedback_CellContentClick);
            // 
            // sendc
            // 
            this.sendc.BorderRadius = 5;
            this.sendc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.sendc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.sendc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.sendc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.sendc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.sendc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sendc.ForeColor = System.Drawing.Color.DarkGray;
            this.sendc.Location = new System.Drawing.Point(283, 376);
            this.sendc.Name = "sendc";
            this.sendc.Size = new System.Drawing.Size(145, 45);
            this.sendc.TabIndex = 263;
            this.sendc.Text = "Send";
            this.sendc.Click += new System.EventHandler(this.sendc_Click);
            // 
            // guna2HtmlLabel47
            // 
            this.guna2HtmlLabel47.AutoSize = false;
            this.guna2HtmlLabel47.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel47.Location = new System.Drawing.Point(35, 169);
            this.guna2HtmlLabel47.Name = "guna2HtmlLabel47";
            this.guna2HtmlLabel47.Size = new System.Drawing.Size(272, 48);
            this.guna2HtmlLabel47.TabIndex = 262;
            this.guna2HtmlLabel47.Text = "Employee Name";
            // 
            // cmbFeedbackType
            // 
            this.cmbFeedbackType.BackColor = System.Drawing.Color.Transparent;
            this.cmbFeedbackType.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbFeedbackType.BorderRadius = 5;
            this.cmbFeedbackType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbFeedbackType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFeedbackType.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbFeedbackType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbFeedbackType.ItemHeight = 30;
            this.cmbFeedbackType.Items.AddRange(new object[] {
            "Complaint",
            "Suggestion",
            "Inquiry"});
            this.cmbFeedbackType.Location = new System.Drawing.Point(196, 218);
            this.cmbFeedbackType.Name = "cmbFeedbackType";
            this.cmbFeedbackType.Size = new System.Drawing.Size(232, 36);
            this.cmbFeedbackType.TabIndex = 261;
            // 
            // txtFeedback
            // 
            this.txtFeedback.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtFeedback.BorderRadius = 5;
            this.txtFeedback.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFeedback.DefaultText = "";
            this.txtFeedback.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtFeedback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtFeedback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtFeedback.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Location = new System.Drawing.Point(196, 271);
            this.txtFeedback.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.PasswordChar = '\0';
            this.txtFeedback.PlaceholderText = "";
            this.txtFeedback.SelectedText = "";
            this.txtFeedback.Size = new System.Drawing.Size(232, 82);
            this.txtFeedback.TabIndex = 260;
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.AutoSize = false;
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(35, 226);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel5.TabIndex = 259;
            this.guna2HtmlLabel5.Text = "Feedback Type";
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.AutoSize = false;
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(35, 112);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel8.TabIndex = 258;
            this.guna2HtmlLabel8.Text = "Employee Id";
            // 
            // txtEmpName
            // 
            this.txtEmpName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpName.BorderRadius = 5;
            this.txtEmpName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpName.DefaultText = "";
            this.txtEmpName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Location = new System.Drawing.Point(196, 155);
            this.txtEmpName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.PasswordChar = '\0';
            this.txtEmpName.PlaceholderText = "";
            this.txtEmpName.ReadOnly = true;
            this.txtEmpName.SelectedText = "";
            this.txtEmpName.Size = new System.Drawing.Size(232, 48);
            this.txtEmpName.TabIndex = 257;
            // 
            // txtEmpId
            // 
            this.txtEmpId.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpId.BorderRadius = 5;
            this.txtEmpId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpId.DefaultText = "";
            this.txtEmpId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Location = new System.Drawing.Point(196, 98);
            this.txtEmpId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.PasswordChar = '\0';
            this.txtEmpId.PlaceholderText = "";
            this.txtEmpId.ReadOnly = true;
            this.txtEmpId.SelectedText = "";
            this.txtEmpId.Size = new System.Drawing.Size(232, 48);
            this.txtEmpId.TabIndex = 256;
            // 
            // guna2HtmlLabel27
            // 
            this.guna2HtmlLabel27.AutoSize = false;
            this.guna2HtmlLabel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel27.Location = new System.Drawing.Point(35, 295);
            this.guna2HtmlLabel27.Name = "guna2HtmlLabel27";
            this.guna2HtmlLabel27.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel27.TabIndex = 255;
            this.guna2HtmlLabel27.Text = "Feedback";
            // 
            // guna2HtmlLabel24
            // 
            this.guna2HtmlLabel24.AutoSize = false;
            this.guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel24.Location = new System.Drawing.Point(300, 17);
            this.guna2HtmlLabel24.Name = "guna2HtmlLabel24";
            this.guna2HtmlLabel24.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel24.TabIndex = 254;
            this.guna2HtmlLabel24.Text = "Send Feedback";
            this.guna2HtmlLabel24.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage5.Controls.Add(this.guna2HtmlLabel48);
            this.tabPage5.Controls.Add(this.guna2TextBox2);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel46);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel52);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel49);
            this.tabPage5.Controls.Add(this.guna2TextBox6);
            this.tabPage5.Controls.Add(this.guna2TextBox4);
            this.tabPage5.Controls.Add(this.guna2Button8);
            this.tabPage5.Controls.Add(this.guna2Button4);
            this.tabPage5.Controls.Add(this.guna2TileButton5);
            this.tabPage5.Controls.Add(this.guna2TileButton4);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel45);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel20);
            this.tabPage5.Controls.Add(this.guna2TextBox1);
            this.tabPage5.Controls.Add(this.guna2TextBox3);
            this.tabPage5.Controls.Add(this.guna2Button6);
            this.tabPage5.Controls.Add(this.guna2TileButton3);
            this.tabPage5.Controls.Add(this.guna2Button3);
            this.tabPage5.Controls.Add(this.guna2TileButton1);
            this.tabPage5.Controls.Add(this.guna2Button1);
            this.tabPage5.Controls.Add(this.guna2TileButton2);
            this.tabPage5.Location = new System.Drawing.Point(194, 4);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1153, 671);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Dashboard";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // guna2TabControl1
            // 
            this.guna2TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.guna2TabControl1.Controls.Add(this.tabPage5);
            this.guna2TabControl1.Controls.Add(this.tabPage3);
            this.guna2TabControl1.Controls.Add(this.tabPage1);
            this.guna2TabControl1.Controls.Add(this.tabPage4);
            this.guna2TabControl1.ItemSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.Location = new System.Drawing.Point(0, 114);
            this.guna2TabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TabControl1.Name = "guna2TabControl1";
            this.guna2TabControl1.SelectedIndex = 0;
            this.guna2TabControl1.Size = new System.Drawing.Size(1351, 679);
            this.guna2TabControl1.TabButtonHoverState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonHoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonHoverState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonHoverState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonIdleState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonIdleState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(160)))), ((int)(((byte)(167)))));
            this.guna2TabControl1.TabButtonIdleState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonSelectedState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonSelectedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(37)))), ((int)(((byte)(49)))));
            this.guna2TabControl1.TabButtonSelectedState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonSelectedState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonSelectedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(132)))), ((int)(((byte)(255)))));
            this.guna2TabControl1.TabButtonSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.TabIndex = 39;
            this.guna2TabControl1.TabMenuBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage3.Controls.Add(this.accDeadline);
            this.tabPage3.Controls.Add(this.acctask);
            this.tabPage3.Controls.Add(this.accPriority);
            this.tabPage3.Controls.Add(this.cmbaccStatuss);
            this.tabPage3.Controls.Add(this.accTaskNames);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel40);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel38);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel37);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel36);
            this.tabPage3.Controls.Add(this.updbtnacc);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel42);
            this.tabPage3.Location = new System.Drawing.Point(194, 4);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1153, 671);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Task Management";
            // 
            // accDeadline
            // 
            this.accDeadline.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accDeadline.BorderRadius = 5;
            this.accDeadline.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accDeadline.DefaultText = "";
            this.accDeadline.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accDeadline.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accDeadline.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accDeadline.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Location = new System.Drawing.Point(194, 158);
            this.accDeadline.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accDeadline.Name = "accDeadline";
            this.accDeadline.PasswordChar = '\0';
            this.accDeadline.PlaceholderText = "";
            this.accDeadline.ReadOnly = true;
            this.accDeadline.SelectedText = "";
            this.accDeadline.Size = new System.Drawing.Size(232, 48);
            this.accDeadline.TabIndex = 255;
            // 
            // acctask
            // 
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            this.acctask.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.acctask.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.acctask.ColumnHeadersHeight = 30;
            this.acctask.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.acctask.DefaultCellStyle = dataGridViewCellStyle8;
            this.acctask.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.Location = new System.Drawing.Point(475, 98);
            this.acctask.Name = "acctask";
            this.acctask.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.acctask.RowHeadersVisible = false;
            this.acctask.RowHeadersWidth = 51;
            dataGridViewCellStyle10.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.acctask.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.acctask.RowTemplate.Height = 24;
            this.acctask.Size = new System.Drawing.Size(584, 514);
            this.acctask.TabIndex = 254;
            this.acctask.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.acctask.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.acctask.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.acctask.ThemeStyle.HeaderStyle.Height = 30;
            this.acctask.ThemeStyle.ReadOnly = true;
            this.acctask.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.acctask.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.ThemeStyle.RowsStyle.Height = 24;
            this.acctask.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.acctask_CellContentClick_1);
            // 
            // accPriority
            // 
            this.accPriority.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accPriority.BorderRadius = 5;
            this.accPriority.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accPriority.DefaultText = "";
            this.accPriority.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accPriority.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accPriority.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accPriority.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Location = new System.Drawing.Point(195, 217);
            this.accPriority.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accPriority.Name = "accPriority";
            this.accPriority.PasswordChar = '\0';
            this.accPriority.PlaceholderText = "";
            this.accPriority.ReadOnly = true;
            this.accPriority.SelectedText = "";
            this.accPriority.Size = new System.Drawing.Size(232, 48);
            this.accPriority.TabIndex = 253;
            // 
            // cmbaccStatuss
            // 
            this.cmbaccStatuss.BackColor = System.Drawing.Color.Transparent;
            this.cmbaccStatuss.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbaccStatuss.BorderRadius = 5;
            this.cmbaccStatuss.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbaccStatuss.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbaccStatuss.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbaccStatuss.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbaccStatuss.ItemHeight = 30;
            this.cmbaccStatuss.Items.AddRange(new object[] {
            "Pending",
            "Completed"});
            this.cmbaccStatuss.Location = new System.Drawing.Point(195, 276);
            this.cmbaccStatuss.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbaccStatuss.Name = "cmbaccStatuss";
            this.cmbaccStatuss.Size = new System.Drawing.Size(232, 36);
            this.cmbaccStatuss.TabIndex = 252;
            // 
            // accTaskNames
            // 
            this.accTaskNames.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accTaskNames.BorderRadius = 5;
            this.accTaskNames.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accTaskNames.DefaultText = "";
            this.accTaskNames.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accTaskNames.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accTaskNames.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accTaskNames.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Location = new System.Drawing.Point(195, 98);
            this.accTaskNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accTaskNames.Name = "accTaskNames";
            this.accTaskNames.PasswordChar = '\0';
            this.accTaskNames.PlaceholderText = "";
            this.accTaskNames.ReadOnly = true;
            this.accTaskNames.SelectedText = "";
            this.accTaskNames.Size = new System.Drawing.Size(232, 48);
            this.accTaskNames.TabIndex = 251;
            // 
            // guna2HtmlLabel40
            // 
            this.guna2HtmlLabel40.AutoSize = false;
            this.guna2HtmlLabel40.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel40.Location = new System.Drawing.Point(51, 228);
            this.guna2HtmlLabel40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel40.Name = "guna2HtmlLabel40";
            this.guna2HtmlLabel40.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel40.TabIndex = 250;
            this.guna2HtmlLabel40.Text = "Priority";
            // 
            // guna2HtmlLabel38
            // 
            this.guna2HtmlLabel38.AutoSize = false;
            this.guna2HtmlLabel38.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel38.Location = new System.Drawing.Point(51, 286);
            this.guna2HtmlLabel38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel38.Name = "guna2HtmlLabel38";
            this.guna2HtmlLabel38.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel38.TabIndex = 249;
            this.guna2HtmlLabel38.Text = "Status";
            // 
            // guna2HtmlLabel37
            // 
            this.guna2HtmlLabel37.AutoSize = false;
            this.guna2HtmlLabel37.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel37.Location = new System.Drawing.Point(51, 110);
            this.guna2HtmlLabel37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel37.Name = "guna2HtmlLabel37";
            this.guna2HtmlLabel37.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel37.TabIndex = 248;
            this.guna2HtmlLabel37.Text = "Task Name";
            // 
            // guna2HtmlLabel36
            // 
            this.guna2HtmlLabel36.AutoSize = false;
            this.guna2HtmlLabel36.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel36.Location = new System.Drawing.Point(51, 167);
            this.guna2HtmlLabel36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel36.Name = "guna2HtmlLabel36";
            this.guna2HtmlLabel36.Size = new System.Drawing.Size(245, 39);
            this.guna2HtmlLabel36.TabIndex = 247;
            this.guna2HtmlLabel36.Text = "Deadline";
            // 
            // updbtnacc
            // 
            this.updbtnacc.BorderRadius = 5;
            this.updbtnacc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtnacc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtnacc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtnacc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtnacc.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.Location = new System.Drawing.Point(281, 334);
            this.updbtnacc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtnacc.Name = "updbtnacc";
            this.updbtnacc.Size = new System.Drawing.Size(145, 46);
            this.updbtnacc.TabIndex = 246;
            this.updbtnacc.Text = "Update";
            this.updbtnacc.Click += new System.EventHandler(this.updbtnacc_Click);
            // 
            // guna2HtmlLabel42
            // 
            this.guna2HtmlLabel42.AutoSize = false;
            this.guna2HtmlLabel42.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel42.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel42.Location = new System.Drawing.Point(265, 17);
            this.guna2HtmlLabel42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel42.Name = "guna2HtmlLabel42";
            this.guna2HtmlLabel42.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel42.TabIndex = 245;
            this.guna2HtmlLabel42.Text = "My Tasks";
            this.guna2HtmlLabel42.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.dgvinventory);
            this.tabPage1.Controls.Add(this.productbox);
            this.tabPage1.Controls.Add(this.guna2Button13);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel4);
            this.tabPage1.Controls.Add(this.supnamebox);
            this.tabPage1.Controls.Add(this.datebox);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel7);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel6);
            this.tabPage1.Controls.Add(this.supcmbbox);
            this.tabPage1.Controls.Add(this.qtybox);
            this.tabPage1.Controls.Add(this.typecombo);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel3);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel16);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel19);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel15);
            this.tabPage1.Controls.Add(this.removebtn);
            this.tabPage1.Controls.Add(this.addbtn);
            this.tabPage1.Controls.Add(this.clearbtn);
            this.tabPage1.Controls.Add(this.updatebtn);
            this.tabPage1.Location = new System.Drawing.Point(194, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1153, 671);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Inventory Management";
            // 
            // dgvinventory
            // 
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            this.dgvinventory.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvinventory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvinventory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvinventory.ColumnHeadersHeight = 50;
            this.dgvinventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvinventory.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgvinventory.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvinventory.Location = new System.Drawing.Point(524, 97);
            this.dgvinventory.Name = "dgvinventory";
            this.dgvinventory.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvinventory.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dgvinventory.RowHeadersVisible = false;
            this.dgvinventory.RowHeadersWidth = 51;
            dataGridViewCellStyle15.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvinventory.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvinventory.RowTemplate.Height = 24;
            this.dgvinventory.Size = new System.Drawing.Size(546, 494);
            this.dgvinventory.TabIndex = 275;
            this.dgvinventory.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvinventory.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvinventory.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvinventory.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvinventory.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvinventory.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvinventory.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvinventory.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvinventory.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvinventory.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvinventory.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvinventory.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvinventory.ThemeStyle.HeaderStyle.Height = 50;
            this.dgvinventory.ThemeStyle.ReadOnly = true;
            this.dgvinventory.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvinventory.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvinventory.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvinventory.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvinventory.ThemeStyle.RowsStyle.Height = 24;
            this.dgvinventory.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvinventory.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvinventory.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvinventory_CellContentClick_1);
            // 
            // productbox
            // 
            this.productbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.productbox.BorderRadius = 5;
            this.productbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.productbox.DefaultText = "";
            this.productbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.productbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.productbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.productbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.productbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.productbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.productbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.productbox.Location = new System.Drawing.Point(257, 263);
            this.productbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.productbox.Name = "productbox";
            this.productbox.PasswordChar = '\0';
            this.productbox.PlaceholderText = "";
            this.productbox.SelectedText = "";
            this.productbox.Size = new System.Drawing.Size(232, 48);
            this.productbox.TabIndex = 274;
            // 
            // guna2Button13
            // 
            this.guna2Button13.BorderRadius = 5;
            this.guna2Button13.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button13.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.Location = new System.Drawing.Point(730, 609);
            this.guna2Button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.Size = new System.Drawing.Size(145, 46);
            this.guna2Button13.TabIndex = 273;
            this.guna2Button13.Text = "Print";
            this.guna2Button13.Click += new System.EventHandler(this.guna2Button13_Click);
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.AutoSize = false;
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(40, 164);
            this.guna2HtmlLabel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(212, 34);
            this.guna2HtmlLabel4.TabIndex = 272;
            this.guna2HtmlLabel4.Text = "Supplier Name";
            // 
            // supnamebox
            // 
            this.supnamebox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.supnamebox.BorderRadius = 5;
            this.supnamebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.supnamebox.DefaultText = "";
            this.supnamebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.supnamebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.supnamebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.supnamebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.supnamebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.supnamebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.supnamebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.supnamebox.Location = new System.Drawing.Point(257, 150);
            this.supnamebox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.supnamebox.Name = "supnamebox";
            this.supnamebox.PasswordChar = '\0';
            this.supnamebox.PlaceholderText = "";
            this.supnamebox.SelectedText = "";
            this.supnamebox.Size = new System.Drawing.Size(232, 48);
            this.supnamebox.TabIndex = 271;
            // 
            // datebox
            // 
            this.datebox.BackColor = System.Drawing.Color.Transparent;
            this.datebox.BorderRadius = 5;
            this.datebox.BorderThickness = 1;
            this.datebox.Checked = true;
            this.datebox.FillColor = System.Drawing.Color.White;
            this.datebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.datebox.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datebox.Location = new System.Drawing.Point(257, 384);
            this.datebox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.datebox.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.datebox.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.datebox.Name = "datebox";
            this.datebox.Size = new System.Drawing.Size(232, 48);
            this.datebox.TabIndex = 270;
            this.datebox.Value = new System.DateTime(2024, 10, 3, 6, 26, 41, 707);
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.AutoSize = false;
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(40, 395);
            this.guna2HtmlLabel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(401, 34);
            this.guna2HtmlLabel7.TabIndex = 269;
            this.guna2HtmlLabel7.Text = "Product Added Date";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.AutoSize = false;
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(40, 107);
            this.guna2HtmlLabel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(212, 34);
            this.guna2HtmlLabel6.TabIndex = 268;
            this.guna2HtmlLabel6.Text = "Supplier ID";
            // 
            // supcmbbox
            // 
            this.supcmbbox.BackColor = System.Drawing.Color.Transparent;
            this.supcmbbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.supcmbbox.BorderRadius = 5;
            this.supcmbbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.supcmbbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.supcmbbox.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.supcmbbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.supcmbbox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.supcmbbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.supcmbbox.ItemHeight = 30;
            this.supcmbbox.Location = new System.Drawing.Point(257, 97);
            this.supcmbbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.supcmbbox.Name = "supcmbbox";
            this.supcmbbox.Size = new System.Drawing.Size(232, 36);
            this.supcmbbox.TabIndex = 267;
            this.supcmbbox.SelectedIndexChanged += new System.EventHandler(this.supcmbbox_SelectedIndexChanged_1);
            // 
            // qtybox
            // 
            this.qtybox.BackColor = System.Drawing.Color.Transparent;
            this.qtybox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.qtybox.BorderRadius = 5;
            this.qtybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qtybox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.qtybox.Location = new System.Drawing.Point(257, 323);
            this.qtybox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.qtybox.Name = "qtybox";
            this.qtybox.Size = new System.Drawing.Size(232, 48);
            this.qtybox.TabIndex = 266;
            // 
            // typecombo
            // 
            this.typecombo.BackColor = System.Drawing.Color.Transparent;
            this.typecombo.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.typecombo.BorderRadius = 5;
            this.typecombo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.typecombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.typecombo.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.typecombo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.typecombo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.typecombo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.typecombo.ItemHeight = 30;
            this.typecombo.Items.AddRange(new object[] {
            "Tool",
            "Raw Material",
            "Item",
            "Other"});
            this.typecombo.Location = new System.Drawing.Point(257, 208);
            this.typecombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.typecombo.Name = "typecombo";
            this.typecombo.Size = new System.Drawing.Size(232, 36);
            this.typecombo.TabIndex = 264;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.AutoSize = false;
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(40, 273);
            this.guna2HtmlLabel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel3.TabIndex = 263;
            this.guna2HtmlLabel3.Text = "Product Name";
            // 
            // guna2HtmlLabel16
            // 
            this.guna2HtmlLabel16.AutoSize = false;
            this.guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel16.Location = new System.Drawing.Point(40, 332);
            this.guna2HtmlLabel16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel16.Name = "guna2HtmlLabel16";
            this.guna2HtmlLabel16.Size = new System.Drawing.Size(227, 48);
            this.guna2HtmlLabel16.TabIndex = 262;
            this.guna2HtmlLabel16.Text = "Quantity";
            // 
            // guna2HtmlLabel19
            // 
            this.guna2HtmlLabel19.AutoSize = false;
            this.guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel19.Location = new System.Drawing.Point(40, 219);
            this.guna2HtmlLabel19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel19.Name = "guna2HtmlLabel19";
            this.guna2HtmlLabel19.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel19.TabIndex = 261;
            this.guna2HtmlLabel19.Text = "Type";
            // 
            // guna2HtmlLabel15
            // 
            this.guna2HtmlLabel15.AutoSize = false;
            this.guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel15.Location = new System.Drawing.Point(175, 14);
            this.guna2HtmlLabel15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel15.Name = "guna2HtmlLabel15";
            this.guna2HtmlLabel15.Size = new System.Drawing.Size(763, 48);
            this.guna2HtmlLabel15.TabIndex = 260;
            this.guna2HtmlLabel15.Text = "Inventory Informations";
            this.guna2HtmlLabel15.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // removebtn
            // 
            this.removebtn.BorderRadius = 5;
            this.removebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.removebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.removebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.removebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.removebtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.removebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.removebtn.ForeColor = System.Drawing.Color.DarkGray;
            this.removebtn.Location = new System.Drawing.Point(96, 526);
            this.removebtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.removebtn.Name = "removebtn";
            this.removebtn.Size = new System.Drawing.Size(145, 46);
            this.removebtn.TabIndex = 259;
            this.removebtn.Text = "Remove";
            this.removebtn.Click += new System.EventHandler(this.removebtn_Click);
            // 
            // addbtn
            // 
            this.addbtn.BorderRadius = 5;
            this.addbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.addbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.addbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.addbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.addbtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.addbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addbtn.ForeColor = System.Drawing.Color.DarkGray;
            this.addbtn.Location = new System.Drawing.Point(96, 462);
            this.addbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(145, 46);
            this.addbtn.TabIndex = 258;
            this.addbtn.Text = "Add";
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // clearbtn
            // 
            this.clearbtn.BorderRadius = 5;
            this.clearbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clearbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clearbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clearbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clearbtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.clearbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clearbtn.ForeColor = System.Drawing.Color.DarkGray;
            this.clearbtn.Location = new System.Drawing.Point(276, 526);
            this.clearbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(145, 46);
            this.clearbtn.TabIndex = 257;
            this.clearbtn.Text = "Clear";
            this.clearbtn.Click += new System.EventHandler(this.clearbtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.BorderRadius = 5;
            this.updatebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updatebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updatebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updatebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updatebtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updatebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updatebtn.ForeColor = System.Drawing.Color.DarkGray;
            this.updatebtn.Location = new System.Drawing.Point(277, 462);
            this.updatebtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(145, 46);
            this.updatebtn.TabIndex = 256;
            this.updatebtn.Text = "Update";
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // guna2CircleButton2
            // 
            this.guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton2.Image")));
            this.guna2CircleButton2.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton2.Location = new System.Drawing.Point(1187, 18);
            this.guna2CircleButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton2.TabIndex = 44;
            this.guna2CircleButton2.Click += new System.EventHandler(this.guna2CircleButton2_Click);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton1.Image")));
            this.guna2CircleButton1.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton1.Location = new System.Drawing.Point(1261, 18);
            this.guna2CircleButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton1.TabIndex = 43;
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2ImageButton3.Location = new System.Drawing.Point(99, 18);
            this.guna2ImageButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Size = new System.Drawing.Size(64, 59);
            this.guna2ImageButton3.TabIndex = 42;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click_1);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(15, 66);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(168, 32);
            this.guna2HtmlLabel2.TabIndex = 41;
            this.guna2HtmlLabel2.Text = "Storekeeper";
            this.guna2HtmlLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(471, 28);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(583, 75);
            this.guna2HtmlLabel1.TabIndex = 40;
            this.guna2HtmlLabel1.Text = "Kitchen & Bedroom";
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button2.Image")));
            this.guna2Button2.ImageSize = new System.Drawing.Size(33, 33);
            this.guna2Button2.Location = new System.Drawing.Point(44, 785);
            this.guna2Button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(152, 57);
            this.guna2Button2.TabIndex = 46;
            this.guna2Button2.Text = "  Logout";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.DarkGray;
            this.guna2Panel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel3.Location = new System.Drawing.Point(253, 791);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(1097, 62);
            this.guna2Panel3.TabIndex = 45;
            // 
            // guna2HtmlToolTip1
            // 
            this.guna2HtmlToolTip1.AllowLinksHandling = true;
            this.guna2HtmlToolTip1.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip2
            // 
            this.guna2HtmlToolTip2.AllowLinksHandling = true;
            this.guna2HtmlToolTip2.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip3
            // 
            this.guna2HtmlToolTip3.AllowLinksHandling = true;
            this.guna2HtmlToolTip3.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip4
            // 
            this.guna2HtmlToolTip4.AllowLinksHandling = true;
            this.guna2HtmlToolTip4.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip5
            // 
            this.guna2HtmlToolTip5.AllowLinksHandling = true;
            this.guna2HtmlToolTip5.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip6
            // 
            this.guna2HtmlToolTip6.AllowLinksHandling = true;
            this.guna2HtmlToolTip6.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlLabel48
            // 
            this.guna2HtmlLabel48.AutoSize = false;
            this.guna2HtmlLabel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel48.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel48.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel48.Location = new System.Drawing.Point(782, 212);
            this.guna2HtmlLabel48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel48.Name = "guna2HtmlLabel48";
            this.guna2HtmlLabel48.Size = new System.Drawing.Size(239, 44);
            this.guna2HtmlLabel48.TabIndex = 282;
            this.guna2HtmlLabel48.Text = "Salary";
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.AutoSize = false;
            this.guna2TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox2.Location = new System.Drawing.Point(880, 170);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.Size = new System.Drawing.Size(194, 98);
            this.guna2TextBox2.TabIndex = 281;
            this.guna2TextBox2.Text = null;
            // 
            // guna2HtmlLabel46
            // 
            this.guna2HtmlLabel46.AutoSize = false;
            this.guna2HtmlLabel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel46.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel46.Location = new System.Drawing.Point(789, 499);
            this.guna2HtmlLabel46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel46.Name = "guna2HtmlLabel46";
            this.guna2HtmlLabel46.Size = new System.Drawing.Size(122, 44);
            this.guna2HtmlLabel46.TabIndex = 280;
            this.guna2HtmlLabel46.Text = "Tasks";
            // 
            // guna2HtmlLabel52
            // 
            this.guna2HtmlLabel52.AutoSize = false;
            this.guna2HtmlLabel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel52.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel52.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel52.Location = new System.Drawing.Point(125, 530);
            this.guna2HtmlLabel52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel52.Name = "guna2HtmlLabel52";
            this.guna2HtmlLabel52.Size = new System.Drawing.Size(327, 44);
            this.guna2HtmlLabel52.TabIndex = 279;
            this.guna2HtmlLabel52.Text = "Alert";
            // 
            // guna2HtmlLabel49
            // 
            this.guna2HtmlLabel49.AutoSize = false;
            this.guna2HtmlLabel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel49.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel49.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel49.Location = new System.Drawing.Point(116, 500);
            this.guna2HtmlLabel49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel49.Name = "guna2HtmlLabel49";
            this.guna2HtmlLabel49.Size = new System.Drawing.Size(349, 44);
            this.guna2HtmlLabel49.TabIndex = 278;
            this.guna2HtmlLabel49.Text = "Meeting";
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.AutoSize = false;
            this.guna2TextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox6.Location = new System.Drawing.Point(237, 456);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.Size = new System.Drawing.Size(785, 82);
            this.guna2TextBox6.TabIndex = 277;
            this.guna2TextBox6.Text = null;
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.AutoSize = false;
            this.guna2TextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox4.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox4.Location = new System.Drawing.Point(899, 435);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox4.TabIndex = 276;
            this.guna2TextBox4.Text = null;
            // 
            // guna2Button8
            // 
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button8.Image")));
            this.guna2Button8.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button8.Location = new System.Drawing.Point(785, 403);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.Size = new System.Drawing.Size(72, 88);
            this.guna2Button8.TabIndex = 275;
            // 
            // guna2Button4
            // 
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button4.Image")));
            this.guna2Button4.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button4.Location = new System.Drawing.Point(102, 409);
            this.guna2Button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.Size = new System.Drawing.Size(105, 89);
            this.guna2Button4.TabIndex = 274;
            // 
            // guna2TileButton5
            // 
            this.guna2TileButton5.BorderRadius = 30;
            this.guna2TileButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton5.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton5.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton5.Location = new System.Drawing.Point(78, 362);
            this.guna2TileButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton5.Name = "guna2TileButton5";
            this.guna2TileButton5.Size = new System.Drawing.Size(635, 226);
            this.guna2TileButton5.TabIndex = 273;
            this.guna2TileButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // guna2TileButton4
            // 
            this.guna2TileButton4.BorderRadius = 30;
            this.guna2TileButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton4.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton4.Location = new System.Drawing.Point(743, 362);
            this.guna2TileButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton4.Name = "guna2TileButton4";
            this.guna2TileButton4.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton4.TabIndex = 272;
            // 
            // guna2HtmlLabel45
            // 
            this.guna2HtmlLabel45.AutoSize = false;
            this.guna2HtmlLabel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel45.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel45.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel45.Location = new System.Drawing.Point(445, 210);
            this.guna2HtmlLabel45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel45.Name = "guna2HtmlLabel45";
            this.guna2HtmlLabel45.Size = new System.Drawing.Size(213, 44);
            this.guna2HtmlLabel45.TabIndex = 271;
            this.guna2HtmlLabel45.Text = "Suppliers\r\n";
            // 
            // guna2HtmlLabel20
            // 
            this.guna2HtmlLabel20.AutoSize = false;
            this.guna2HtmlLabel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel20.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel20.Location = new System.Drawing.Point(102, 210);
            this.guna2HtmlLabel20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel20.Name = "guna2HtmlLabel20";
            this.guna2HtmlLabel20.Size = new System.Drawing.Size(215, 44);
            this.guna2HtmlLabel20.TabIndex = 270;
            this.guna2HtmlLabel20.Text = "Employees";
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.AutoSize = false;
            this.guna2TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox1.Location = new System.Drawing.Point(589, 148);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox1.TabIndex = 269;
            this.guna2TextBox1.Text = null;
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.AutoSize = false;
            this.guna2TextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox3.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox3.Location = new System.Drawing.Point(236, 148);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox3.TabIndex = 268;
            this.guna2TextBox3.Text = null;
            // 
            // guna2Button6
            // 
            this.guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button6.Image")));
            this.guna2Button6.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button6.Location = new System.Drawing.Point(763, 121);
            this.guna2Button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.Size = new System.Drawing.Size(87, 89);
            this.guna2Button6.TabIndex = 267;
            // 
            // guna2TileButton3
            // 
            this.guna2TileButton3.BorderRadius = 30;
            this.guna2TileButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton3.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton3.Location = new System.Drawing.Point(745, 83);
            this.guna2TileButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton3.Name = "guna2TileButton3";
            this.guna2TileButton3.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton3.TabIndex = 266;
            // 
            // guna2Button3
            // 
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.guna2Button3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button3.Image")));
            this.guna2Button3.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button3.Location = new System.Drawing.Point(120, 117);
            this.guna2Button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(71, 89);
            this.guna2Button3.TabIndex = 265;
            this.guna2Button3.UseTransparentBackground = true;
            // 
            // guna2TileButton1
            // 
            this.guna2TileButton1.BorderRadius = 30;
            this.guna2TileButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton1.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton1.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton1.Location = new System.Drawing.Point(80, 83);
            this.guna2TileButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton1.Name = "guna2TileButton1";
            this.guna2TileButton1.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton1.TabIndex = 264;
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button1.Location = new System.Drawing.Point(434, 121);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(120, 89);
            this.guna2Button1.TabIndex = 263;
            // 
            // guna2TileButton2
            // 
            this.guna2TileButton2.BorderRadius = 30;
            this.guna2TileButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton2.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton2.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton2.Location = new System.Drawing.Point(421, 86);
            this.guna2TileButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton2.Name = "guna2TileButton2";
            this.guna2TileButton2.Size = new System.Drawing.Size(281, 226);
            this.guna2TileButton2.TabIndex = 262;
            // 
            // Storekeeper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(1349, 850);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2CircleButton2);
            this.Controls.Add(this.guna2CircleButton1);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.guna2TabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Storekeeper";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Storekeeper";
            this.Load += new System.EventHandler(this.Storekeeper_Load);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.guna2TabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).EndInit();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvinventory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtybox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Button removebtn;
        private Guna.UI2.WinForms.Guna2Button addbtn;
        private Guna.UI2.WinForms.Guna2Button clearbtn;
        private Guna.UI2.WinForms.Guna2Button updatebtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel15;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox supnamebox;
        private Guna.UI2.WinForms.Guna2DateTimePicker datebox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2ComboBox supcmbbox;
        private Guna.UI2.WinForms.Guna2NumericUpDown qtybox;
        private Guna.UI2.WinForms.Guna2ComboBox typecombo;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel16;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel19;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2TextBox productbox;
        private Guna.UI2.WinForms.Guna2DataGridView dgvinventory;
        private Guna.UI2.WinForms.Guna2TextBox accDeadline;
        private Guna.UI2.WinForms.Guna2DataGridView acctask;
        private Guna.UI2.WinForms.Guna2TextBox accPriority;
        private Guna.UI2.WinForms.Guna2ComboBox cmbaccStatuss;
        private Guna.UI2.WinForms.Guna2TextBox accTaskNames;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel40;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel38;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel37;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel36;
        private Guna.UI2.WinForms.Guna2Button updbtnacc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel42;
        private Guna.UI2.WinForms.Guna2DataGridView dgvFeedback;
        private Guna.UI2.WinForms.Guna2Button sendc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel47;
        private Guna.UI2.WinForms.Guna2ComboBox cmbFeedbackType;
        private Guna.UI2.WinForms.Guna2TextBox txtFeedback;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpName;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpId;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel27;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel24;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip1;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip2;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip3;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip4;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip5;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel48;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel46;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel52;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel49;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox4;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton5;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel45;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel20;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox3;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton3;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton2;
    }
}