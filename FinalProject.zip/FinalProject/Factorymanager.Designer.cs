﻿namespace FinalProject
{
    partial class Factorymanager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Factorymanager));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.guna2TileButton7 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton6 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.accDeadline = new Guna.UI2.WinForms.Guna2TextBox();
            this.acctask = new Guna.UI2.WinForms.Guna2DataGridView();
            this.accPriority = new Guna.UI2.WinForms.Guna2TextBox();
            this.cmbaccStatuss = new Guna.UI2.WinForms.Guna2ComboBox();
            this.accTaskNames = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel40 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel38 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel37 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel36 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.updbtnacc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel42 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgvFeedback = new Guna.UI2.WinForms.Guna2DataGridView();
            this.sendc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel47 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbFeedbackType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtFeedback = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel16 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel17 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtEmpName = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtEmpId = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel27 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel24 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvTools = new Guna.UI2.WinForms.Guna2DataGridView();
            this.txtToolName = new Guna.UI2.WinForms.Guna2TextBox();
            this.dateTimePickerLastMaintenance = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.addbtntool = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbToolStatus = new Guna.UI2.WinForms.Guna2ComboBox();
            this.rembtntool = new Guna.UI2.WinForms.Guna2Button();
            this.clrbtntool = new Guna.UI2.WinForms.Guna2Button();
            this.updbtntool = new Guna.UI2.WinForms.Guna2Button();
            this.numericUpDownQuantityNeededs = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel15 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbOrderIds = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbItemNames = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.cmbOrderId = new Guna.UI2.WinForms.Guna2ComboBox();
            this.dgvRawmaterials = new Guna.UI2.WinForms.Guna2DataGridView();
            this.txtRawMaterialName = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtUnitPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.remobtnraw = new Guna.UI2.WinForms.Guna2Button();
            this.addbtnraw = new Guna.UI2.WinForms.Guna2Button();
            this.clrbtnraw = new Guna.UI2.WinForms.Guna2Button();
            this.updbtnraw = new Guna.UI2.WinForms.Guna2Button();
            this.numericUpDownQuantityNeeded = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbItemName = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlToolTip1 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip2 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip3 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip4 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip5 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip6 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlLabel48 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel46 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel52 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel49 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton5 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2HtmlLabel45 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel21 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton3 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton2 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.guna2TabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTools)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantityNeededs)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRawmaterials)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantityNeeded)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage2.Controls.Add(this.guna2TileButton7);
            this.tabPage2.Controls.Add(this.guna2TileButton6);
            this.tabPage2.Location = new System.Drawing.Point(194, 4);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1153, 671);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Inventory Management ";
            // 
            // guna2TileButton7
            // 
            this.guna2TileButton7.BorderRadius = 30;
            this.guna2TileButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton7.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton7.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton7.Location = new System.Drawing.Point(76, 386);
            this.guna2TileButton7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton7.Name = "guna2TileButton7";
            this.guna2TileButton7.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton7.TabIndex = 18;
            this.guna2TileButton7.Text = "Inventory Request";
            this.guna2TileButton7.Click += new System.EventHandler(this.guna2TileButton7_Click);
            // 
            // guna2TileButton6
            // 
            this.guna2TileButton6.BorderRadius = 30;
            this.guna2TileButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold);
            this.guna2TileButton6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton6.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton6.Location = new System.Drawing.Point(76, 161);
            this.guna2TileButton6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton6.Name = "guna2TileButton6";
            this.guna2TileButton6.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton6.TabIndex = 17;
            this.guna2TileButton6.Text = "Inventory Availability";
            this.guna2TileButton6.Click += new System.EventHandler(this.guna2TileButton6_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage3.Controls.Add(this.accDeadline);
            this.tabPage3.Controls.Add(this.acctask);
            this.tabPage3.Controls.Add(this.accPriority);
            this.tabPage3.Controls.Add(this.cmbaccStatuss);
            this.tabPage3.Controls.Add(this.accTaskNames);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel40);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel38);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel37);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel36);
            this.tabPage3.Controls.Add(this.updbtnacc);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel42);
            this.tabPage3.Location = new System.Drawing.Point(194, 4);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1153, 671);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Task Management";
            // 
            // accDeadline
            // 
            this.accDeadline.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accDeadline.BorderRadius = 5;
            this.accDeadline.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accDeadline.DefaultText = "";
            this.accDeadline.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accDeadline.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accDeadline.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accDeadline.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Location = new System.Drawing.Point(194, 158);
            this.accDeadline.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accDeadline.Name = "accDeadline";
            this.accDeadline.PasswordChar = '\0';
            this.accDeadline.PlaceholderText = "";
            this.accDeadline.ReadOnly = true;
            this.accDeadline.SelectedText = "";
            this.accDeadline.Size = new System.Drawing.Size(232, 48);
            this.accDeadline.TabIndex = 266;
            // 
            // acctask
            // 
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            this.acctask.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.acctask.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.acctask.ColumnHeadersHeight = 30;
            this.acctask.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.acctask.DefaultCellStyle = dataGridViewCellStyle23;
            this.acctask.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.Location = new System.Drawing.Point(475, 98);
            this.acctask.Name = "acctask";
            this.acctask.ReadOnly = true;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.acctask.RowHeadersVisible = false;
            this.acctask.RowHeadersWidth = 51;
            dataGridViewCellStyle25.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.acctask.RowsDefaultCellStyle = dataGridViewCellStyle25;
            this.acctask.RowTemplate.Height = 24;
            this.acctask.Size = new System.Drawing.Size(584, 514);
            this.acctask.TabIndex = 265;
            this.acctask.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.acctask.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.acctask.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.acctask.ThemeStyle.HeaderStyle.Height = 30;
            this.acctask.ThemeStyle.ReadOnly = true;
            this.acctask.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.acctask.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.ThemeStyle.RowsStyle.Height = 24;
            this.acctask.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.acctask_CellContentClick);
            // 
            // accPriority
            // 
            this.accPriority.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accPriority.BorderRadius = 5;
            this.accPriority.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accPriority.DefaultText = "";
            this.accPriority.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accPriority.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accPriority.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accPriority.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Location = new System.Drawing.Point(195, 217);
            this.accPriority.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accPriority.Name = "accPriority";
            this.accPriority.PasswordChar = '\0';
            this.accPriority.PlaceholderText = "";
            this.accPriority.ReadOnly = true;
            this.accPriority.SelectedText = "";
            this.accPriority.Size = new System.Drawing.Size(232, 48);
            this.accPriority.TabIndex = 264;
            // 
            // cmbaccStatuss
            // 
            this.cmbaccStatuss.BackColor = System.Drawing.Color.Transparent;
            this.cmbaccStatuss.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbaccStatuss.BorderRadius = 5;
            this.cmbaccStatuss.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbaccStatuss.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbaccStatuss.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbaccStatuss.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbaccStatuss.ItemHeight = 30;
            this.cmbaccStatuss.Items.AddRange(new object[] {
            "Pending",
            "Completed"});
            this.cmbaccStatuss.Location = new System.Drawing.Point(195, 276);
            this.cmbaccStatuss.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbaccStatuss.Name = "cmbaccStatuss";
            this.cmbaccStatuss.Size = new System.Drawing.Size(232, 36);
            this.cmbaccStatuss.TabIndex = 263;
            // 
            // accTaskNames
            // 
            this.accTaskNames.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accTaskNames.BorderRadius = 5;
            this.accTaskNames.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accTaskNames.DefaultText = "";
            this.accTaskNames.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accTaskNames.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accTaskNames.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accTaskNames.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Location = new System.Drawing.Point(195, 98);
            this.accTaskNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accTaskNames.Name = "accTaskNames";
            this.accTaskNames.PasswordChar = '\0';
            this.accTaskNames.PlaceholderText = "";
            this.accTaskNames.ReadOnly = true;
            this.accTaskNames.SelectedText = "";
            this.accTaskNames.Size = new System.Drawing.Size(232, 48);
            this.accTaskNames.TabIndex = 262;
            // 
            // guna2HtmlLabel40
            // 
            this.guna2HtmlLabel40.AutoSize = false;
            this.guna2HtmlLabel40.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel40.Location = new System.Drawing.Point(51, 228);
            this.guna2HtmlLabel40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel40.Name = "guna2HtmlLabel40";
            this.guna2HtmlLabel40.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel40.TabIndex = 261;
            this.guna2HtmlLabel40.Text = "Priority";
            // 
            // guna2HtmlLabel38
            // 
            this.guna2HtmlLabel38.AutoSize = false;
            this.guna2HtmlLabel38.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel38.Location = new System.Drawing.Point(51, 286);
            this.guna2HtmlLabel38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel38.Name = "guna2HtmlLabel38";
            this.guna2HtmlLabel38.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel38.TabIndex = 260;
            this.guna2HtmlLabel38.Text = "Status";
            // 
            // guna2HtmlLabel37
            // 
            this.guna2HtmlLabel37.AutoSize = false;
            this.guna2HtmlLabel37.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel37.Location = new System.Drawing.Point(51, 110);
            this.guna2HtmlLabel37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel37.Name = "guna2HtmlLabel37";
            this.guna2HtmlLabel37.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel37.TabIndex = 259;
            this.guna2HtmlLabel37.Text = "Task Name";
            // 
            // guna2HtmlLabel36
            // 
            this.guna2HtmlLabel36.AutoSize = false;
            this.guna2HtmlLabel36.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel36.Location = new System.Drawing.Point(51, 167);
            this.guna2HtmlLabel36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel36.Name = "guna2HtmlLabel36";
            this.guna2HtmlLabel36.Size = new System.Drawing.Size(245, 39);
            this.guna2HtmlLabel36.TabIndex = 258;
            this.guna2HtmlLabel36.Text = "Deadline";
            // 
            // updbtnacc
            // 
            this.updbtnacc.BorderRadius = 5;
            this.updbtnacc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtnacc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtnacc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtnacc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtnacc.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.Location = new System.Drawing.Point(281, 334);
            this.updbtnacc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtnacc.Name = "updbtnacc";
            this.updbtnacc.Size = new System.Drawing.Size(145, 46);
            this.updbtnacc.TabIndex = 257;
            this.updbtnacc.Text = "Update";
            this.updbtnacc.Click += new System.EventHandler(this.updbtnacc_Click);
            // 
            // guna2HtmlLabel42
            // 
            this.guna2HtmlLabel42.AutoSize = false;
            this.guna2HtmlLabel42.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel42.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel42.Location = new System.Drawing.Point(265, 17);
            this.guna2HtmlLabel42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel42.Name = "guna2HtmlLabel42";
            this.guna2HtmlLabel42.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel42.TabIndex = 256;
            this.guna2HtmlLabel42.Text = "My Tasks";
            this.guna2HtmlLabel42.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage4.Controls.Add(this.dgvFeedback);
            this.tabPage4.Controls.Add(this.sendc);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel47);
            this.tabPage4.Controls.Add(this.cmbFeedbackType);
            this.tabPage4.Controls.Add(this.txtFeedback);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel16);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel17);
            this.tabPage4.Controls.Add(this.txtEmpName);
            this.tabPage4.Controls.Add(this.txtEmpId);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel27);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel24);
            this.tabPage4.Location = new System.Drawing.Point(194, 4);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1153, 671);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Feedback Management";
            // 
            // dgvFeedback
            // 
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvFeedback.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFeedback.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvFeedback.ColumnHeadersHeight = 30;
            this.dgvFeedback.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFeedback.DefaultCellStyle = dataGridViewCellStyle28;
            this.dgvFeedback.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.Location = new System.Drawing.Point(469, 98);
            this.dgvFeedback.Name = "dgvFeedback";
            this.dgvFeedback.ReadOnly = true;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFeedback.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvFeedback.RowHeadersVisible = false;
            this.dgvFeedback.RowHeadersWidth = 51;
            dataGridViewCellStyle30.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvFeedback.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvFeedback.RowTemplate.Height = 24;
            this.dgvFeedback.Size = new System.Drawing.Size(584, 514);
            this.dgvFeedback.TabIndex = 275;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvFeedback.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvFeedback.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvFeedback.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvFeedback.ThemeStyle.ReadOnly = true;
            this.dgvFeedback.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvFeedback.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvFeedback.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvFeedback.ThemeStyle.RowsStyle.Height = 24;
            this.dgvFeedback.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvFeedback.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFeedback_CellContentClick);
            // 
            // sendc
            // 
            this.sendc.BorderRadius = 5;
            this.sendc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.sendc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.sendc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.sendc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.sendc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.sendc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sendc.ForeColor = System.Drawing.Color.DarkGray;
            this.sendc.Location = new System.Drawing.Point(283, 376);
            this.sendc.Name = "sendc";
            this.sendc.Size = new System.Drawing.Size(145, 45);
            this.sendc.TabIndex = 274;
            this.sendc.Text = "Send";
            this.sendc.Click += new System.EventHandler(this.sendc_Click);
            // 
            // guna2HtmlLabel47
            // 
            this.guna2HtmlLabel47.AutoSize = false;
            this.guna2HtmlLabel47.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel47.Location = new System.Drawing.Point(35, 169);
            this.guna2HtmlLabel47.Name = "guna2HtmlLabel47";
            this.guna2HtmlLabel47.Size = new System.Drawing.Size(272, 48);
            this.guna2HtmlLabel47.TabIndex = 273;
            this.guna2HtmlLabel47.Text = "Employee Name";
            // 
            // cmbFeedbackType
            // 
            this.cmbFeedbackType.BackColor = System.Drawing.Color.Transparent;
            this.cmbFeedbackType.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbFeedbackType.BorderRadius = 5;
            this.cmbFeedbackType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbFeedbackType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFeedbackType.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbFeedbackType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbFeedbackType.ItemHeight = 30;
            this.cmbFeedbackType.Items.AddRange(new object[] {
            "Complaint",
            "Suggestion",
            "Inquiry"});
            this.cmbFeedbackType.Location = new System.Drawing.Point(196, 218);
            this.cmbFeedbackType.Name = "cmbFeedbackType";
            this.cmbFeedbackType.Size = new System.Drawing.Size(232, 36);
            this.cmbFeedbackType.TabIndex = 272;
            // 
            // txtFeedback
            // 
            this.txtFeedback.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtFeedback.BorderRadius = 5;
            this.txtFeedback.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFeedback.DefaultText = "";
            this.txtFeedback.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtFeedback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtFeedback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtFeedback.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Location = new System.Drawing.Point(196, 271);
            this.txtFeedback.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.PasswordChar = '\0';
            this.txtFeedback.PlaceholderText = "";
            this.txtFeedback.SelectedText = "";
            this.txtFeedback.Size = new System.Drawing.Size(232, 82);
            this.txtFeedback.TabIndex = 271;
            // 
            // guna2HtmlLabel16
            // 
            this.guna2HtmlLabel16.AutoSize = false;
            this.guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel16.Location = new System.Drawing.Point(35, 226);
            this.guna2HtmlLabel16.Name = "guna2HtmlLabel16";
            this.guna2HtmlLabel16.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel16.TabIndex = 270;
            this.guna2HtmlLabel16.Text = "Feedback Type";
            // 
            // guna2HtmlLabel17
            // 
            this.guna2HtmlLabel17.AutoSize = false;
            this.guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel17.Location = new System.Drawing.Point(35, 112);
            this.guna2HtmlLabel17.Name = "guna2HtmlLabel17";
            this.guna2HtmlLabel17.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel17.TabIndex = 269;
            this.guna2HtmlLabel17.Text = "Employee Id";
            // 
            // txtEmpName
            // 
            this.txtEmpName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpName.BorderRadius = 5;
            this.txtEmpName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpName.DefaultText = "";
            this.txtEmpName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Location = new System.Drawing.Point(196, 155);
            this.txtEmpName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.PasswordChar = '\0';
            this.txtEmpName.PlaceholderText = "";
            this.txtEmpName.ReadOnly = true;
            this.txtEmpName.SelectedText = "";
            this.txtEmpName.Size = new System.Drawing.Size(232, 48);
            this.txtEmpName.TabIndex = 268;
            // 
            // txtEmpId
            // 
            this.txtEmpId.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpId.BorderRadius = 5;
            this.txtEmpId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpId.DefaultText = "";
            this.txtEmpId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Location = new System.Drawing.Point(196, 98);
            this.txtEmpId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.PasswordChar = '\0';
            this.txtEmpId.PlaceholderText = "";
            this.txtEmpId.ReadOnly = true;
            this.txtEmpId.SelectedText = "";
            this.txtEmpId.Size = new System.Drawing.Size(232, 48);
            this.txtEmpId.TabIndex = 267;
            // 
            // guna2HtmlLabel27
            // 
            this.guna2HtmlLabel27.AutoSize = false;
            this.guna2HtmlLabel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel27.Location = new System.Drawing.Point(35, 295);
            this.guna2HtmlLabel27.Name = "guna2HtmlLabel27";
            this.guna2HtmlLabel27.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel27.TabIndex = 266;
            this.guna2HtmlLabel27.Text = "Feedback";
            // 
            // guna2HtmlLabel24
            // 
            this.guna2HtmlLabel24.AutoSize = false;
            this.guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel24.Location = new System.Drawing.Point(300, 17);
            this.guna2HtmlLabel24.Name = "guna2HtmlLabel24";
            this.guna2HtmlLabel24.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel24.TabIndex = 265;
            this.guna2HtmlLabel24.Text = "Send Feedback";
            this.guna2HtmlLabel24.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage5.Controls.Add(this.guna2HtmlLabel48);
            this.tabPage5.Controls.Add(this.guna2TextBox2);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel46);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel52);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel49);
            this.tabPage5.Controls.Add(this.guna2TextBox6);
            this.tabPage5.Controls.Add(this.guna2TextBox4);
            this.tabPage5.Controls.Add(this.guna2Button8);
            this.tabPage5.Controls.Add(this.guna2Button4);
            this.tabPage5.Controls.Add(this.guna2TileButton5);
            this.tabPage5.Controls.Add(this.guna2TileButton4);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel45);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel21);
            this.tabPage5.Controls.Add(this.guna2TextBox1);
            this.tabPage5.Controls.Add(this.guna2TextBox3);
            this.tabPage5.Controls.Add(this.guna2Button6);
            this.tabPage5.Controls.Add(this.guna2TileButton3);
            this.tabPage5.Controls.Add(this.guna2Button3);
            this.tabPage5.Controls.Add(this.guna2TileButton1);
            this.tabPage5.Controls.Add(this.guna2Button1);
            this.tabPage5.Controls.Add(this.guna2TileButton2);
            this.tabPage5.Location = new System.Drawing.Point(194, 4);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1153, 671);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Dashboard";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // guna2TabControl1
            // 
            this.guna2TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.guna2TabControl1.Controls.Add(this.tabPage5);
            this.guna2TabControl1.Controls.Add(this.tabPage3);
            this.guna2TabControl1.Controls.Add(this.tabPage2);
            this.guna2TabControl1.Controls.Add(this.tabPage1);
            this.guna2TabControl1.Controls.Add(this.tabPage6);
            this.guna2TabControl1.Controls.Add(this.tabPage4);
            this.guna2TabControl1.ItemSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.Location = new System.Drawing.Point(0, 114);
            this.guna2TabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TabControl1.Name = "guna2TabControl1";
            this.guna2TabControl1.SelectedIndex = 0;
            this.guna2TabControl1.Size = new System.Drawing.Size(1351, 679);
            this.guna2TabControl1.TabButtonHoverState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonHoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonHoverState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonHoverState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonIdleState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonIdleState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(160)))), ((int)(((byte)(167)))));
            this.guna2TabControl1.TabButtonIdleState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonSelectedState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonSelectedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(37)))), ((int)(((byte)(49)))));
            this.guna2TabControl1.TabButtonSelectedState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonSelectedState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonSelectedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(132)))), ((int)(((byte)(255)))));
            this.guna2TabControl1.TabButtonSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.TabIndex = 32;
            this.guna2TabControl1.TabMenuBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.dgvTools);
            this.tabPage1.Controls.Add(this.txtToolName);
            this.tabPage1.Controls.Add(this.dateTimePickerLastMaintenance);
            this.tabPage1.Controls.Add(this.addbtntool);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel10);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel4);
            this.tabPage1.Controls.Add(this.cmbToolStatus);
            this.tabPage1.Controls.Add(this.rembtntool);
            this.tabPage1.Controls.Add(this.clrbtntool);
            this.tabPage1.Controls.Add(this.updbtntool);
            this.tabPage1.Controls.Add(this.numericUpDownQuantityNeededs);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel15);
            this.tabPage1.Controls.Add(this.cmbOrderIds);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel9);
            this.tabPage1.Controls.Add(this.cmbItemNames);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel6);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel7);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel8);
            this.tabPage1.Location = new System.Drawing.Point(194, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1153, 671);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "Tools Management";
            // 
            // dgvTools
            // 
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.White;
            this.dgvTools.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvTools.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTools.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.dgvTools.ColumnHeadersHeight = 40;
            this.dgvTools.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTools.DefaultCellStyle = dataGridViewCellStyle33;
            this.dgvTools.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvTools.Location = new System.Drawing.Point(513, 101);
            this.dgvTools.Name = "dgvTools";
            this.dgvTools.ReadOnly = true;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTools.RowHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgvTools.RowHeadersVisible = false;
            this.dgvTools.RowHeadersWidth = 51;
            dataGridViewCellStyle35.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvTools.RowsDefaultCellStyle = dataGridViewCellStyle35;
            this.dgvTools.RowTemplate.Height = 24;
            this.dgvTools.Size = new System.Drawing.Size(565, 514);
            this.dgvTools.TabIndex = 267;
            this.dgvTools.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvTools.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvTools.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvTools.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvTools.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvTools.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvTools.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvTools.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvTools.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvTools.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTools.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvTools.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvTools.ThemeStyle.HeaderStyle.Height = 40;
            this.dgvTools.ThemeStyle.ReadOnly = true;
            this.dgvTools.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvTools.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvTools.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTools.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvTools.ThemeStyle.RowsStyle.Height = 24;
            this.dgvTools.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvTools.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvTools.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTools_CellContentClick);
            // 
            // txtToolName
            // 
            this.txtToolName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtToolName.BorderRadius = 5;
            this.txtToolName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtToolName.DefaultText = "";
            this.txtToolName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtToolName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtToolName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtToolName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtToolName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtToolName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtToolName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtToolName.Location = new System.Drawing.Point(252, 213);
            this.txtToolName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtToolName.Name = "txtToolName";
            this.txtToolName.PasswordChar = '\0';
            this.txtToolName.PlaceholderText = "";
            this.txtToolName.SelectedText = "";
            this.txtToolName.Size = new System.Drawing.Size(232, 48);
            this.txtToolName.TabIndex = 252;
            // 
            // dateTimePickerLastMaintenance
            // 
            this.dateTimePickerLastMaintenance.BackColor = System.Drawing.Color.Transparent;
            this.dateTimePickerLastMaintenance.BorderRadius = 5;
            this.dateTimePickerLastMaintenance.BorderThickness = 1;
            this.dateTimePickerLastMaintenance.Checked = true;
            this.dateTimePickerLastMaintenance.FillColor = System.Drawing.Color.White;
            this.dateTimePickerLastMaintenance.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dateTimePickerLastMaintenance.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerLastMaintenance.Location = new System.Drawing.Point(251, 389);
            this.dateTimePickerLastMaintenance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePickerLastMaintenance.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerLastMaintenance.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerLastMaintenance.Name = "dateTimePickerLastMaintenance";
            this.dateTimePickerLastMaintenance.Size = new System.Drawing.Size(233, 48);
            this.dateTimePickerLastMaintenance.TabIndex = 240;
            this.dateTimePickerLastMaintenance.Value = new System.DateTime(2024, 10, 3, 6, 26, 41, 707);
            // 
            // addbtntool
            // 
            this.addbtntool.BorderRadius = 5;
            this.addbtntool.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.addbtntool.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.addbtntool.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.addbtntool.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.addbtntool.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.addbtntool.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addbtntool.ForeColor = System.Drawing.Color.DarkGray;
            this.addbtntool.Location = new System.Drawing.Point(96, 474);
            this.addbtntool.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addbtntool.Name = "addbtntool";
            this.addbtntool.Size = new System.Drawing.Size(145, 46);
            this.addbtntool.TabIndex = 239;
            this.addbtntool.Text = "Add";
            this.addbtntool.Click += new System.EventHandler(this.addbtntool_Click);
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.AutoSize = false;
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(28, 400);
            this.guna2HtmlLabel10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(394, 39);
            this.guna2HtmlLabel10.TabIndex = 238;
            this.guna2HtmlLabel10.Text = "Last Maintenance Date";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.AutoSize = false;
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(28, 342);
            this.guna2HtmlLabel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(217, 39);
            this.guna2HtmlLabel4.TabIndex = 237;
            this.guna2HtmlLabel4.Text = "Status";
            // 
            // cmbToolStatus
            // 
            this.cmbToolStatus.BackColor = System.Drawing.Color.Transparent;
            this.cmbToolStatus.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbToolStatus.BorderRadius = 5;
            this.cmbToolStatus.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbToolStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbToolStatus.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbToolStatus.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbToolStatus.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbToolStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbToolStatus.ItemHeight = 30;
            this.cmbToolStatus.Items.AddRange(new object[] {
            "Available",
            "In Use",
            "Under Maintenance"});
            this.cmbToolStatus.Location = new System.Drawing.Point(251, 334);
            this.cmbToolStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbToolStatus.Name = "cmbToolStatus";
            this.cmbToolStatus.Size = new System.Drawing.Size(231, 36);
            this.cmbToolStatus.TabIndex = 236;
            // 
            // rembtntool
            // 
            this.rembtntool.BorderRadius = 5;
            this.rembtntool.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.rembtntool.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.rembtntool.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.rembtntool.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.rembtntool.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.rembtntool.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.rembtntool.ForeColor = System.Drawing.Color.DarkGray;
            this.rembtntool.Location = new System.Drawing.Point(96, 538);
            this.rembtntool.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rembtntool.Name = "rembtntool";
            this.rembtntool.Size = new System.Drawing.Size(145, 46);
            this.rembtntool.TabIndex = 234;
            this.rembtntool.Text = "Remove";
            this.rembtntool.Click += new System.EventHandler(this.rembtntool_Click);
            // 
            // clrbtntool
            // 
            this.clrbtntool.BorderRadius = 5;
            this.clrbtntool.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clrbtntool.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clrbtntool.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clrbtntool.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clrbtntool.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.clrbtntool.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clrbtntool.ForeColor = System.Drawing.Color.DarkGray;
            this.clrbtntool.Location = new System.Drawing.Point(277, 538);
            this.clrbtntool.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clrbtntool.Name = "clrbtntool";
            this.clrbtntool.Size = new System.Drawing.Size(145, 46);
            this.clrbtntool.TabIndex = 232;
            this.clrbtntool.Text = "Clear";
            this.clrbtntool.Click += new System.EventHandler(this.clrbtntool_Click);
            // 
            // updbtntool
            // 
            this.updbtntool.BorderRadius = 5;
            this.updbtntool.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtntool.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtntool.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtntool.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtntool.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtntool.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtntool.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtntool.Location = new System.Drawing.Point(277, 474);
            this.updbtntool.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtntool.Name = "updbtntool";
            this.updbtntool.Size = new System.Drawing.Size(145, 46);
            this.updbtntool.TabIndex = 231;
            this.updbtntool.Text = "Update";
            this.updbtntool.Click += new System.EventHandler(this.updbtntool_Click);
            // 
            // numericUpDownQuantityNeededs
            // 
            this.numericUpDownQuantityNeededs.BackColor = System.Drawing.Color.Transparent;
            this.numericUpDownQuantityNeededs.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.numericUpDownQuantityNeededs.BorderRadius = 5;
            this.numericUpDownQuantityNeededs.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numericUpDownQuantityNeededs.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numericUpDownQuantityNeededs.Location = new System.Drawing.Point(251, 271);
            this.numericUpDownQuantityNeededs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownQuantityNeededs.Name = "numericUpDownQuantityNeededs";
            this.numericUpDownQuantityNeededs.Size = new System.Drawing.Size(231, 48);
            this.numericUpDownQuantityNeededs.TabIndex = 202;
            // 
            // guna2HtmlLabel15
            // 
            this.guna2HtmlLabel15.AutoSize = false;
            this.guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel15.Location = new System.Drawing.Point(28, 109);
            this.guna2HtmlLabel15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel15.Name = "guna2HtmlLabel15";
            this.guna2HtmlLabel15.Size = new System.Drawing.Size(217, 34);
            this.guna2HtmlLabel15.TabIndex = 200;
            this.guna2HtmlLabel15.Text = "Item Name";
            // 
            // cmbOrderIds
            // 
            this.cmbOrderIds.BackColor = System.Drawing.Color.Transparent;
            this.cmbOrderIds.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbOrderIds.BorderRadius = 5;
            this.cmbOrderIds.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbOrderIds.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOrderIds.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbOrderIds.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbOrderIds.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbOrderIds.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbOrderIds.ItemHeight = 30;
            this.cmbOrderIds.Location = new System.Drawing.Point(251, 158);
            this.cmbOrderIds.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbOrderIds.Name = "cmbOrderIds";
            this.cmbOrderIds.Size = new System.Drawing.Size(231, 36);
            this.cmbOrderIds.TabIndex = 199;
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(28, 164);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(217, 34);
            this.guna2HtmlLabel9.TabIndex = 198;
            this.guna2HtmlLabel9.Text = "Order ID";
            // 
            // cmbItemNames
            // 
            this.cmbItemNames.BackColor = System.Drawing.Color.Transparent;
            this.cmbItemNames.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbItemNames.BorderRadius = 5;
            this.cmbItemNames.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbItemNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItemNames.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbItemNames.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbItemNames.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbItemNames.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbItemNames.ItemHeight = 30;
            this.cmbItemNames.Location = new System.Drawing.Point(251, 101);
            this.cmbItemNames.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbItemNames.Name = "cmbItemNames";
            this.cmbItemNames.Size = new System.Drawing.Size(231, 36);
            this.cmbItemNames.TabIndex = 197;
            this.cmbItemNames.SelectedIndexChanged += new System.EventHandler(this.cmbItemNames_SelectedIndexChanged);
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.AutoSize = false;
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(28, 224);
            this.guna2HtmlLabel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel6.TabIndex = 185;
            this.guna2HtmlLabel6.Text = "Tool Name";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.AutoSize = false;
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(28, 281);
            this.guna2HtmlLabel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(245, 39);
            this.guna2HtmlLabel7.TabIndex = 184;
            this.guna2HtmlLabel7.Text = "Quantity";
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.AutoSize = false;
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(288, 16);
            this.guna2HtmlLabel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel8.TabIndex = 181;
            this.guna2HtmlLabel8.Text = "Tool Informations";
            this.guna2HtmlLabel8.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage6.Controls.Add(this.cmbOrderId);
            this.tabPage6.Controls.Add(this.dgvRawmaterials);
            this.tabPage6.Controls.Add(this.txtRawMaterialName);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel14);
            this.tabPage6.Controls.Add(this.txtUnitPrice);
            this.tabPage6.Controls.Add(this.remobtnraw);
            this.tabPage6.Controls.Add(this.addbtnraw);
            this.tabPage6.Controls.Add(this.clrbtnraw);
            this.tabPage6.Controls.Add(this.updbtnraw);
            this.tabPage6.Controls.Add(this.numericUpDownQuantityNeeded);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel3);
            this.tabPage6.Controls.Add(this.cmbItemName);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel5);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel11);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel12);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel13);
            this.tabPage6.Location = new System.Drawing.Point(194, 4);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1153, 671);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "Raw Materials Management";
            this.tabPage6.Click += new System.EventHandler(this.tabPage6_Click);
            // 
            // cmbOrderId
            // 
            this.cmbOrderId.BackColor = System.Drawing.Color.Transparent;
            this.cmbOrderId.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbOrderId.BorderRadius = 5;
            this.cmbOrderId.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbOrderId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOrderId.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbOrderId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbOrderId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbOrderId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbOrderId.ItemHeight = 30;
            this.cmbOrderId.Location = new System.Drawing.Point(224, 155);
            this.cmbOrderId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbOrderId.Name = "cmbOrderId";
            this.cmbOrderId.Size = new System.Drawing.Size(231, 36);
            this.cmbOrderId.TabIndex = 267;
            // 
            // dgvRawmaterials
            // 
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.White;
            this.dgvRawmaterials.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle36;
            this.dgvRawmaterials.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRawmaterials.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvRawmaterials.ColumnHeadersHeight = 30;
            this.dgvRawmaterials.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRawmaterials.DefaultCellStyle = dataGridViewCellStyle38;
            this.dgvRawmaterials.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvRawmaterials.Location = new System.Drawing.Point(487, 101);
            this.dgvRawmaterials.Name = "dgvRawmaterials";
            this.dgvRawmaterials.ReadOnly = true;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle39.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRawmaterials.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvRawmaterials.RowHeadersVisible = false;
            this.dgvRawmaterials.RowHeadersWidth = 51;
            dataGridViewCellStyle40.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvRawmaterials.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.dgvRawmaterials.RowTemplate.Height = 24;
            this.dgvRawmaterials.Size = new System.Drawing.Size(565, 514);
            this.dgvRawmaterials.TabIndex = 266;
            this.dgvRawmaterials.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvRawmaterials.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvRawmaterials.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvRawmaterials.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvRawmaterials.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvRawmaterials.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvRawmaterials.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvRawmaterials.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvRawmaterials.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvRawmaterials.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvRawmaterials.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvRawmaterials.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvRawmaterials.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvRawmaterials.ThemeStyle.ReadOnly = true;
            this.dgvRawmaterials.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvRawmaterials.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvRawmaterials.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvRawmaterials.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvRawmaterials.ThemeStyle.RowsStyle.Height = 24;
            this.dgvRawmaterials.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvRawmaterials.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvRawmaterials.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRawmaterials_CellContentClick);
            // 
            // txtRawMaterialName
            // 
            this.txtRawMaterialName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtRawMaterialName.BorderRadius = 5;
            this.txtRawMaterialName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRawMaterialName.DefaultText = "";
            this.txtRawMaterialName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtRawMaterialName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtRawMaterialName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtRawMaterialName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtRawMaterialName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRawMaterialName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtRawMaterialName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRawMaterialName.Location = new System.Drawing.Point(223, 211);
            this.txtRawMaterialName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRawMaterialName.Name = "txtRawMaterialName";
            this.txtRawMaterialName.PasswordChar = '\0';
            this.txtRawMaterialName.PlaceholderText = "";
            this.txtRawMaterialName.SelectedText = "";
            this.txtRawMaterialName.Size = new System.Drawing.Size(232, 48);
            this.txtRawMaterialName.TabIndex = 251;
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.AutoSize = false;
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(30, 341);
            this.guna2HtmlLabel14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(164, 39);
            this.guna2HtmlLabel14.TabIndex = 250;
            this.guna2HtmlLabel14.Text = "Unit Price";
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtUnitPrice.BorderRadius = 5;
            this.txtUnitPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtUnitPrice.DefaultText = "";
            this.txtUnitPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtUnitPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtUnitPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUnitPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUnitPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUnitPrice.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtUnitPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUnitPrice.Location = new System.Drawing.Point(222, 329);
            this.txtUnitPrice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.PasswordChar = '\0';
            this.txtUnitPrice.PlaceholderText = "";
            this.txtUnitPrice.SelectedText = "";
            this.txtUnitPrice.Size = new System.Drawing.Size(232, 48);
            this.txtUnitPrice.TabIndex = 249;
            this.txtUnitPrice.TextChanged += new System.EventHandler(this.txtUnitPrice_TextChanged);
            // 
            // remobtnraw
            // 
            this.remobtnraw.BorderRadius = 5;
            this.remobtnraw.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.remobtnraw.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.remobtnraw.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.remobtnraw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.remobtnraw.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.remobtnraw.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.remobtnraw.ForeColor = System.Drawing.Color.DarkGray;
            this.remobtnraw.Location = new System.Drawing.Point(85, 478);
            this.remobtnraw.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.remobtnraw.Name = "remobtnraw";
            this.remobtnraw.Size = new System.Drawing.Size(145, 46);
            this.remobtnraw.TabIndex = 248;
            this.remobtnraw.Text = "Remove";
            this.remobtnraw.Click += new System.EventHandler(this.remobtnraw_Click);
            // 
            // addbtnraw
            // 
            this.addbtnraw.BorderRadius = 5;
            this.addbtnraw.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.addbtnraw.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.addbtnraw.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.addbtnraw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.addbtnraw.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.addbtnraw.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addbtnraw.ForeColor = System.Drawing.Color.DarkGray;
            this.addbtnraw.Location = new System.Drawing.Point(85, 414);
            this.addbtnraw.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addbtnraw.Name = "addbtnraw";
            this.addbtnraw.Size = new System.Drawing.Size(145, 46);
            this.addbtnraw.TabIndex = 247;
            this.addbtnraw.Text = "Add";
            this.addbtnraw.Click += new System.EventHandler(this.addbtnraw_Click);
            // 
            // clrbtnraw
            // 
            this.clrbtnraw.BorderRadius = 5;
            this.clrbtnraw.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clrbtnraw.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clrbtnraw.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clrbtnraw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clrbtnraw.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.clrbtnraw.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clrbtnraw.ForeColor = System.Drawing.Color.DarkGray;
            this.clrbtnraw.Location = new System.Drawing.Point(267, 478);
            this.clrbtnraw.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clrbtnraw.Name = "clrbtnraw";
            this.clrbtnraw.Size = new System.Drawing.Size(145, 46);
            this.clrbtnraw.TabIndex = 246;
            this.clrbtnraw.Text = "Clear";
            this.clrbtnraw.Click += new System.EventHandler(this.clrbtnraw_Click);
            // 
            // updbtnraw
            // 
            this.updbtnraw.BorderRadius = 5;
            this.updbtnraw.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtnraw.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtnraw.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtnraw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtnraw.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtnraw.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtnraw.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtnraw.Location = new System.Drawing.Point(267, 414);
            this.updbtnraw.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtnraw.Name = "updbtnraw";
            this.updbtnraw.Size = new System.Drawing.Size(145, 46);
            this.updbtnraw.TabIndex = 245;
            this.updbtnraw.Text = "Update";
            this.updbtnraw.Click += new System.EventHandler(this.updbtnraw_Click);
            // 
            // numericUpDownQuantityNeeded
            // 
            this.numericUpDownQuantityNeeded.BackColor = System.Drawing.Color.Transparent;
            this.numericUpDownQuantityNeeded.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.numericUpDownQuantityNeeded.BorderRadius = 5;
            this.numericUpDownQuantityNeeded.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numericUpDownQuantityNeeded.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numericUpDownQuantityNeeded.Location = new System.Drawing.Point(222, 272);
            this.numericUpDownQuantityNeeded.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownQuantityNeeded.Name = "numericUpDownQuantityNeeded";
            this.numericUpDownQuantityNeeded.Size = new System.Drawing.Size(231, 48);
            this.numericUpDownQuantityNeeded.TabIndex = 243;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.AutoSize = false;
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(31, 110);
            this.guna2HtmlLabel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(180, 34);
            this.guna2HtmlLabel3.TabIndex = 241;
            this.guna2HtmlLabel3.Text = "Item Name";
            // 
            // cmbItemName
            // 
            this.cmbItemName.BackColor = System.Drawing.Color.Transparent;
            this.cmbItemName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbItemName.BorderRadius = 5;
            this.cmbItemName.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbItemName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItemName.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbItemName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbItemName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbItemName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbItemName.ItemHeight = 30;
            this.cmbItemName.Location = new System.Drawing.Point(224, 101);
            this.cmbItemName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbItemName.Name = "cmbItemName";
            this.cmbItemName.Size = new System.Drawing.Size(231, 36);
            this.cmbItemName.TabIndex = 240;
            this.cmbItemName.SelectedIndexChanged += new System.EventHandler(this.cmbItemName_SelectedIndexChanged);
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.AutoSize = false;
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(30, 166);
            this.guna2HtmlLabel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(180, 34);
            this.guna2HtmlLabel5.TabIndex = 239;
            this.guna2HtmlLabel5.Text = "Order ID";
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.AutoSize = false;
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(30, 224);
            this.guna2HtmlLabel11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(339, 34);
            this.guna2HtmlLabel11.TabIndex = 237;
            this.guna2HtmlLabel11.Text = "Raw Material Name";
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.AutoSize = false;
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(30, 287);
            this.guna2HtmlLabel12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(245, 39);
            this.guna2HtmlLabel12.TabIndex = 236;
            this.guna2HtmlLabel12.Text = "Quantity";
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.AutoSize = false;
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(183, 17);
            this.guna2HtmlLabel13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(1021, 48);
            this.guna2HtmlLabel13.TabIndex = 235;
            this.guna2HtmlLabel13.Text = "Raw Material Informations";
            this.guna2HtmlLabel13.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // guna2CircleButton2
            // 
            this.guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton2.Image")));
            this.guna2CircleButton2.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton2.Location = new System.Drawing.Point(1187, 18);
            this.guna2CircleButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton2.TabIndex = 37;
            this.guna2CircleButton2.Click += new System.EventHandler(this.guna2CircleButton2_Click);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton1.Image")));
            this.guna2CircleButton1.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton1.Location = new System.Drawing.Point(1261, 18);
            this.guna2CircleButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton1.TabIndex = 36;
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2ImageButton3.Location = new System.Drawing.Point(99, 18);
            this.guna2ImageButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Size = new System.Drawing.Size(64, 59);
            this.guna2ImageButton3.TabIndex = 35;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click_1);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(-44, 65);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(269, 39);
            this.guna2HtmlLabel2.TabIndex = 34;
            this.guna2HtmlLabel2.Text = "Factory Manager";
            this.guna2HtmlLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(471, 28);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(583, 75);
            this.guna2HtmlLabel1.TabIndex = 33;
            this.guna2HtmlLabel1.Text = "Kitchen & Bedroom";
            // 
            // guna2Button7
            // 
            this.guna2Button7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button7.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button7.Image")));
            this.guna2Button7.ImageSize = new System.Drawing.Size(33, 33);
            this.guna2Button7.Location = new System.Drawing.Point(44, 785);
            this.guna2Button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.Size = new System.Drawing.Size(152, 57);
            this.guna2Button7.TabIndex = 39;
            this.guna2Button7.Text = "  Logout";
            this.guna2Button7.Click += new System.EventHandler(this.guna2Button7_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.DarkGray;
            this.guna2Panel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel3.Location = new System.Drawing.Point(253, 791);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(1097, 62);
            this.guna2Panel3.TabIndex = 38;
            // 
            // guna2HtmlToolTip1
            // 
            this.guna2HtmlToolTip1.AllowLinksHandling = true;
            this.guna2HtmlToolTip1.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip2
            // 
            this.guna2HtmlToolTip2.AllowLinksHandling = true;
            this.guna2HtmlToolTip2.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip3
            // 
            this.guna2HtmlToolTip3.AllowLinksHandling = true;
            this.guna2HtmlToolTip3.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip4
            // 
            this.guna2HtmlToolTip4.AllowLinksHandling = true;
            this.guna2HtmlToolTip4.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip5
            // 
            this.guna2HtmlToolTip5.AllowLinksHandling = true;
            this.guna2HtmlToolTip5.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip6
            // 
            this.guna2HtmlToolTip6.AllowLinksHandling = true;
            this.guna2HtmlToolTip6.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlLabel48
            // 
            this.guna2HtmlLabel48.AutoSize = false;
            this.guna2HtmlLabel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel48.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel48.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel48.Location = new System.Drawing.Point(782, 212);
            this.guna2HtmlLabel48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel48.Name = "guna2HtmlLabel48";
            this.guna2HtmlLabel48.Size = new System.Drawing.Size(239, 44);
            this.guna2HtmlLabel48.TabIndex = 303;
            this.guna2HtmlLabel48.Text = "Salary";
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.AutoSize = false;
            this.guna2TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox2.Location = new System.Drawing.Point(880, 170);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.Size = new System.Drawing.Size(194, 98);
            this.guna2TextBox2.TabIndex = 302;
            this.guna2TextBox2.Text = null;
            // 
            // guna2HtmlLabel46
            // 
            this.guna2HtmlLabel46.AutoSize = false;
            this.guna2HtmlLabel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel46.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel46.Location = new System.Drawing.Point(789, 499);
            this.guna2HtmlLabel46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel46.Name = "guna2HtmlLabel46";
            this.guna2HtmlLabel46.Size = new System.Drawing.Size(122, 44);
            this.guna2HtmlLabel46.TabIndex = 301;
            this.guna2HtmlLabel46.Text = "Tasks";
            // 
            // guna2HtmlLabel52
            // 
            this.guna2HtmlLabel52.AutoSize = false;
            this.guna2HtmlLabel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel52.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel52.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel52.Location = new System.Drawing.Point(125, 530);
            this.guna2HtmlLabel52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel52.Name = "guna2HtmlLabel52";
            this.guna2HtmlLabel52.Size = new System.Drawing.Size(327, 44);
            this.guna2HtmlLabel52.TabIndex = 300;
            this.guna2HtmlLabel52.Text = "Alert";
            // 
            // guna2HtmlLabel49
            // 
            this.guna2HtmlLabel49.AutoSize = false;
            this.guna2HtmlLabel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel49.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel49.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel49.Location = new System.Drawing.Point(116, 500);
            this.guna2HtmlLabel49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel49.Name = "guna2HtmlLabel49";
            this.guna2HtmlLabel49.Size = new System.Drawing.Size(349, 44);
            this.guna2HtmlLabel49.TabIndex = 299;
            this.guna2HtmlLabel49.Text = "Meeting";
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.AutoSize = false;
            this.guna2TextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox6.Location = new System.Drawing.Point(237, 456);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.Size = new System.Drawing.Size(785, 82);
            this.guna2TextBox6.TabIndex = 298;
            this.guna2TextBox6.Text = null;
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.AutoSize = false;
            this.guna2TextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox4.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox4.Location = new System.Drawing.Point(899, 435);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox4.TabIndex = 297;
            this.guna2TextBox4.Text = null;
            // 
            // guna2Button8
            // 
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button8.Image")));
            this.guna2Button8.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button8.Location = new System.Drawing.Point(785, 403);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.Size = new System.Drawing.Size(72, 88);
            this.guna2Button8.TabIndex = 296;
            // 
            // guna2Button4
            // 
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button4.Image")));
            this.guna2Button4.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button4.Location = new System.Drawing.Point(102, 409);
            this.guna2Button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.Size = new System.Drawing.Size(105, 89);
            this.guna2Button4.TabIndex = 295;
            // 
            // guna2TileButton5
            // 
            this.guna2TileButton5.BorderRadius = 30;
            this.guna2TileButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton5.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton5.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton5.Location = new System.Drawing.Point(78, 362);
            this.guna2TileButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton5.Name = "guna2TileButton5";
            this.guna2TileButton5.Size = new System.Drawing.Size(635, 226);
            this.guna2TileButton5.TabIndex = 294;
            this.guna2TileButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // guna2TileButton4
            // 
            this.guna2TileButton4.BorderRadius = 30;
            this.guna2TileButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton4.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton4.Location = new System.Drawing.Point(743, 362);
            this.guna2TileButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton4.Name = "guna2TileButton4";
            this.guna2TileButton4.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton4.TabIndex = 293;
            // 
            // guna2HtmlLabel45
            // 
            this.guna2HtmlLabel45.AutoSize = false;
            this.guna2HtmlLabel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel45.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel45.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel45.Location = new System.Drawing.Point(445, 210);
            this.guna2HtmlLabel45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel45.Name = "guna2HtmlLabel45";
            this.guna2HtmlLabel45.Size = new System.Drawing.Size(213, 44);
            this.guna2HtmlLabel45.TabIndex = 292;
            this.guna2HtmlLabel45.Text = "Suppliers\r\n";
            // 
            // guna2HtmlLabel21
            // 
            this.guna2HtmlLabel21.AutoSize = false;
            this.guna2HtmlLabel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel21.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel21.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel21.Location = new System.Drawing.Point(102, 210);
            this.guna2HtmlLabel21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel21.Name = "guna2HtmlLabel21";
            this.guna2HtmlLabel21.Size = new System.Drawing.Size(215, 44);
            this.guna2HtmlLabel21.TabIndex = 291;
            this.guna2HtmlLabel21.Text = "Employees";
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.AutoSize = false;
            this.guna2TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox1.Location = new System.Drawing.Point(589, 148);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox1.TabIndex = 290;
            this.guna2TextBox1.Text = null;
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.AutoSize = false;
            this.guna2TextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox3.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox3.Location = new System.Drawing.Point(236, 148);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox3.TabIndex = 289;
            this.guna2TextBox3.Text = null;
            // 
            // guna2Button6
            // 
            this.guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button6.Image")));
            this.guna2Button6.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button6.Location = new System.Drawing.Point(763, 121);
            this.guna2Button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.Size = new System.Drawing.Size(87, 89);
            this.guna2Button6.TabIndex = 288;
            // 
            // guna2TileButton3
            // 
            this.guna2TileButton3.BorderRadius = 30;
            this.guna2TileButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton3.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton3.Location = new System.Drawing.Point(745, 83);
            this.guna2TileButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton3.Name = "guna2TileButton3";
            this.guna2TileButton3.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton3.TabIndex = 287;
            // 
            // guna2Button3
            // 
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.guna2Button3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button3.Image")));
            this.guna2Button3.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button3.Location = new System.Drawing.Point(120, 117);
            this.guna2Button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(71, 89);
            this.guna2Button3.TabIndex = 286;
            this.guna2Button3.UseTransparentBackground = true;
            // 
            // guna2TileButton1
            // 
            this.guna2TileButton1.BorderRadius = 30;
            this.guna2TileButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton1.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton1.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton1.Location = new System.Drawing.Point(80, 83);
            this.guna2TileButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton1.Name = "guna2TileButton1";
            this.guna2TileButton1.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton1.TabIndex = 285;
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button1.Location = new System.Drawing.Point(434, 121);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(120, 89);
            this.guna2Button1.TabIndex = 284;
            // 
            // guna2TileButton2
            // 
            this.guna2TileButton2.BorderRadius = 30;
            this.guna2TileButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton2.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton2.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton2.Location = new System.Drawing.Point(421, 86);
            this.guna2TileButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton2.Name = "guna2TileButton2";
            this.guna2TileButton2.Size = new System.Drawing.Size(281, 226);
            this.guna2TileButton2.TabIndex = 283;
            // 
            // Factorymanager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(1349, 850);
            this.Controls.Add(this.guna2Button7);
            this.Controls.Add(this.guna2CircleButton2);
            this.Controls.Add(this.guna2CircleButton1);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.guna2TabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Factorymanager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Factorymanager";
            this.Load += new System.EventHandler(this.Factorymanager_Load);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.guna2TabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTools)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantityNeededs)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRawmaterials)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantityNeeded)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton7;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton6;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel15;
        private Guna.UI2.WinForms.Guna2ComboBox cmbOrderIds;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2ComboBox cmbItemNames;
        private Guna.UI2.WinForms.Guna2NumericUpDown numericUpDownQuantityNeededs;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Button rembtntool;
        private Guna.UI2.WinForms.Guna2Button clrbtntool;
        private Guna.UI2.WinForms.Guna2Button updbtntool;
        private Guna.UI2.WinForms.Guna2Button remobtnraw;
        private Guna.UI2.WinForms.Guna2Button addbtnraw;
        private Guna.UI2.WinForms.Guna2Button clrbtnraw;
        private Guna.UI2.WinForms.Guna2Button updbtnraw;
        private Guna.UI2.WinForms.Guna2NumericUpDown numericUpDownQuantityNeeded;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2ComboBox cmbItemName;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2TextBox txtUnitPrice;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2ComboBox cmbToolStatus;
        private Guna.UI2.WinForms.Guna2TextBox accDeadline;
        private Guna.UI2.WinForms.Guna2DataGridView acctask;
        private Guna.UI2.WinForms.Guna2TextBox accPriority;
        private Guna.UI2.WinForms.Guna2ComboBox cmbaccStatuss;
        private Guna.UI2.WinForms.Guna2TextBox accTaskNames;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel40;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel38;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel37;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel36;
        private Guna.UI2.WinForms.Guna2Button updbtnacc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel42;
        private Guna.UI2.WinForms.Guna2DataGridView dgvFeedback;
        private Guna.UI2.WinForms.Guna2Button sendc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel47;
        private Guna.UI2.WinForms.Guna2ComboBox cmbFeedbackType;
        private Guna.UI2.WinForms.Guna2TextBox txtFeedback;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel16;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel17;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpName;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpId;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel27;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel24;
        private Guna.UI2.WinForms.Guna2DateTimePicker dateTimePickerLastMaintenance;
        private Guna.UI2.WinForms.Guna2Button addbtntool;
        private Guna.UI2.WinForms.Guna2TextBox txtRawMaterialName;
        private Guna.UI2.WinForms.Guna2DataGridView dgvRawmaterials;
        private Guna.UI2.WinForms.Guna2TextBox txtToolName;
        private Guna.UI2.WinForms.Guna2ComboBox cmbOrderId;
        private Guna.UI2.WinForms.Guna2DataGridView dgvTools;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip1;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip2;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip3;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip4;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip5;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel48;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel46;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel52;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel49;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox4;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton5;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel45;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel21;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox3;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton3;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton2;
    }
}