﻿namespace FinalProject
{
    partial class COO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(COO));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.guna2HtmlLabel48 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel46 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel52 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel49 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton5 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2HtmlLabel45 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel44 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton3 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton2 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.accDeadline = new Guna.UI2.WinForms.Guna2TextBox();
            this.acctask = new Guna.UI2.WinForms.Guna2DataGridView();
            this.accPriority = new Guna.UI2.WinForms.Guna2TextBox();
            this.cmbaccStatuss = new Guna.UI2.WinForms.Guna2ComboBox();
            this.accTaskNames = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel40 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel38 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel37 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel36 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.updbtnacc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel42 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dgvSupplier = new Guna.UI2.WinForms.Guna2DataGridView();
            this.addbtnsup = new Guna.UI2.WinForms.Guna2Button();
            this.rembtnsup = new Guna.UI2.WinForms.Guna2Button();
            this.clrbtnsup = new Guna.UI2.WinForms.Guna2Button();
            this.updbtnsup = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel33 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.phonebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel29 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel30 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel31 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.mailbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.namebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.contactpersonbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.guna2TileButton9 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton10 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.submissiondate = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.dgv1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2HtmlLabel23 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button11 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.projectid = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel19 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.ORDERBOX = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.CLIENTBOX = new Guna.UI2.WinForms.Guna2TextBox();
            this.totalcost = new Guna.UI2.WinForms.Guna2TextBox();
            this.labourcost = new Guna.UI2.WinForms.Guna2TextBox();
            this.materialcost = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel16 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel17 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel15 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel18 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.PROJECTBOX = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.guna2DataGridView3 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.type = new Guna.UI2.WinForms.Guna2TextBox();
            this.name = new Guna.UI2.WinForms.Guna2TextBox();
            this.qty = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel28 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.guna2TileButton8 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton7 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton6 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.dgvMeetings = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel32 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.meetingIdTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel25 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.summary = new Guna.UI2.WinForms.Guna2TextBox();
            this.meetingParticipantsListBox = new System.Windows.Forms.ListBox();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.meetingDatePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel20 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.meetingTitleTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dgvsales = new Guna.UI2.WinForms.Guna2DataGridView();
            this.salesDateTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel34 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.orderIdTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel26 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.clientPaymentIdTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel35 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.clientIdTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel39 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.salesStatusComboBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel41 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel43 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.salesAmountTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.salesIdTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel21 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel22 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgvFeedback = new Guna.UI2.WinForms.Guna2DataGridView();
            this.sendc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel47 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbFeedbackType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtFeedback = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtEmpName = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtEmpId = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel27 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel24 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlToolTip1 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip2 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip3 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip4 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip5 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip6 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2TabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplier)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.guna2Panel4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView3)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMeetings)).BeginInit();
            this.guna2Panel5.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvsales)).BeginInit();
            this.guna2Panel6.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2TabControl1
            // 
            this.guna2TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.guna2TabControl1.Controls.Add(this.tabPage1);
            this.guna2TabControl1.Controls.Add(this.tabPage6);
            this.guna2TabControl1.Controls.Add(this.tabPage8);
            this.guna2TabControl1.Controls.Add(this.tabPage2);
            this.guna2TabControl1.Controls.Add(this.tabPage7);
            this.guna2TabControl1.Controls.Add(this.tabPage3);
            this.guna2TabControl1.Controls.Add(this.tabPage9);
            this.guna2TabControl1.Controls.Add(this.tabPage10);
            this.guna2TabControl1.Controls.Add(this.tabPage5);
            this.guna2TabControl1.Controls.Add(this.tabPage4);
            this.guna2TabControl1.ItemSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.Location = new System.Drawing.Point(0, 114);
            this.guna2TabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TabControl1.Name = "guna2TabControl1";
            this.guna2TabControl1.SelectedIndex = 0;
            this.guna2TabControl1.Size = new System.Drawing.Size(1351, 679);
            this.guna2TabControl1.TabButtonHoverState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonHoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonHoverState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonHoverState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonIdleState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonIdleState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(160)))), ((int)(((byte)(167)))));
            this.guna2TabControl1.TabButtonIdleState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonSelectedState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonSelectedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(37)))), ((int)(((byte)(49)))));
            this.guna2TabControl1.TabButtonSelectedState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonSelectedState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonSelectedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(132)))), ((int)(((byte)(255)))));
            this.guna2TabControl1.TabButtonSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.TabIndex = 16;
            this.guna2TabControl1.TabMenuBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.SelectedIndexChanged += new System.EventHandler(this.guna2TabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.guna2HtmlLabel48);
            this.tabPage1.Controls.Add(this.guna2TextBox2);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel46);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel52);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel49);
            this.tabPage1.Controls.Add(this.guna2TextBox6);
            this.tabPage1.Controls.Add(this.guna2TextBox10);
            this.tabPage1.Controls.Add(this.guna2Button8);
            this.tabPage1.Controls.Add(this.guna2Button4);
            this.tabPage1.Controls.Add(this.guna2TileButton5);
            this.tabPage1.Controls.Add(this.guna2TileButton4);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel45);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel44);
            this.tabPage1.Controls.Add(this.guna2TextBox12);
            this.tabPage1.Controls.Add(this.guna2TextBox4);
            this.tabPage1.Controls.Add(this.guna2Button6);
            this.tabPage1.Controls.Add(this.guna2TileButton3);
            this.tabPage1.Controls.Add(this.guna2Button3);
            this.tabPage1.Controls.Add(this.guna2TileButton1);
            this.tabPage1.Controls.Add(this.guna2Button1);
            this.tabPage1.Controls.Add(this.guna2TileButton2);
            this.tabPage1.Location = new System.Drawing.Point(194, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1153, 671);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dashboard";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // guna2HtmlLabel48
            // 
            this.guna2HtmlLabel48.AutoSize = false;
            this.guna2HtmlLabel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel48.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel48.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel48.Location = new System.Drawing.Point(780, 239);
            this.guna2HtmlLabel48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel48.Name = "guna2HtmlLabel48";
            this.guna2HtmlLabel48.Size = new System.Drawing.Size(239, 44);
            this.guna2HtmlLabel48.TabIndex = 135;
            this.guna2HtmlLabel48.Text = "Salary";
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.AutoSize = false;
            this.guna2TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox2.Location = new System.Drawing.Point(878, 197);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.Size = new System.Drawing.Size(194, 98);
            this.guna2TextBox2.TabIndex = 134;
            this.guna2TextBox2.Text = null;
            // 
            // guna2HtmlLabel46
            // 
            this.guna2HtmlLabel46.AutoSize = false;
            this.guna2HtmlLabel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel46.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel46.Location = new System.Drawing.Point(787, 526);
            this.guna2HtmlLabel46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel46.Name = "guna2HtmlLabel46";
            this.guna2HtmlLabel46.Size = new System.Drawing.Size(122, 44);
            this.guna2HtmlLabel46.TabIndex = 133;
            this.guna2HtmlLabel46.Text = "Tasks";
            // 
            // guna2HtmlLabel52
            // 
            this.guna2HtmlLabel52.AutoSize = false;
            this.guna2HtmlLabel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel52.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel52.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel52.Location = new System.Drawing.Point(123, 557);
            this.guna2HtmlLabel52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel52.Name = "guna2HtmlLabel52";
            this.guna2HtmlLabel52.Size = new System.Drawing.Size(327, 44);
            this.guna2HtmlLabel52.TabIndex = 108;
            this.guna2HtmlLabel52.Text = "Alert";
            // 
            // guna2HtmlLabel49
            // 
            this.guna2HtmlLabel49.AutoSize = false;
            this.guna2HtmlLabel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel49.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel49.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel49.Location = new System.Drawing.Point(114, 527);
            this.guna2HtmlLabel49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel49.Name = "guna2HtmlLabel49";
            this.guna2HtmlLabel49.Size = new System.Drawing.Size(349, 44);
            this.guna2HtmlLabel49.TabIndex = 105;
            this.guna2HtmlLabel49.Text = "Meeting";
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.AutoSize = false;
            this.guna2TextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox6.Location = new System.Drawing.Point(235, 483);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.Size = new System.Drawing.Size(785, 82);
            this.guna2TextBox6.TabIndex = 104;
            this.guna2TextBox6.Text = null;
            // 
            // guna2TextBox10
            // 
            this.guna2TextBox10.AutoSize = false;
            this.guna2TextBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox10.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox10.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox10.Location = new System.Drawing.Point(897, 462);
            this.guna2TextBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox10.Name = "guna2TextBox10";
            this.guna2TextBox10.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox10.TabIndex = 103;
            this.guna2TextBox10.Text = null;
            // 
            // guna2Button8
            // 
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button8.Image")));
            this.guna2Button8.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button8.Location = new System.Drawing.Point(783, 430);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.Size = new System.Drawing.Size(72, 88);
            this.guna2Button8.TabIndex = 102;
            // 
            // guna2Button4
            // 
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button4.Image")));
            this.guna2Button4.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button4.Location = new System.Drawing.Point(100, 436);
            this.guna2Button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.Size = new System.Drawing.Size(105, 89);
            this.guna2Button4.TabIndex = 101;
            // 
            // guna2TileButton5
            // 
            this.guna2TileButton5.BorderRadius = 30;
            this.guna2TileButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton5.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton5.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton5.Location = new System.Drawing.Point(76, 389);
            this.guna2TileButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton5.Name = "guna2TileButton5";
            this.guna2TileButton5.Size = new System.Drawing.Size(635, 226);
            this.guna2TileButton5.TabIndex = 100;
            this.guna2TileButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // guna2TileButton4
            // 
            this.guna2TileButton4.BorderRadius = 30;
            this.guna2TileButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton4.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton4.Location = new System.Drawing.Point(741, 389);
            this.guna2TileButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton4.Name = "guna2TileButton4";
            this.guna2TileButton4.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton4.TabIndex = 99;
            // 
            // guna2HtmlLabel45
            // 
            this.guna2HtmlLabel45.AutoSize = false;
            this.guna2HtmlLabel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel45.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel45.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel45.Location = new System.Drawing.Point(443, 237);
            this.guna2HtmlLabel45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel45.Name = "guna2HtmlLabel45";
            this.guna2HtmlLabel45.Size = new System.Drawing.Size(213, 44);
            this.guna2HtmlLabel45.TabIndex = 96;
            this.guna2HtmlLabel45.Text = "Suppliers\r\n";
            // 
            // guna2HtmlLabel44
            // 
            this.guna2HtmlLabel44.AutoSize = false;
            this.guna2HtmlLabel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel44.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel44.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel44.Location = new System.Drawing.Point(100, 237);
            this.guna2HtmlLabel44.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel44.Name = "guna2HtmlLabel44";
            this.guna2HtmlLabel44.Size = new System.Drawing.Size(215, 44);
            this.guna2HtmlLabel44.TabIndex = 95;
            this.guna2HtmlLabel44.Text = "Employees";
            // 
            // guna2TextBox12
            // 
            this.guna2TextBox12.AutoSize = false;
            this.guna2TextBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox12.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox12.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox12.Location = new System.Drawing.Point(587, 175);
            this.guna2TextBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox12.Name = "guna2TextBox12";
            this.guna2TextBox12.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox12.TabIndex = 93;
            this.guna2TextBox12.Text = null;
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.AutoSize = false;
            this.guna2TextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox4.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox4.Location = new System.Drawing.Point(234, 175);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox4.TabIndex = 92;
            this.guna2TextBox4.Text = null;
            // 
            // guna2Button6
            // 
            this.guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button6.Image")));
            this.guna2Button6.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button6.Location = new System.Drawing.Point(761, 148);
            this.guna2Button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.Size = new System.Drawing.Size(87, 89);
            this.guna2Button6.TabIndex = 91;
            // 
            // guna2TileButton3
            // 
            this.guna2TileButton3.BorderRadius = 30;
            this.guna2TileButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton3.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton3.Location = new System.Drawing.Point(743, 110);
            this.guna2TileButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton3.Name = "guna2TileButton3";
            this.guna2TileButton3.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton3.TabIndex = 90;
            // 
            // guna2Button3
            // 
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.guna2Button3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button3.Image")));
            this.guna2Button3.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button3.Location = new System.Drawing.Point(118, 144);
            this.guna2Button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(71, 89);
            this.guna2Button3.TabIndex = 89;
            this.guna2Button3.UseTransparentBackground = true;
            // 
            // guna2TileButton1
            // 
            this.guna2TileButton1.BorderRadius = 30;
            this.guna2TileButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton1.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton1.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton1.Location = new System.Drawing.Point(78, 110);
            this.guna2TileButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton1.Name = "guna2TileButton1";
            this.guna2TileButton1.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton1.TabIndex = 88;
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button1.Location = new System.Drawing.Point(432, 148);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(120, 89);
            this.guna2Button1.TabIndex = 87;
            // 
            // guna2TileButton2
            // 
            this.guna2TileButton2.BorderRadius = 30;
            this.guna2TileButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton2.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton2.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton2.Location = new System.Drawing.Point(419, 113);
            this.guna2TileButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton2.Name = "guna2TileButton2";
            this.guna2TileButton2.Size = new System.Drawing.Size(281, 226);
            this.guna2TileButton2.TabIndex = 86;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage6.Controls.Add(this.accDeadline);
            this.tabPage6.Controls.Add(this.acctask);
            this.tabPage6.Controls.Add(this.accPriority);
            this.tabPage6.Controls.Add(this.cmbaccStatuss);
            this.tabPage6.Controls.Add(this.accTaskNames);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel40);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel38);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel37);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel36);
            this.tabPage6.Controls.Add(this.updbtnacc);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel42);
            this.tabPage6.Location = new System.Drawing.Point(194, 4);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1153, 671);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Task Management";
            // 
            // accDeadline
            // 
            this.accDeadline.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accDeadline.BorderRadius = 5;
            this.accDeadline.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accDeadline.DefaultText = "";
            this.accDeadline.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accDeadline.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accDeadline.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accDeadline.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Location = new System.Drawing.Point(194, 158);
            this.accDeadline.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accDeadline.Name = "accDeadline";
            this.accDeadline.PasswordChar = '\0';
            this.accDeadline.PlaceholderText = "";
            this.accDeadline.ReadOnly = true;
            this.accDeadline.SelectedText = "";
            this.accDeadline.Size = new System.Drawing.Size(232, 48);
            this.accDeadline.TabIndex = 255;
            // 
            // acctask
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.acctask.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.acctask.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.acctask.ColumnHeadersHeight = 30;
            this.acctask.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.acctask.DefaultCellStyle = dataGridViewCellStyle3;
            this.acctask.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.Location = new System.Drawing.Point(475, 98);
            this.acctask.Name = "acctask";
            this.acctask.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.acctask.RowHeadersVisible = false;
            this.acctask.RowHeadersWidth = 51;
            dataGridViewCellStyle5.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.acctask.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.acctask.RowTemplate.Height = 24;
            this.acctask.Size = new System.Drawing.Size(584, 514);
            this.acctask.TabIndex = 254;
            this.acctask.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.acctask.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.acctask.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.acctask.ThemeStyle.HeaderStyle.Height = 30;
            this.acctask.ThemeStyle.ReadOnly = true;
            this.acctask.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.acctask.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.ThemeStyle.RowsStyle.Height = 24;
            this.acctask.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.acctask_CellContentClick);
            // 
            // accPriority
            // 
            this.accPriority.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accPriority.BorderRadius = 5;
            this.accPriority.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accPriority.DefaultText = "";
            this.accPriority.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accPriority.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accPriority.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accPriority.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Location = new System.Drawing.Point(195, 217);
            this.accPriority.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accPriority.Name = "accPriority";
            this.accPriority.PasswordChar = '\0';
            this.accPriority.PlaceholderText = "";
            this.accPriority.ReadOnly = true;
            this.accPriority.SelectedText = "";
            this.accPriority.Size = new System.Drawing.Size(232, 48);
            this.accPriority.TabIndex = 253;
            // 
            // cmbaccStatuss
            // 
            this.cmbaccStatuss.BackColor = System.Drawing.Color.Transparent;
            this.cmbaccStatuss.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbaccStatuss.BorderRadius = 5;
            this.cmbaccStatuss.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbaccStatuss.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbaccStatuss.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbaccStatuss.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbaccStatuss.ItemHeight = 30;
            this.cmbaccStatuss.Items.AddRange(new object[] {
            "Pending",
            "Completed"});
            this.cmbaccStatuss.Location = new System.Drawing.Point(195, 276);
            this.cmbaccStatuss.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbaccStatuss.Name = "cmbaccStatuss";
            this.cmbaccStatuss.Size = new System.Drawing.Size(232, 36);
            this.cmbaccStatuss.TabIndex = 252;
            // 
            // accTaskNames
            // 
            this.accTaskNames.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accTaskNames.BorderRadius = 5;
            this.accTaskNames.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accTaskNames.DefaultText = "";
            this.accTaskNames.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accTaskNames.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accTaskNames.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accTaskNames.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Location = new System.Drawing.Point(195, 98);
            this.accTaskNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accTaskNames.Name = "accTaskNames";
            this.accTaskNames.PasswordChar = '\0';
            this.accTaskNames.PlaceholderText = "";
            this.accTaskNames.ReadOnly = true;
            this.accTaskNames.SelectedText = "";
            this.accTaskNames.Size = new System.Drawing.Size(232, 48);
            this.accTaskNames.TabIndex = 251;
            // 
            // guna2HtmlLabel40
            // 
            this.guna2HtmlLabel40.AutoSize = false;
            this.guna2HtmlLabel40.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel40.Location = new System.Drawing.Point(51, 228);
            this.guna2HtmlLabel40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel40.Name = "guna2HtmlLabel40";
            this.guna2HtmlLabel40.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel40.TabIndex = 250;
            this.guna2HtmlLabel40.Text = "Priority";
            // 
            // guna2HtmlLabel38
            // 
            this.guna2HtmlLabel38.AutoSize = false;
            this.guna2HtmlLabel38.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel38.Location = new System.Drawing.Point(51, 286);
            this.guna2HtmlLabel38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel38.Name = "guna2HtmlLabel38";
            this.guna2HtmlLabel38.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel38.TabIndex = 249;
            this.guna2HtmlLabel38.Text = "Status";
            // 
            // guna2HtmlLabel37
            // 
            this.guna2HtmlLabel37.AutoSize = false;
            this.guna2HtmlLabel37.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel37.Location = new System.Drawing.Point(51, 110);
            this.guna2HtmlLabel37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel37.Name = "guna2HtmlLabel37";
            this.guna2HtmlLabel37.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel37.TabIndex = 248;
            this.guna2HtmlLabel37.Text = "Task Name";
            // 
            // guna2HtmlLabel36
            // 
            this.guna2HtmlLabel36.AutoSize = false;
            this.guna2HtmlLabel36.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel36.Location = new System.Drawing.Point(51, 167);
            this.guna2HtmlLabel36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel36.Name = "guna2HtmlLabel36";
            this.guna2HtmlLabel36.Size = new System.Drawing.Size(245, 39);
            this.guna2HtmlLabel36.TabIndex = 247;
            this.guna2HtmlLabel36.Text = "Deadline";
            // 
            // updbtnacc
            // 
            this.updbtnacc.BorderRadius = 5;
            this.updbtnacc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtnacc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtnacc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtnacc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtnacc.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.Location = new System.Drawing.Point(281, 334);
            this.updbtnacc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtnacc.Name = "updbtnacc";
            this.updbtnacc.Size = new System.Drawing.Size(145, 46);
            this.updbtnacc.TabIndex = 246;
            this.updbtnacc.Text = "Update";
            this.updbtnacc.Click += new System.EventHandler(this.updbtnacc_Click_1);
            // 
            // guna2HtmlLabel42
            // 
            this.guna2HtmlLabel42.AutoSize = false;
            this.guna2HtmlLabel42.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel42.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel42.Location = new System.Drawing.Point(265, 17);
            this.guna2HtmlLabel42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel42.Name = "guna2HtmlLabel42";
            this.guna2HtmlLabel42.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel42.TabIndex = 245;
            this.guna2HtmlLabel42.Text = "My Tasks";
            this.guna2HtmlLabel42.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage8.Controls.Add(this.dgvSupplier);
            this.tabPage8.Controls.Add(this.addbtnsup);
            this.tabPage8.Controls.Add(this.rembtnsup);
            this.tabPage8.Controls.Add(this.clrbtnsup);
            this.tabPage8.Controls.Add(this.updbtnsup);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel33);
            this.tabPage8.Controls.Add(this.phonebox);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel29);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel30);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel31);
            this.tabPage8.Controls.Add(this.mailbox);
            this.tabPage8.Controls.Add(this.namebox);
            this.tabPage8.Controls.Add(this.contactpersonbox);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel10);
            this.tabPage8.Location = new System.Drawing.Point(194, 4);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1153, 671);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Supplier Management";
            // 
            // dgvSupplier
            // 
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            this.dgvSupplier.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvSupplier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSupplier.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvSupplier.ColumnHeadersHeight = 30;
            this.dgvSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSupplier.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvSupplier.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvSupplier.Location = new System.Drawing.Point(475, 97);
            this.dgvSupplier.Name = "dgvSupplier";
            this.dgvSupplier.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSupplier.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvSupplier.RowHeadersVisible = false;
            this.dgvSupplier.RowHeadersWidth = 51;
            dataGridViewCellStyle10.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvSupplier.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvSupplier.RowTemplate.Height = 24;
            this.dgvSupplier.Size = new System.Drawing.Size(584, 514);
            this.dgvSupplier.TabIndex = 238;
            this.dgvSupplier.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvSupplier.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvSupplier.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvSupplier.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvSupplier.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvSupplier.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvSupplier.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvSupplier.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvSupplier.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvSupplier.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvSupplier.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvSupplier.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvSupplier.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvSupplier.ThemeStyle.ReadOnly = true;
            this.dgvSupplier.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvSupplier.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvSupplier.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvSupplier.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvSupplier.ThemeStyle.RowsStyle.Height = 24;
            this.dgvSupplier.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvSupplier.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvSupplier.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSupplier_CellContentClick);
            // 
            // addbtnsup
            // 
            this.addbtnsup.BorderRadius = 5;
            this.addbtnsup.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.addbtnsup.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.addbtnsup.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.addbtnsup.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.addbtnsup.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.addbtnsup.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addbtnsup.ForeColor = System.Drawing.Color.DarkGray;
            this.addbtnsup.Location = new System.Drawing.Point(77, 369);
            this.addbtnsup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addbtnsup.Name = "addbtnsup";
            this.addbtnsup.Size = new System.Drawing.Size(145, 46);
            this.addbtnsup.TabIndex = 235;
            this.addbtnsup.Text = "Add";
            this.addbtnsup.Click += new System.EventHandler(this.addbtnsup_Click);
            // 
            // rembtnsup
            // 
            this.rembtnsup.BorderRadius = 5;
            this.rembtnsup.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.rembtnsup.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.rembtnsup.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.rembtnsup.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.rembtnsup.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.rembtnsup.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.rembtnsup.ForeColor = System.Drawing.Color.DarkGray;
            this.rembtnsup.Location = new System.Drawing.Point(77, 433);
            this.rembtnsup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rembtnsup.Name = "rembtnsup";
            this.rembtnsup.Size = new System.Drawing.Size(145, 46);
            this.rembtnsup.TabIndex = 234;
            this.rembtnsup.Text = "Remove";
            this.rembtnsup.Click += new System.EventHandler(this.rembtnsup_Click);
            // 
            // clrbtnsup
            // 
            this.clrbtnsup.BorderRadius = 5;
            this.clrbtnsup.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clrbtnsup.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clrbtnsup.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clrbtnsup.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clrbtnsup.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.clrbtnsup.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clrbtnsup.ForeColor = System.Drawing.Color.DarkGray;
            this.clrbtnsup.Location = new System.Drawing.Point(259, 433);
            this.clrbtnsup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clrbtnsup.Name = "clrbtnsup";
            this.clrbtnsup.Size = new System.Drawing.Size(145, 46);
            this.clrbtnsup.TabIndex = 232;
            this.clrbtnsup.Text = "Clear";
            this.clrbtnsup.Click += new System.EventHandler(this.clrbtnsup_Click);
            // 
            // updbtnsup
            // 
            this.updbtnsup.BorderRadius = 5;
            this.updbtnsup.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtnsup.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtnsup.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtnsup.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtnsup.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtnsup.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtnsup.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtnsup.Location = new System.Drawing.Point(259, 369);
            this.updbtnsup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtnsup.Name = "updbtnsup";
            this.updbtnsup.Size = new System.Drawing.Size(145, 46);
            this.updbtnsup.TabIndex = 231;
            this.updbtnsup.Text = "Update";
            this.updbtnsup.Click += new System.EventHandler(this.updbtnsup_Click);
            // 
            // guna2HtmlLabel33
            // 
            this.guna2HtmlLabel33.AutoSize = false;
            this.guna2HtmlLabel33.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel33.Location = new System.Drawing.Point(47, 174);
            this.guna2HtmlLabel33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel33.Name = "guna2HtmlLabel33";
            this.guna2HtmlLabel33.Size = new System.Drawing.Size(244, 60);
            this.guna2HtmlLabel33.TabIndex = 121;
            this.guna2HtmlLabel33.Text = "Contact Person";
            this.guna2HtmlLabel33.Click += new System.EventHandler(this.guna2HtmlLabel33_Click);
            // 
            // phonebox
            // 
            this.phonebox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.phonebox.BorderRadius = 5;
            this.phonebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phonebox.DefaultText = "";
            this.phonebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.phonebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.phonebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phonebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phonebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phonebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.phonebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phonebox.Location = new System.Drawing.Point(207, 288);
            this.phonebox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.phonebox.Name = "phonebox";
            this.phonebox.PasswordChar = '\0';
            this.phonebox.PlaceholderText = "";
            this.phonebox.SelectedText = "";
            this.phonebox.Size = new System.Drawing.Size(232, 48);
            this.phonebox.TabIndex = 120;
            // 
            // guna2HtmlLabel29
            // 
            this.guna2HtmlLabel29.AutoSize = false;
            this.guna2HtmlLabel29.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel29.Location = new System.Drawing.Point(47, 299);
            this.guna2HtmlLabel29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel29.Name = "guna2HtmlLabel29";
            this.guna2HtmlLabel29.Size = new System.Drawing.Size(341, 48);
            this.guna2HtmlLabel29.TabIndex = 119;
            this.guna2HtmlLabel29.Text = "       Phone Number";
            // 
            // guna2HtmlLabel30
            // 
            this.guna2HtmlLabel30.AutoSize = false;
            this.guna2HtmlLabel30.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel30.Location = new System.Drawing.Point(47, 110);
            this.guna2HtmlLabel30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel30.Name = "guna2HtmlLabel30";
            this.guna2HtmlLabel30.Size = new System.Drawing.Size(265, 48);
            this.guna2HtmlLabel30.TabIndex = 118;
            this.guna2HtmlLabel30.Text = "Supplier Name";
            // 
            // guna2HtmlLabel31
            // 
            this.guna2HtmlLabel31.AutoSize = false;
            this.guna2HtmlLabel31.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel31.Location = new System.Drawing.Point(47, 238);
            this.guna2HtmlLabel31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel31.Name = "guna2HtmlLabel31";
            this.guna2HtmlLabel31.Size = new System.Drawing.Size(192, 44);
            this.guna2HtmlLabel31.TabIndex = 117;
            this.guna2HtmlLabel31.Text = "Email";
            // 
            // mailbox
            // 
            this.mailbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.mailbox.BorderRadius = 5;
            this.mailbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mailbox.DefaultText = "";
            this.mailbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mailbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mailbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mailbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mailbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mailbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mailbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mailbox.Location = new System.Drawing.Point(207, 223);
            this.mailbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mailbox.Name = "mailbox";
            this.mailbox.PasswordChar = '\0';
            this.mailbox.PlaceholderText = "";
            this.mailbox.SelectedText = "";
            this.mailbox.Size = new System.Drawing.Size(232, 48);
            this.mailbox.TabIndex = 116;
            // 
            // namebox
            // 
            this.namebox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.namebox.BorderRadius = 5;
            this.namebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.namebox.DefaultText = "";
            this.namebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.namebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.namebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.namebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.Location = new System.Drawing.Point(207, 97);
            this.namebox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.namebox.Name = "namebox";
            this.namebox.PasswordChar = '\0';
            this.namebox.PlaceholderText = "";
            this.namebox.SelectedText = "";
            this.namebox.Size = new System.Drawing.Size(232, 48);
            this.namebox.TabIndex = 115;
            // 
            // contactpersonbox
            // 
            this.contactpersonbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.contactpersonbox.BorderRadius = 5;
            this.contactpersonbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.contactpersonbox.DefaultText = "";
            this.contactpersonbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.contactpersonbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.contactpersonbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.contactpersonbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.contactpersonbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.contactpersonbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.contactpersonbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.contactpersonbox.Location = new System.Drawing.Point(207, 160);
            this.contactpersonbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.contactpersonbox.Name = "contactpersonbox";
            this.contactpersonbox.PasswordChar = '\0';
            this.contactpersonbox.PlaceholderText = "";
            this.contactpersonbox.SelectedText = "";
            this.contactpersonbox.Size = new System.Drawing.Size(232, 48);
            this.contactpersonbox.TabIndex = 114;
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.AutoSize = false;
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(259, 13);
            this.guna2HtmlLabel10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(833, 48);
            this.guna2HtmlLabel10.TabIndex = 113;
            this.guna2HtmlLabel10.Text = "Supplier Informations";
            this.guna2HtmlLabel10.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage2.Controls.Add(this.guna2TileButton9);
            this.tabPage2.Controls.Add(this.guna2TileButton10);
            this.tabPage2.Location = new System.Drawing.Point(194, 4);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1153, 671);
            this.tabPage2.TabIndex = 9;
            this.tabPage2.Text = "Employee Management";
            // 
            // guna2TileButton9
            // 
            this.guna2TileButton9.BorderRadius = 30;
            this.guna2TileButton9.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton9.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton9.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton9.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton9.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton9.Location = new System.Drawing.Point(76, 388);
            this.guna2TileButton9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton9.Name = "guna2TileButton9";
            this.guna2TileButton9.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton9.TabIndex = 18;
            this.guna2TileButton9.Text = "Employee Attendance";
            this.guna2TileButton9.Click += new System.EventHandler(this.guna2TileButton9_Click);
            // 
            // guna2TileButton10
            // 
            this.guna2TileButton10.BorderRadius = 30;
            this.guna2TileButton10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold);
            this.guna2TileButton10.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton10.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton10.Location = new System.Drawing.Point(76, 185);
            this.guna2TileButton10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton10.Name = "guna2TileButton10";
            this.guna2TileButton10.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton10.TabIndex = 17;
            this.guna2TileButton10.Text = "Employee Profiles ";
            this.guna2TileButton10.Click += new System.EventHandler(this.guna2TileButton10_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage7.Controls.Add(this.submissiondate);
            this.tabPage7.Controls.Add(this.guna2Button7);
            this.tabPage7.Controls.Add(this.dgv1);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel23);
            this.tabPage7.Controls.Add(this.guna2Button11);
            this.tabPage7.Controls.Add(this.guna2Panel4);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel5);
            this.tabPage7.Controls.Add(this.ORDERBOX);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel11);
            this.tabPage7.Controls.Add(this.CLIENTBOX);
            this.tabPage7.Controls.Add(this.totalcost);
            this.tabPage7.Controls.Add(this.labourcost);
            this.tabPage7.Controls.Add(this.materialcost);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel16);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel17);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel15);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel18);
            this.tabPage7.Controls.Add(this.PROJECTBOX);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel14);
            this.tabPage7.Location = new System.Drawing.Point(194, 4);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1153, 671);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Project Management";
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // submissiondate
            // 
            this.submissiondate.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.submissiondate.BorderRadius = 5;
            this.submissiondate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.submissiondate.DefaultText = "";
            this.submissiondate.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.submissiondate.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.submissiondate.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.submissiondate.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.submissiondate.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.submissiondate.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.submissiondate.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.submissiondate.Location = new System.Drawing.Point(215, 438);
            this.submissiondate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.submissiondate.Name = "submissiondate";
            this.submissiondate.PasswordChar = '\0';
            this.submissiondate.PlaceholderText = "";
            this.submissiondate.SelectedText = "";
            this.submissiondate.Size = new System.Drawing.Size(232, 48);
            this.submissiondate.TabIndex = 251;
            this.submissiondate.TextChanged += new System.EventHandler(this.submissiondate_TextChanged);
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderRadius = 5;
            this.guna2Button7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button7.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.Location = new System.Drawing.Point(782, 620);
            this.guna2Button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.Size = new System.Drawing.Size(145, 46);
            this.guna2Button7.TabIndex = 250;
            this.guna2Button7.Text = "Reject";
            this.guna2Button7.Click += new System.EventHandler(this.guna2Button7_Click);
            // 
            // dgv1
            // 
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            this.dgv1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgv1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgv1.ColumnHeadersHeight = 30;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv1.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgv1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgv1.Location = new System.Drawing.Point(495, 97);
            this.dgv1.Name = "dgv1";
            this.dgv1.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dgv1.RowHeadersVisible = false;
            this.dgv1.RowHeadersWidth = 51;
            dataGridViewCellStyle15.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgv1.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dgv1.RowTemplate.Height = 24;
            this.dgv1.Size = new System.Drawing.Size(584, 511);
            this.dgv1.TabIndex = 249;
            this.dgv1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgv1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgv1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgv1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgv1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgv1.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgv1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgv1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgv1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgv1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgv1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgv1.ThemeStyle.HeaderStyle.Height = 30;
            this.dgv1.ThemeStyle.ReadOnly = true;
            this.dgv1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgv1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgv1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgv1.ThemeStyle.RowsStyle.Height = 24;
            this.dgv1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgv1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgv1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProjectss_CellContentClick);
            // 
            // guna2HtmlLabel23
            // 
            this.guna2HtmlLabel23.AutoSize = false;
            this.guna2HtmlLabel23.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel23.Location = new System.Drawing.Point(43, 620);
            this.guna2HtmlLabel23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel23.Name = "guna2HtmlLabel23";
            this.guna2HtmlLabel23.Size = new System.Drawing.Size(167, 32);
            this.guna2HtmlLabel23.TabIndex = 236;
            this.guna2HtmlLabel23.Text = "Total Cost";
            // 
            // guna2Button11
            // 
            this.guna2Button11.BorderRadius = 5;
            this.guna2Button11.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button11.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button11.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button11.Location = new System.Drawing.Point(618, 620);
            this.guna2Button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button11.Name = "guna2Button11";
            this.guna2Button11.Size = new System.Drawing.Size(145, 46);
            this.guna2Button11.TabIndex = 235;
            this.guna2Button11.Text = "Approve";
            this.guna2Button11.Click += new System.EventHandler(this.guna2Button11_Click);
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Panel4.BorderThickness = 2;
            this.guna2Panel4.Controls.Add(this.projectid);
            this.guna2Panel4.Controls.Add(this.guna2Button10);
            this.guna2Panel4.Controls.Add(this.guna2HtmlLabel19);
            this.guna2Panel4.Location = new System.Drawing.Point(25, 97);
            this.guna2Panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.Size = new System.Drawing.Size(433, 146);
            this.guna2Panel4.TabIndex = 126;
            // 
            // projectid
            // 
            this.projectid.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.projectid.BorderRadius = 5;
            this.projectid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.projectid.DefaultText = "";
            this.projectid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.projectid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.projectid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.projectid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.projectid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.projectid.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.projectid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.projectid.Location = new System.Drawing.Point(187, 20);
            this.projectid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.projectid.Name = "projectid";
            this.projectid.PasswordChar = '\0';
            this.projectid.PlaceholderText = "Enter Project Id ( P001 )";
            this.projectid.SelectedText = "";
            this.projectid.Size = new System.Drawing.Size(232, 48);
            this.projectid.TabIndex = 113;
            this.projectid.TextChanged += new System.EventHandler(this.projectid_TextChanged);
            // 
            // guna2Button10
            // 
            this.guna2Button10.BorderRadius = 5;
            this.guna2Button10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button10.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.Location = new System.Drawing.Point(275, 81);
            this.guna2Button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.Size = new System.Drawing.Size(145, 46);
            this.guna2Button10.TabIndex = 112;
            this.guna2Button10.Text = "Search";
            this.guna2Button10.Click += new System.EventHandler(this.guna2Button10_Click);
            // 
            // guna2HtmlLabel19
            // 
            this.guna2HtmlLabel19.AutoSize = false;
            this.guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel19.Location = new System.Drawing.Point(13, 34);
            this.guna2HtmlLabel19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel19.Name = "guna2HtmlLabel19";
            this.guna2HtmlLabel19.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel19.TabIndex = 111;
            this.guna2HtmlLabel19.Text = "Project ID";
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.AutoSize = false;
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(43, 338);
            this.guna2HtmlLabel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(167, 48);
            this.guna2HtmlLabel5.TabIndex = 124;
            this.guna2HtmlLabel5.Text = "Order ID";
            // 
            // ORDERBOX
            // 
            this.ORDERBOX.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.ORDERBOX.BorderRadius = 5;
            this.ORDERBOX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ORDERBOX.DefaultText = "";
            this.ORDERBOX.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ORDERBOX.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ORDERBOX.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ORDERBOX.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ORDERBOX.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ORDERBOX.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ORDERBOX.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ORDERBOX.Location = new System.Drawing.Point(215, 322);
            this.ORDERBOX.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ORDERBOX.Name = "ORDERBOX";
            this.ORDERBOX.PasswordChar = '\0';
            this.ORDERBOX.PlaceholderText = "";
            this.ORDERBOX.ReadOnly = true;
            this.ORDERBOX.SelectedText = "";
            this.ORDERBOX.Size = new System.Drawing.Size(232, 48);
            this.ORDERBOX.TabIndex = 123;
            this.ORDERBOX.TextChanged += new System.EventHandler(this.ORDERBOX_TextChanged);
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.AutoSize = false;
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(43, 283);
            this.guna2HtmlLabel11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(167, 48);
            this.guna2HtmlLabel11.TabIndex = 122;
            this.guna2HtmlLabel11.Text = "Client ID";
            // 
            // CLIENTBOX
            // 
            this.CLIENTBOX.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.CLIENTBOX.BorderRadius = 5;
            this.CLIENTBOX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CLIENTBOX.DefaultText = "";
            this.CLIENTBOX.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.CLIENTBOX.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.CLIENTBOX.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CLIENTBOX.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CLIENTBOX.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CLIENTBOX.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CLIENTBOX.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CLIENTBOX.Location = new System.Drawing.Point(215, 266);
            this.CLIENTBOX.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CLIENTBOX.Name = "CLIENTBOX";
            this.CLIENTBOX.PasswordChar = '\0';
            this.CLIENTBOX.PlaceholderText = "";
            this.CLIENTBOX.ReadOnly = true;
            this.CLIENTBOX.SelectedText = "";
            this.CLIENTBOX.Size = new System.Drawing.Size(232, 48);
            this.CLIENTBOX.TabIndex = 121;
            this.CLIENTBOX.TextChanged += new System.EventHandler(this.CLIENTBOX_TextChanged);
            // 
            // totalcost
            // 
            this.totalcost.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.totalcost.BorderRadius = 5;
            this.totalcost.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.totalcost.DefaultText = "";
            this.totalcost.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.totalcost.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.totalcost.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.totalcost.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.totalcost.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.totalcost.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.totalcost.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.totalcost.Location = new System.Drawing.Point(215, 606);
            this.totalcost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.totalcost.Name = "totalcost";
            this.totalcost.PasswordChar = '\0';
            this.totalcost.PlaceholderText = "";
            this.totalcost.ReadOnly = true;
            this.totalcost.SelectedText = "";
            this.totalcost.Size = new System.Drawing.Size(232, 48);
            this.totalcost.TabIndex = 120;
            this.totalcost.TextChanged += new System.EventHandler(this.totalcost_TextChanged);
            // 
            // labourcost
            // 
            this.labourcost.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.labourcost.BorderRadius = 5;
            this.labourcost.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labourcost.DefaultText = "";
            this.labourcost.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.labourcost.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.labourcost.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.labourcost.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.labourcost.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.labourcost.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.labourcost.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.labourcost.Location = new System.Drawing.Point(215, 548);
            this.labourcost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labourcost.Name = "labourcost";
            this.labourcost.PasswordChar = '\0';
            this.labourcost.PlaceholderText = "";
            this.labourcost.ReadOnly = true;
            this.labourcost.SelectedText = "";
            this.labourcost.Size = new System.Drawing.Size(232, 48);
            this.labourcost.TabIndex = 119;
            this.labourcost.TextChanged += new System.EventHandler(this.labourcost_TextChanged);
            // 
            // materialcost
            // 
            this.materialcost.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.materialcost.BorderRadius = 5;
            this.materialcost.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.materialcost.DefaultText = "";
            this.materialcost.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.materialcost.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.materialcost.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.materialcost.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.materialcost.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.materialcost.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.materialcost.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.materialcost.Location = new System.Drawing.Point(215, 494);
            this.materialcost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.materialcost.Name = "materialcost";
            this.materialcost.PasswordChar = '\0';
            this.materialcost.PlaceholderText = "";
            this.materialcost.ReadOnly = true;
            this.materialcost.SelectedText = "";
            this.materialcost.Size = new System.Drawing.Size(232, 48);
            this.materialcost.TabIndex = 118;
            this.materialcost.TextChanged += new System.EventHandler(this.materialcost_TextChanged);
            // 
            // guna2HtmlLabel16
            // 
            this.guna2HtmlLabel16.AutoSize = false;
            this.guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel16.Location = new System.Drawing.Point(43, 560);
            this.guna2HtmlLabel16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel16.Name = "guna2HtmlLabel16";
            this.guna2HtmlLabel16.Size = new System.Drawing.Size(227, 48);
            this.guna2HtmlLabel16.TabIndex = 117;
            this.guna2HtmlLabel16.Text = "Labour Cost";
            // 
            // guna2HtmlLabel17
            // 
            this.guna2HtmlLabel17.AutoSize = false;
            this.guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel17.Location = new System.Drawing.Point(43, 508);
            this.guna2HtmlLabel17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel17.Name = "guna2HtmlLabel17";
            this.guna2HtmlLabel17.Size = new System.Drawing.Size(227, 48);
            this.guna2HtmlLabel17.TabIndex = 116;
            this.guna2HtmlLabel17.Text = "Material Cost";
            // 
            // guna2HtmlLabel15
            // 
            this.guna2HtmlLabel15.AutoSize = false;
            this.guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel15.Location = new System.Drawing.Point(43, 450);
            this.guna2HtmlLabel15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel15.Name = "guna2HtmlLabel15";
            this.guna2HtmlLabel15.Size = new System.Drawing.Size(280, 48);
            this.guna2HtmlLabel15.TabIndex = 114;
            this.guna2HtmlLabel15.Text = "Submission Date";
            // 
            // guna2HtmlLabel18
            // 
            this.guna2HtmlLabel18.AutoSize = false;
            this.guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel18.Location = new System.Drawing.Point(43, 393);
            this.guna2HtmlLabel18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel18.Name = "guna2HtmlLabel18";
            this.guna2HtmlLabel18.Size = new System.Drawing.Size(167, 48);
            this.guna2HtmlLabel18.TabIndex = 113;
            this.guna2HtmlLabel18.Text = "Project Name";
            // 
            // PROJECTBOX
            // 
            this.PROJECTBOX.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.PROJECTBOX.BorderRadius = 5;
            this.PROJECTBOX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PROJECTBOX.DefaultText = "";
            this.PROJECTBOX.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.PROJECTBOX.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PROJECTBOX.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PROJECTBOX.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PROJECTBOX.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PROJECTBOX.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PROJECTBOX.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PROJECTBOX.Location = new System.Drawing.Point(215, 379);
            this.PROJECTBOX.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.PROJECTBOX.Name = "PROJECTBOX";
            this.PROJECTBOX.PasswordChar = '\0';
            this.PROJECTBOX.PlaceholderText = "";
            this.PROJECTBOX.SelectedText = "";
            this.PROJECTBOX.Size = new System.Drawing.Size(232, 48);
            this.PROJECTBOX.TabIndex = 112;
            this.PROJECTBOX.TextChanged += new System.EventHandler(this.PROJECTBOX_TextChanged);
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.AutoSize = false;
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(8, 17);
            this.guna2HtmlLabel14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(1137, 48);
            this.guna2HtmlLabel14.TabIndex = 111;
            this.guna2HtmlLabel14.Text = "Project Informations";
            this.guna2HtmlLabel14.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage3.Controls.Add(this.guna2DataGridView3);
            this.tabPage3.Controls.Add(this.type);
            this.tabPage3.Controls.Add(this.name);
            this.tabPage3.Controls.Add(this.qty);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel12);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel13);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel28);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel4);
            this.tabPage3.Location = new System.Drawing.Point(194, 4);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1153, 671);
            this.tabPage3.TabIndex = 10;
            this.tabPage3.Text = "Inventory Management";
            // 
            // guna2DataGridView3
            // 
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.guna2DataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.guna2DataGridView3.ColumnHeadersHeight = 30;
            this.guna2DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView3.DefaultCellStyle = dataGridViewCellStyle18;
            this.guna2DataGridView3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.Location = new System.Drawing.Point(500, 97);
            this.guna2DataGridView3.Name = "guna2DataGridView3";
            this.guna2DataGridView3.ReadOnly = true;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.guna2DataGridView3.RowHeadersVisible = false;
            this.guna2DataGridView3.RowHeadersWidth = 51;
            dataGridViewCellStyle20.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.guna2DataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.guna2DataGridView3.RowTemplate.Height = 24;
            this.guna2DataGridView3.Size = new System.Drawing.Size(584, 511);
            this.guna2DataGridView3.TabIndex = 251;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView3.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.Height = 30;
            this.guna2DataGridView3.ThemeStyle.ReadOnly = true;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView3.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView3.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView3_CellContentClick_1);
            // 
            // type
            // 
            this.type.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.type.BorderRadius = 5;
            this.type.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.type.DefaultText = "";
            this.type.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.type.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.type.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.type.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.type.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.type.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.type.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.type.Location = new System.Drawing.Point(216, 97);
            this.type.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.type.Name = "type";
            this.type.PasswordChar = '\0';
            this.type.PlaceholderText = "";
            this.type.ReadOnly = true;
            this.type.SelectedText = "";
            this.type.Size = new System.Drawing.Size(232, 48);
            this.type.TabIndex = 177;
            // 
            // name
            // 
            this.name.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.name.BorderRadius = 5;
            this.name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.name.DefaultText = "";
            this.name.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.name.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.name.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.name.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.name.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.name.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.name.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.name.Location = new System.Drawing.Point(216, 153);
            this.name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.name.Name = "name";
            this.name.PasswordChar = '\0';
            this.name.PlaceholderText = "";
            this.name.ReadOnly = true;
            this.name.SelectedText = "";
            this.name.Size = new System.Drawing.Size(232, 48);
            this.name.TabIndex = 176;
            this.name.TextChanged += new System.EventHandler(this.guna2TextBox13_TextChanged);
            // 
            // qty
            // 
            this.qty.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.qty.BorderRadius = 5;
            this.qty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qty.DefaultText = "";
            this.qty.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.qty.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.qty.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qty.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qty.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qty.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.qty.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qty.Location = new System.Drawing.Point(216, 209);
            this.qty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.qty.Name = "qty";
            this.qty.PasswordChar = '\0';
            this.qty.PlaceholderText = "";
            this.qty.ReadOnly = true;
            this.qty.SelectedText = "";
            this.qty.Size = new System.Drawing.Size(232, 48);
            this.qty.TabIndex = 175;
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.AutoSize = false;
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(44, 166);
            this.guna2HtmlLabel12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel12.TabIndex = 174;
            this.guna2HtmlLabel12.Text = "Product Name";
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.AutoSize = false;
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(44, 110);
            this.guna2HtmlLabel13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel13.TabIndex = 173;
            this.guna2HtmlLabel13.Text = "Type";
            // 
            // guna2HtmlLabel28
            // 
            this.guna2HtmlLabel28.AutoSize = false;
            this.guna2HtmlLabel28.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel28.Location = new System.Drawing.Point(44, 222);
            this.guna2HtmlLabel28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel28.Name = "guna2HtmlLabel28";
            this.guna2HtmlLabel28.Size = new System.Drawing.Size(379, 48);
            this.guna2HtmlLabel28.TabIndex = 171;
            this.guna2HtmlLabel28.Text = "Required Quantity";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.AutoSize = false;
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(197, 15);
            this.guna2HtmlLabel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(1013, 48);
            this.guna2HtmlLabel4.TabIndex = 14;
            this.guna2HtmlLabel4.Text = "Required Inventory List";
            this.guna2HtmlLabel4.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage9.Controls.Add(this.guna2TileButton8);
            this.tabPage9.Controls.Add(this.guna2TileButton7);
            this.tabPage9.Controls.Add(this.guna2TileButton6);
            this.tabPage9.Location = new System.Drawing.Point(194, 4);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(1153, 671);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Payment Management";
            // 
            // guna2TileButton8
            // 
            this.guna2TileButton8.BorderRadius = 30;
            this.guna2TileButton8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton8.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton8.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton8.Location = new System.Drawing.Point(76, 498);
            this.guna2TileButton8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton8.Name = "guna2TileButton8";
            this.guna2TileButton8.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton8.TabIndex = 20;
            this.guna2TileButton8.Text = "Organziational Payments";
            this.guna2TileButton8.Click += new System.EventHandler(this.guna2TileButton8_Click_1);
            // 
            // guna2TileButton7
            // 
            this.guna2TileButton7.BorderRadius = 30;
            this.guna2TileButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton7.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton7.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton7.Location = new System.Drawing.Point(76, 297);
            this.guna2TileButton7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton7.Name = "guna2TileButton7";
            this.guna2TileButton7.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton7.TabIndex = 19;
            this.guna2TileButton7.Text = "Client Payments";
            this.guna2TileButton7.Click += new System.EventHandler(this.guna2TileButton7_Click_1);
            // 
            // guna2TileButton6
            // 
            this.guna2TileButton6.BorderRadius = 30;
            this.guna2TileButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold);
            this.guna2TileButton6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton6.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton6.Location = new System.Drawing.Point(76, 94);
            this.guna2TileButton6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton6.Name = "guna2TileButton6";
            this.guna2TileButton6.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton6.TabIndex = 18;
            this.guna2TileButton6.Text = "Salary Payments";
            this.guna2TileButton6.Click += new System.EventHandler(this.guna2TileButton6_Click);
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage10.Controls.Add(this.dgvMeetings);
            this.tabPage10.Controls.Add(this.guna2Panel5);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel25);
            this.tabPage10.Controls.Add(this.summary);
            this.tabPage10.Controls.Add(this.meetingParticipantsListBox);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel8);
            this.tabPage10.Controls.Add(this.meetingDatePicker);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel9);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel20);
            this.tabPage10.Controls.Add(this.meetingTitleTextBox);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel3);
            this.tabPage10.Location = new System.Drawing.Point(194, 4);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(1153, 671);
            this.tabPage10.TabIndex = 11;
            this.tabPage10.Text = "Meeting Management";
            // 
            // dgvMeetings
            // 
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            this.dgvMeetings.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dgvMeetings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMeetings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvMeetings.ColumnHeadersHeight = 30;
            this.dgvMeetings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMeetings.DefaultCellStyle = dataGridViewCellStyle23;
            this.dgvMeetings.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvMeetings.Location = new System.Drawing.Point(492, 97);
            this.dgvMeetings.Name = "dgvMeetings";
            this.dgvMeetings.ReadOnly = true;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMeetings.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvMeetings.RowHeadersVisible = false;
            this.dgvMeetings.RowHeadersWidth = 51;
            dataGridViewCellStyle25.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvMeetings.RowsDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvMeetings.RowTemplate.Height = 24;
            this.dgvMeetings.Size = new System.Drawing.Size(584, 511);
            this.dgvMeetings.TabIndex = 250;
            this.dgvMeetings.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvMeetings.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvMeetings.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvMeetings.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvMeetings.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvMeetings.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvMeetings.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvMeetings.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvMeetings.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvMeetings.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvMeetings.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvMeetings.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvMeetings.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvMeetings.ThemeStyle.ReadOnly = true;
            this.dgvMeetings.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvMeetings.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvMeetings.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvMeetings.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvMeetings.ThemeStyle.RowsStyle.Height = 24;
            this.dgvMeetings.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvMeetings.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvMeetings.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMeetings_CellContentClick_1);
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Panel5.BorderThickness = 2;
            this.guna2Panel5.Controls.Add(this.guna2HtmlLabel32);
            this.guna2Panel5.Controls.Add(this.meetingIdTextBox);
            this.guna2Panel5.Controls.Add(this.guna2Button17);
            this.guna2Panel5.Location = new System.Drawing.Point(25, 97);
            this.guna2Panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.Size = new System.Drawing.Size(433, 146);
            this.guna2Panel5.TabIndex = 127;
            // 
            // guna2HtmlLabel32
            // 
            this.guna2HtmlLabel32.AutoSize = false;
            this.guna2HtmlLabel32.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel32.Location = new System.Drawing.Point(24, 33);
            this.guna2HtmlLabel32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel32.Name = "guna2HtmlLabel32";
            this.guna2HtmlLabel32.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel32.TabIndex = 114;
            this.guna2HtmlLabel32.Text = "Meeting ID";
            // 
            // meetingIdTextBox
            // 
            this.meetingIdTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.meetingIdTextBox.BorderRadius = 5;
            this.meetingIdTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.meetingIdTextBox.DefaultText = "";
            this.meetingIdTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.meetingIdTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.meetingIdTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.meetingIdTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.meetingIdTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.meetingIdTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.meetingIdTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.meetingIdTextBox.Location = new System.Drawing.Point(187, 20);
            this.meetingIdTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.meetingIdTextBox.Name = "meetingIdTextBox";
            this.meetingIdTextBox.PasswordChar = '\0';
            this.meetingIdTextBox.PlaceholderText = "Enter Meeting Id ( M001 )";
            this.meetingIdTextBox.SelectedText = "";
            this.meetingIdTextBox.Size = new System.Drawing.Size(232, 48);
            this.meetingIdTextBox.TabIndex = 113;
            // 
            // guna2Button17
            // 
            this.guna2Button17.BorderRadius = 5;
            this.guna2Button17.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button17.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.Location = new System.Drawing.Point(275, 81);
            this.guna2Button17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.Size = new System.Drawing.Size(145, 46);
            this.guna2Button17.TabIndex = 112;
            this.guna2Button17.Text = "Search";
            this.guna2Button17.Click += new System.EventHandler(this.guna2Button17_Click);
            // 
            // guna2HtmlLabel25
            // 
            this.guna2HtmlLabel25.AutoSize = false;
            this.guna2HtmlLabel25.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel25.Location = new System.Drawing.Point(49, 498);
            this.guna2HtmlLabel25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel25.Name = "guna2HtmlLabel25";
            this.guna2HtmlLabel25.Size = new System.Drawing.Size(227, 34);
            this.guna2HtmlLabel25.TabIndex = 113;
            this.guna2HtmlLabel25.Text = "Summary";
            // 
            // summary
            // 
            this.summary.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.summary.BorderRadius = 5;
            this.summary.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.summary.DefaultText = "";
            this.summary.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.summary.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.summary.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.summary.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.summary.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.summary.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.summary.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.summary.Location = new System.Drawing.Point(209, 458);
            this.summary.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.summary.Name = "summary";
            this.summary.PasswordChar = '\0';
            this.summary.PlaceholderText = "";
            this.summary.SelectedText = "";
            this.summary.Size = new System.Drawing.Size(235, 114);
            this.summary.TabIndex = 112;
            // 
            // meetingParticipantsListBox
            // 
            this.meetingParticipantsListBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.meetingParticipantsListBox.ItemHeight = 16;
            this.meetingParticipantsListBox.Location = new System.Drawing.Point(212, 382);
            this.meetingParticipantsListBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.meetingParticipantsListBox.Name = "meetingParticipantsListBox";
            this.meetingParticipantsListBox.Size = new System.Drawing.Size(231, 66);
            this.meetingParticipantsListBox.TabIndex = 43;
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.AutoSize = false;
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(49, 404);
            this.guna2HtmlLabel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(227, 34);
            this.guna2HtmlLabel8.TabIndex = 50;
            this.guna2HtmlLabel8.Text = "Participants";
            // 
            // meetingDatePicker
            // 
            this.meetingDatePicker.BackColor = System.Drawing.Color.Transparent;
            this.meetingDatePicker.BorderRadius = 5;
            this.meetingDatePicker.BorderThickness = 1;
            this.meetingDatePicker.Checked = true;
            this.meetingDatePicker.FillColor = System.Drawing.Color.White;
            this.meetingDatePicker.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.meetingDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.meetingDatePicker.Location = new System.Drawing.Point(212, 322);
            this.meetingDatePicker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.meetingDatePicker.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.meetingDatePicker.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.meetingDatePicker.Name = "meetingDatePicker";
            this.meetingDatePicker.Size = new System.Drawing.Size(232, 48);
            this.meetingDatePicker.TabIndex = 49;
            this.meetingDatePicker.Value = new System.DateTime(2024, 10, 3, 6, 26, 41, 707);
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(49, 334);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(179, 48);
            this.guna2HtmlLabel9.TabIndex = 48;
            this.guna2HtmlLabel9.Text = "Date";
            // 
            // guna2HtmlLabel20
            // 
            this.guna2HtmlLabel20.AutoSize = false;
            this.guna2HtmlLabel20.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel20.Location = new System.Drawing.Point(49, 277);
            this.guna2HtmlLabel20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel20.Name = "guna2HtmlLabel20";
            this.guna2HtmlLabel20.Size = new System.Drawing.Size(196, 48);
            this.guna2HtmlLabel20.TabIndex = 47;
            this.guna2HtmlLabel20.Text = "Title";
            // 
            // meetingTitleTextBox
            // 
            this.meetingTitleTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.meetingTitleTextBox.BorderRadius = 5;
            this.meetingTitleTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.meetingTitleTextBox.DefaultText = "";
            this.meetingTitleTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.meetingTitleTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.meetingTitleTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.meetingTitleTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.meetingTitleTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.meetingTitleTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.meetingTitleTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.meetingTitleTextBox.Location = new System.Drawing.Point(212, 263);
            this.meetingTitleTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.meetingTitleTextBox.Name = "meetingTitleTextBox";
            this.meetingTitleTextBox.PasswordChar = '\0';
            this.meetingTitleTextBox.PlaceholderText = "";
            this.meetingTitleTextBox.SelectedText = "";
            this.meetingTitleTextBox.Size = new System.Drawing.Size(232, 48);
            this.meetingTitleTextBox.TabIndex = 45;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.AutoSize = false;
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(268, 15);
            this.guna2HtmlLabel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(808, 48);
            this.guna2HtmlLabel3.TabIndex = 14;
            this.guna2HtmlLabel3.Text = "Meeting Informations";
            this.guna2HtmlLabel3.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage5.Controls.Add(this.dgvsales);
            this.tabPage5.Controls.Add(this.salesDateTextBox);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel34);
            this.tabPage5.Controls.Add(this.orderIdTextBox);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel26);
            this.tabPage5.Controls.Add(this.clientPaymentIdTextBox);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel35);
            this.tabPage5.Controls.Add(this.clientIdTextBox);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel39);
            this.tabPage5.Controls.Add(this.salesStatusComboBox);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel41);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel43);
            this.tabPage5.Controls.Add(this.salesAmountTextBox);
            this.tabPage5.Controls.Add(this.guna2Panel6);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel22);
            this.tabPage5.Location = new System.Drawing.Point(194, 4);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1153, 671);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Sales Management";
            // 
            // dgvsales
            // 
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.White;
            this.dgvsales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvsales.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvsales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvsales.ColumnHeadersHeight = 30;
            this.dgvsales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvsales.DefaultCellStyle = dataGridViewCellStyle28;
            this.dgvsales.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvsales.Location = new System.Drawing.Point(486, 97);
            this.dgvsales.Name = "dgvsales";
            this.dgvsales.ReadOnly = true;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvsales.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvsales.RowHeadersVisible = false;
            this.dgvsales.RowHeadersWidth = 51;
            dataGridViewCellStyle30.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvsales.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvsales.RowTemplate.Height = 24;
            this.dgvsales.Size = new System.Drawing.Size(584, 514);
            this.dgvsales.TabIndex = 239;
            this.dgvsales.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvsales.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvsales.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvsales.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvsales.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvsales.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvsales.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvsales.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvsales.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvsales.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvsales.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvsales.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvsales.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvsales.ThemeStyle.ReadOnly = true;
            this.dgvsales.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvsales.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvsales.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvsales.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvsales.ThemeStyle.RowsStyle.Height = 24;
            this.dgvsales.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvsales.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvsales.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvsales_CellContentClick_1);
            // 
            // salesDateTextBox
            // 
            this.salesDateTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.salesDateTextBox.BorderRadius = 5;
            this.salesDateTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.salesDateTextBox.DefaultText = "";
            this.salesDateTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.salesDateTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.salesDateTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesDateTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesDateTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesDateTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.salesDateTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesDateTextBox.Location = new System.Drawing.Point(198, 577);
            this.salesDateTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.salesDateTextBox.Name = "salesDateTextBox";
            this.salesDateTextBox.PasswordChar = '\0';
            this.salesDateTextBox.PlaceholderText = "";
            this.salesDateTextBox.ReadOnly = true;
            this.salesDateTextBox.SelectedText = "";
            this.salesDateTextBox.Size = new System.Drawing.Size(233, 48);
            this.salesDateTextBox.TabIndex = 238;
            // 
            // guna2HtmlLabel34
            // 
            this.guna2HtmlLabel34.AutoSize = false;
            this.guna2HtmlLabel34.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel34.Location = new System.Drawing.Point(40, 332);
            this.guna2HtmlLabel34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel34.Name = "guna2HtmlLabel34";
            this.guna2HtmlLabel34.Size = new System.Drawing.Size(245, 41);
            this.guna2HtmlLabel34.TabIndex = 237;
            this.guna2HtmlLabel34.Text = "Client ID";
            // 
            // orderIdTextBox
            // 
            this.orderIdTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.orderIdTextBox.BorderRadius = 5;
            this.orderIdTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.orderIdTextBox.DefaultText = "";
            this.orderIdTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.orderIdTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.orderIdTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.orderIdTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.orderIdTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.orderIdTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.orderIdTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.orderIdTextBox.Location = new System.Drawing.Point(202, 264);
            this.orderIdTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.orderIdTextBox.Name = "orderIdTextBox";
            this.orderIdTextBox.PasswordChar = '\0';
            this.orderIdTextBox.PlaceholderText = "";
            this.orderIdTextBox.ReadOnly = true;
            this.orderIdTextBox.SelectedText = "";
            this.orderIdTextBox.Size = new System.Drawing.Size(232, 48);
            this.orderIdTextBox.TabIndex = 227;
            // 
            // guna2HtmlLabel26
            // 
            this.guna2HtmlLabel26.AutoSize = false;
            this.guna2HtmlLabel26.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel26.Location = new System.Drawing.Point(40, 397);
            this.guna2HtmlLabel26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel26.Name = "guna2HtmlLabel26";
            this.guna2HtmlLabel26.Size = new System.Drawing.Size(141, 48);
            this.guna2HtmlLabel26.TabIndex = 236;
            this.guna2HtmlLabel26.Text = "Payment ID";
            // 
            // clientPaymentIdTextBox
            // 
            this.clientPaymentIdTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.clientPaymentIdTextBox.BorderRadius = 5;
            this.clientPaymentIdTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.clientPaymentIdTextBox.DefaultText = "";
            this.clientPaymentIdTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.clientPaymentIdTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.clientPaymentIdTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.clientPaymentIdTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.clientPaymentIdTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.clientPaymentIdTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clientPaymentIdTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.clientPaymentIdTextBox.Location = new System.Drawing.Point(199, 385);
            this.clientPaymentIdTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.clientPaymentIdTextBox.Name = "clientPaymentIdTextBox";
            this.clientPaymentIdTextBox.PasswordChar = '\0';
            this.clientPaymentIdTextBox.PlaceholderText = "";
            this.clientPaymentIdTextBox.ReadOnly = true;
            this.clientPaymentIdTextBox.SelectedText = "";
            this.clientPaymentIdTextBox.Size = new System.Drawing.Size(233, 48);
            this.clientPaymentIdTextBox.TabIndex = 235;
            // 
            // guna2HtmlLabel35
            // 
            this.guna2HtmlLabel35.AutoSize = false;
            this.guna2HtmlLabel35.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel35.Location = new System.Drawing.Point(40, 278);
            this.guna2HtmlLabel35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel35.Name = "guna2HtmlLabel35";
            this.guna2HtmlLabel35.Size = new System.Drawing.Size(245, 41);
            this.guna2HtmlLabel35.TabIndex = 234;
            this.guna2HtmlLabel35.Text = "Order ID";
            // 
            // clientIdTextBox
            // 
            this.clientIdTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.clientIdTextBox.BorderRadius = 5;
            this.clientIdTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.clientIdTextBox.DefaultText = "";
            this.clientIdTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.clientIdTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.clientIdTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.clientIdTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.clientIdTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.clientIdTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clientIdTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.clientIdTextBox.Location = new System.Drawing.Point(200, 325);
            this.clientIdTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.clientIdTextBox.Name = "clientIdTextBox";
            this.clientIdTextBox.PasswordChar = '\0';
            this.clientIdTextBox.PlaceholderText = "";
            this.clientIdTextBox.ReadOnly = true;
            this.clientIdTextBox.SelectedText = "";
            this.clientIdTextBox.Size = new System.Drawing.Size(233, 48);
            this.clientIdTextBox.TabIndex = 233;
            // 
            // guna2HtmlLabel39
            // 
            this.guna2HtmlLabel39.AutoSize = false;
            this.guna2HtmlLabel39.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel39.Location = new System.Drawing.Point(40, 518);
            this.guna2HtmlLabel39.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel39.Name = "guna2HtmlLabel39";
            this.guna2HtmlLabel39.Size = new System.Drawing.Size(201, 53);
            this.guna2HtmlLabel39.TabIndex = 232;
            this.guna2HtmlLabel39.Text = "Sales Status";
            // 
            // salesStatusComboBox
            // 
            this.salesStatusComboBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.salesStatusComboBox.BorderRadius = 5;
            this.salesStatusComboBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.salesStatusComboBox.DefaultText = "";
            this.salesStatusComboBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.salesStatusComboBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.salesStatusComboBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesStatusComboBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesStatusComboBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesStatusComboBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.salesStatusComboBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesStatusComboBox.Location = new System.Drawing.Point(200, 509);
            this.salesStatusComboBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.salesStatusComboBox.Name = "salesStatusComboBox";
            this.salesStatusComboBox.PasswordChar = '\0';
            this.salesStatusComboBox.PlaceholderText = "";
            this.salesStatusComboBox.ReadOnly = true;
            this.salesStatusComboBox.SelectedText = "";
            this.salesStatusComboBox.Size = new System.Drawing.Size(233, 48);
            this.salesStatusComboBox.TabIndex = 231;
            // 
            // guna2HtmlLabel41
            // 
            this.guna2HtmlLabel41.AutoSize = false;
            this.guna2HtmlLabel41.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel41.Location = new System.Drawing.Point(40, 577);
            this.guna2HtmlLabel41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel41.Name = "guna2HtmlLabel41";
            this.guna2HtmlLabel41.Size = new System.Drawing.Size(227, 48);
            this.guna2HtmlLabel41.TabIndex = 230;
            this.guna2HtmlLabel41.Text = "Date of Sale";
            // 
            // guna2HtmlLabel43
            // 
            this.guna2HtmlLabel43.AutoSize = false;
            this.guna2HtmlLabel43.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel43.Location = new System.Drawing.Point(40, 461);
            this.guna2HtmlLabel43.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel43.Name = "guna2HtmlLabel43";
            this.guna2HtmlLabel43.Size = new System.Drawing.Size(201, 53);
            this.guna2HtmlLabel43.TabIndex = 229;
            this.guna2HtmlLabel43.Text = "Sales Amount";
            // 
            // salesAmountTextBox
            // 
            this.salesAmountTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.salesAmountTextBox.BorderRadius = 5;
            this.salesAmountTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.salesAmountTextBox.DefaultText = "";
            this.salesAmountTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.salesAmountTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.salesAmountTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesAmountTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesAmountTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesAmountTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.salesAmountTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesAmountTextBox.Location = new System.Drawing.Point(200, 447);
            this.salesAmountTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.salesAmountTextBox.Name = "salesAmountTextBox";
            this.salesAmountTextBox.PasswordChar = '\0';
            this.salesAmountTextBox.PlaceholderText = "";
            this.salesAmountTextBox.ReadOnly = true;
            this.salesAmountTextBox.SelectedText = "";
            this.salesAmountTextBox.Size = new System.Drawing.Size(233, 48);
            this.salesAmountTextBox.TabIndex = 228;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Panel6.BorderThickness = 2;
            this.guna2Panel6.Controls.Add(this.salesIdTextBox);
            this.guna2Panel6.Controls.Add(this.guna2Button13);
            this.guna2Panel6.Controls.Add(this.guna2HtmlLabel21);
            this.guna2Panel6.Location = new System.Drawing.Point(25, 97);
            this.guna2Panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.Size = new System.Drawing.Size(433, 146);
            this.guna2Panel6.TabIndex = 225;
            // 
            // salesIdTextBox
            // 
            this.salesIdTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.salesIdTextBox.BorderRadius = 5;
            this.salesIdTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.salesIdTextBox.DefaultText = "";
            this.salesIdTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.salesIdTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.salesIdTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesIdTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.salesIdTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesIdTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.salesIdTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.salesIdTextBox.Location = new System.Drawing.Point(183, 23);
            this.salesIdTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.salesIdTextBox.Name = "salesIdTextBox";
            this.salesIdTextBox.PasswordChar = '\0';
            this.salesIdTextBox.PlaceholderText = "Enter Sales Id ( SL001 )";
            this.salesIdTextBox.SelectedText = "";
            this.salesIdTextBox.Size = new System.Drawing.Size(232, 48);
            this.salesIdTextBox.TabIndex = 113;
            // 
            // guna2Button13
            // 
            this.guna2Button13.BorderRadius = 5;
            this.guna2Button13.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button13.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.Location = new System.Drawing.Point(271, 82);
            this.guna2Button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.Size = new System.Drawing.Size(145, 46);
            this.guna2Button13.TabIndex = 112;
            this.guna2Button13.Text = "Search";
            this.guna2Button13.Click += new System.EventHandler(this.guna2Button13_Click);
            // 
            // guna2HtmlLabel21
            // 
            this.guna2HtmlLabel21.AutoSize = false;
            this.guna2HtmlLabel21.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel21.Location = new System.Drawing.Point(24, 34);
            this.guna2HtmlLabel21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel21.Name = "guna2HtmlLabel21";
            this.guna2HtmlLabel21.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel21.TabIndex = 111;
            this.guna2HtmlLabel21.Text = "Sales ID";
            // 
            // guna2HtmlLabel22
            // 
            this.guna2HtmlLabel22.AutoSize = false;
            this.guna2HtmlLabel22.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel22.Location = new System.Drawing.Point(263, 16);
            this.guna2HtmlLabel22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel22.Name = "guna2HtmlLabel22";
            this.guna2HtmlLabel22.Size = new System.Drawing.Size(804, 48);
            this.guna2HtmlLabel22.TabIndex = 224;
            this.guna2HtmlLabel22.Text = "Sales Informations";
            this.guna2HtmlLabel22.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage4.Controls.Add(this.dgvFeedback);
            this.tabPage4.Controls.Add(this.sendc);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel47);
            this.tabPage4.Controls.Add(this.cmbFeedbackType);
            this.tabPage4.Controls.Add(this.txtFeedback);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel6);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel7);
            this.tabPage4.Controls.Add(this.txtEmpName);
            this.tabPage4.Controls.Add(this.txtEmpId);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel27);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel24);
            this.tabPage4.Location = new System.Drawing.Point(194, 4);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1153, 671);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Feedback Management";
            // 
            // dgvFeedback
            // 
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvFeedback.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFeedback.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.dgvFeedback.ColumnHeadersHeight = 30;
            this.dgvFeedback.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFeedback.DefaultCellStyle = dataGridViewCellStyle33;
            this.dgvFeedback.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.Location = new System.Drawing.Point(469, 98);
            this.dgvFeedback.Name = "dgvFeedback";
            this.dgvFeedback.ReadOnly = true;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFeedback.RowHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgvFeedback.RowHeadersVisible = false;
            this.dgvFeedback.RowHeadersWidth = 51;
            dataGridViewCellStyle35.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.dgvFeedback.RowsDefaultCellStyle = dataGridViewCellStyle35;
            this.dgvFeedback.RowTemplate.Height = 24;
            this.dgvFeedback.Size = new System.Drawing.Size(584, 514);
            this.dgvFeedback.TabIndex = 253;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvFeedback.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvFeedback.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvFeedback.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvFeedback.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvFeedback.ThemeStyle.ReadOnly = true;
            this.dgvFeedback.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvFeedback.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvFeedback.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvFeedback.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvFeedback.ThemeStyle.RowsStyle.Height = 24;
            this.dgvFeedback.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvFeedback.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvFeedback.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFeedback_CellContentClick);
            // 
            // sendc
            // 
            this.sendc.BorderRadius = 5;
            this.sendc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.sendc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.sendc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.sendc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.sendc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.sendc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sendc.ForeColor = System.Drawing.Color.DarkGray;
            this.sendc.Location = new System.Drawing.Point(283, 376);
            this.sendc.Name = "sendc";
            this.sendc.Size = new System.Drawing.Size(145, 45);
            this.sendc.TabIndex = 252;
            this.sendc.Text = "Send";
            this.sendc.Click += new System.EventHandler(this.sendc_Click);
            // 
            // guna2HtmlLabel47
            // 
            this.guna2HtmlLabel47.AutoSize = false;
            this.guna2HtmlLabel47.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel47.Location = new System.Drawing.Point(35, 169);
            this.guna2HtmlLabel47.Name = "guna2HtmlLabel47";
            this.guna2HtmlLabel47.Size = new System.Drawing.Size(272, 48);
            this.guna2HtmlLabel47.TabIndex = 251;
            this.guna2HtmlLabel47.Text = "Employee Name";
            this.guna2HtmlLabel47.Click += new System.EventHandler(this.guna2HtmlLabel47_Click);
            // 
            // cmbFeedbackType
            // 
            this.cmbFeedbackType.BackColor = System.Drawing.Color.Transparent;
            this.cmbFeedbackType.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbFeedbackType.BorderRadius = 5;
            this.cmbFeedbackType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbFeedbackType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFeedbackType.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbFeedbackType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbFeedbackType.ItemHeight = 30;
            this.cmbFeedbackType.Items.AddRange(new object[] {
            "Complaint",
            "Suggestion",
            "Inquiry"});
            this.cmbFeedbackType.Location = new System.Drawing.Point(196, 218);
            this.cmbFeedbackType.Name = "cmbFeedbackType";
            this.cmbFeedbackType.Size = new System.Drawing.Size(232, 36);
            this.cmbFeedbackType.TabIndex = 250;
            this.cmbFeedbackType.SelectedIndexChanged += new System.EventHandler(this.cmbFeedbackType_SelectedIndexChanged);
            // 
            // txtFeedback
            // 
            this.txtFeedback.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtFeedback.BorderRadius = 5;
            this.txtFeedback.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFeedback.DefaultText = "";
            this.txtFeedback.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtFeedback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtFeedback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtFeedback.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Location = new System.Drawing.Point(196, 271);
            this.txtFeedback.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.PasswordChar = '\0';
            this.txtFeedback.PlaceholderText = "";
            this.txtFeedback.SelectedText = "";
            this.txtFeedback.Size = new System.Drawing.Size(232, 82);
            this.txtFeedback.TabIndex = 249;
            this.txtFeedback.TextChanged += new System.EventHandler(this.txtFeedback_TextChanged);
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.AutoSize = false;
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(35, 226);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel6.TabIndex = 248;
            this.guna2HtmlLabel6.Text = "Feedback Type";
            this.guna2HtmlLabel6.Click += new System.EventHandler(this.guna2HtmlLabel6_Click);
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.AutoSize = false;
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(35, 112);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel7.TabIndex = 247;
            this.guna2HtmlLabel7.Text = "Employee Id";
            this.guna2HtmlLabel7.Click += new System.EventHandler(this.guna2HtmlLabel7_Click_1);
            // 
            // txtEmpName
            // 
            this.txtEmpName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpName.BorderRadius = 5;
            this.txtEmpName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpName.DefaultText = "";
            this.txtEmpName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Location = new System.Drawing.Point(196, 155);
            this.txtEmpName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.PasswordChar = '\0';
            this.txtEmpName.PlaceholderText = "";
            this.txtEmpName.ReadOnly = true;
            this.txtEmpName.SelectedText = "";
            this.txtEmpName.Size = new System.Drawing.Size(232, 48);
            this.txtEmpName.TabIndex = 246;
            this.txtEmpName.TextChanged += new System.EventHandler(this.txtEmpName_TextChanged);
            // 
            // txtEmpId
            // 
            this.txtEmpId.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpId.BorderRadius = 5;
            this.txtEmpId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpId.DefaultText = "";
            this.txtEmpId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Location = new System.Drawing.Point(196, 98);
            this.txtEmpId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.PasswordChar = '\0';
            this.txtEmpId.PlaceholderText = "";
            this.txtEmpId.ReadOnly = true;
            this.txtEmpId.SelectedText = "";
            this.txtEmpId.Size = new System.Drawing.Size(232, 48);
            this.txtEmpId.TabIndex = 245;
            this.txtEmpId.TextChanged += new System.EventHandler(this.txtEmpId_TextChanged);
            // 
            // guna2HtmlLabel27
            // 
            this.guna2HtmlLabel27.AutoSize = false;
            this.guna2HtmlLabel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel27.Location = new System.Drawing.Point(35, 295);
            this.guna2HtmlLabel27.Name = "guna2HtmlLabel27";
            this.guna2HtmlLabel27.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel27.TabIndex = 244;
            this.guna2HtmlLabel27.Text = "Feedback";
            this.guna2HtmlLabel27.Click += new System.EventHandler(this.guna2HtmlLabel27_Click);
            // 
            // guna2HtmlLabel24
            // 
            this.guna2HtmlLabel24.AutoSize = false;
            this.guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel24.Location = new System.Drawing.Point(300, 17);
            this.guna2HtmlLabel24.Name = "guna2HtmlLabel24";
            this.guna2HtmlLabel24.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel24.TabIndex = 243;
            this.guna2HtmlLabel24.Text = "Send Feedback";
            this.guna2HtmlLabel24.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.guna2HtmlLabel24.Click += new System.EventHandler(this.guna2HtmlLabel24_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button2.Image")));
            this.guna2Button2.ImageSize = new System.Drawing.Size(33, 33);
            this.guna2Button2.Location = new System.Drawing.Point(45, 783);
            this.guna2Button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(152, 57);
            this.guna2Button2.TabIndex = 22;
            this.guna2Button2.Text = "  Logout";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click_1);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.DarkGray;
            this.guna2Panel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel3.Location = new System.Drawing.Point(253, 789);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(1097, 62);
            this.guna2Panel3.TabIndex = 21;
            // 
            // guna2CircleButton2
            // 
            this.guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton2.Image")));
            this.guna2CircleButton2.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton2.Location = new System.Drawing.Point(1187, 18);
            this.guna2CircleButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton2.TabIndex = 27;
            this.guna2CircleButton2.Click += new System.EventHandler(this.guna2CircleButton2_Click_1);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton1.Image")));
            this.guna2CircleButton1.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton1.Location = new System.Drawing.Point(1261, 18);
            this.guna2CircleButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton1.TabIndex = 26;
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click_2);
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2ImageButton3.Location = new System.Drawing.Point(99, 18);
            this.guna2ImageButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Size = new System.Drawing.Size(64, 59);
            this.guna2ImageButton3.TabIndex = 25;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click_1);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(47, 67);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(115, 32);
            this.guna2HtmlLabel2.TabIndex = 24;
            this.guna2HtmlLabel2.Text = "COO";
            this.guna2HtmlLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(471, 28);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(583, 75);
            this.guna2HtmlLabel1.TabIndex = 23;
            this.guna2HtmlLabel1.Text = "Kitchen & Bedroom";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // guna2HtmlToolTip1
            // 
            this.guna2HtmlToolTip1.AllowLinksHandling = true;
            this.guna2HtmlToolTip1.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip2
            // 
            this.guna2HtmlToolTip2.AllowLinksHandling = true;
            this.guna2HtmlToolTip2.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip3
            // 
            this.guna2HtmlToolTip3.AllowLinksHandling = true;
            this.guna2HtmlToolTip3.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip4
            // 
            this.guna2HtmlToolTip4.AllowLinksHandling = true;
            this.guna2HtmlToolTip4.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip5
            // 
            this.guna2HtmlToolTip5.AllowLinksHandling = true;
            this.guna2HtmlToolTip5.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip6
            // 
            this.guna2HtmlToolTip6.AllowLinksHandling = true;
            this.guna2HtmlToolTip6.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // COO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(1349, 850);
            this.Controls.Add(this.guna2CircleButton2);
            this.Controls.Add(this.guna2CircleButton1);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2TabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "COO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "COO";
            this.Load += new System.EventHandler(this.COO_Load);
            this.guna2TabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplier)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.guna2Panel4.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView3)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMeetings)).EndInit();
            this.guna2Panel5.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvsales)).EndInit();
            this.guna2Panel6.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private System.Windows.Forms.TabPage tabPage10;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton9;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private System.Windows.Forms.ListBox meetingParticipantsListBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2DateTimePicker meetingDatePicker;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel20;
        private Guna.UI2.WinForms.Guna2TextBox meetingTitleTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel25;
        private Guna.UI2.WinForms.Guna2TextBox summary;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel33;
        private Guna.UI2.WinForms.Guna2TextBox phonebox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel29;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel30;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel31;
        private Guna.UI2.WinForms.Guna2TextBox mailbox;
        private Guna.UI2.WinForms.Guna2TextBox namebox;
        private Guna.UI2.WinForms.Guna2TextBox contactpersonbox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2Button rembtnsup;
        private Guna.UI2.WinForms.Guna2Button clrbtnsup;
        private Guna.UI2.WinForms.Guna2Button updbtnsup;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2TextBox projectid;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel19;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2TextBox ORDERBOX;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2TextBox CLIENTBOX;
        private Guna.UI2.WinForms.Guna2TextBox totalcost;
        private Guna.UI2.WinForms.Guna2TextBox labourcost;
        private Guna.UI2.WinForms.Guna2TextBox materialcost;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel16;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel17;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel15;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel18;
        private Guna.UI2.WinForms.Guna2TextBox PROJECTBOX;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2Button guna2Button11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel23;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel28;
        private Guna.UI2.WinForms.Guna2TextBox type;
        private Guna.UI2.WinForms.Guna2TextBox name;
        private Guna.UI2.WinForms.Guna2TextBox qty;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel32;
        private Guna.UI2.WinForms.Guna2TextBox meetingIdTextBox;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton8;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton7;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton6;
        private Guna.UI2.WinForms.Guna2DataGridView dgv1;
        private Guna.UI2.WinForms.Guna2Button addbtnsup;
        private Guna.UI2.WinForms.Guna2DataGridView dgvSupplier;
        private Guna.UI2.WinForms.Guna2TextBox accDeadline;
        private Guna.UI2.WinForms.Guna2DataGridView acctask;
        private Guna.UI2.WinForms.Guna2TextBox accPriority;
        private Guna.UI2.WinForms.Guna2ComboBox cmbaccStatuss;
        private Guna.UI2.WinForms.Guna2TextBox accTaskNames;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel40;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel38;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel37;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel36;
        private Guna.UI2.WinForms.Guna2Button updbtnacc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel42;
        private Guna.UI2.WinForms.Guna2DataGridView dgvFeedback;
        private Guna.UI2.WinForms.Guna2Button sendc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel47;
        private Guna.UI2.WinForms.Guna2ComboBox cmbFeedbackType;
        private Guna.UI2.WinForms.Guna2TextBox txtFeedback;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpName;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpId;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel27;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel24;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2TextBox submissiondate;
        private System.Windows.Forms.TabPage tabPage5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2TextBox salesIdTextBox;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel21;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel22;
        private Guna.UI2.WinForms.Guna2TextBox salesDateTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel34;
        private Guna.UI2.WinForms.Guna2TextBox orderIdTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel26;
        private Guna.UI2.WinForms.Guna2TextBox clientPaymentIdTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel35;
        private Guna.UI2.WinForms.Guna2TextBox clientIdTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel39;
        private Guna.UI2.WinForms.Guna2TextBox salesStatusComboBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel41;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel43;
        private Guna.UI2.WinForms.Guna2TextBox salesAmountTextBox;
        private Guna.UI2.WinForms.Guna2DataGridView dgvsales;
        private Guna.UI2.WinForms.Guna2DataGridView dgvMeetings;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView3;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip1;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip2;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip3;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip4;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip5;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel45;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel44;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox12;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox4;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton3;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel52;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel49;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox10;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton5;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel46;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel48;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox2;
    }
}