﻿namespace FinalProject
{
    partial class Payments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Payments));
            this.guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.accDeadline = new Guna.UI2.WinForms.Guna2TextBox();
            this.acctask = new Guna.UI2.WinForms.Guna2DataGridView();
            this.accPriority = new Guna.UI2.WinForms.Guna2TextBox();
            this.cmbaccStatuss = new Guna.UI2.WinForms.Guna2ComboBox();
            this.accTaskNames = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel40 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel38 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel37 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel36 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.updbtnacc = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel42 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.guna2TileButton7 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton6 = new Guna.UI2.WinForms.Guna2TileButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.Feetbackdgv = new Guna.UI2.WinForms.Guna2DataGridView();
            this.accsend = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel47 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmbFeedbackType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtFeedback = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel41 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel44 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtEmpName = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtEmpId = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel27 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel24 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlToolTip1 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip2 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip3 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip4 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip5 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlToolTip6 = new Guna.UI2.WinForms.Guna2HtmlToolTip();
            this.guna2HtmlLabel48 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel46 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel52 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel49 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton5 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2HtmlLabel45 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton3 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TileButton2 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Feetbackdgv)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2TabControl1
            // 
            this.guna2TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.guna2TabControl1.Controls.Add(this.tabPage5);
            this.guna2TabControl1.Controls.Add(this.tabPage6);
            this.guna2TabControl1.Controls.Add(this.tabPage1);
            this.guna2TabControl1.Controls.Add(this.tabPage4);
            this.guna2TabControl1.ItemSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.Location = new System.Drawing.Point(0, 114);
            this.guna2TabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TabControl1.Name = "guna2TabControl1";
            this.guna2TabControl1.SelectedIndex = 0;
            this.guna2TabControl1.Size = new System.Drawing.Size(1351, 679);
            this.guna2TabControl1.TabButtonHoverState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonHoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonHoverState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonHoverState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonIdleState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonIdleState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(160)))), ((int)(((byte)(167)))));
            this.guna2TabControl1.TabButtonIdleState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonSelectedState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonSelectedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(37)))), ((int)(((byte)(49)))));
            this.guna2TabControl1.TabButtonSelectedState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonSelectedState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonSelectedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(132)))), ((int)(((byte)(255)))));
            this.guna2TabControl1.TabButtonSize = new System.Drawing.Size(190, 50);
            this.guna2TabControl1.TabIndex = 18;
            this.guna2TabControl1.TabMenuBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage5.Controls.Add(this.guna2HtmlLabel48);
            this.tabPage5.Controls.Add(this.guna2TextBox2);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel46);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel52);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel49);
            this.tabPage5.Controls.Add(this.guna2TextBox6);
            this.tabPage5.Controls.Add(this.guna2TextBox10);
            this.tabPage5.Controls.Add(this.guna2Button8);
            this.tabPage5.Controls.Add(this.guna2Button4);
            this.tabPage5.Controls.Add(this.guna2TileButton5);
            this.tabPage5.Controls.Add(this.guna2TileButton4);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel45);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel3);
            this.tabPage5.Controls.Add(this.guna2TextBox1);
            this.tabPage5.Controls.Add(this.guna2TextBox4);
            this.tabPage5.Controls.Add(this.guna2Button6);
            this.tabPage5.Controls.Add(this.guna2TileButton3);
            this.tabPage5.Controls.Add(this.guna2Button3);
            this.tabPage5.Controls.Add(this.guna2TileButton1);
            this.tabPage5.Controls.Add(this.guna2Button1);
            this.tabPage5.Controls.Add(this.guna2TileButton2);
            this.tabPage5.Location = new System.Drawing.Point(194, 4);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1153, 671);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Dashboard";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage6.Controls.Add(this.accDeadline);
            this.tabPage6.Controls.Add(this.acctask);
            this.tabPage6.Controls.Add(this.accPriority);
            this.tabPage6.Controls.Add(this.cmbaccStatuss);
            this.tabPage6.Controls.Add(this.accTaskNames);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel40);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel38);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel37);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel36);
            this.tabPage6.Controls.Add(this.updbtnacc);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel42);
            this.tabPage6.Location = new System.Drawing.Point(194, 4);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1153, 671);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Task Management";
            // 
            // accDeadline
            // 
            this.accDeadline.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accDeadline.BorderRadius = 5;
            this.accDeadline.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accDeadline.DefaultText = "";
            this.accDeadline.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accDeadline.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accDeadline.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accDeadline.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accDeadline.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accDeadline.Location = new System.Drawing.Point(194, 158);
            this.accDeadline.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accDeadline.Name = "accDeadline";
            this.accDeadline.PasswordChar = '\0';
            this.accDeadline.PlaceholderText = "";
            this.accDeadline.ReadOnly = true;
            this.accDeadline.SelectedText = "";
            this.accDeadline.Size = new System.Drawing.Size(232, 48);
            this.accDeadline.TabIndex = 266;
            // 
            // acctask
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.acctask.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.acctask.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.acctask.ColumnHeadersHeight = 30;
            this.acctask.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.acctask.DefaultCellStyle = dataGridViewCellStyle3;
            this.acctask.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.Location = new System.Drawing.Point(475, 98);
            this.acctask.Name = "acctask";
            this.acctask.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acctask.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.acctask.RowHeadersVisible = false;
            this.acctask.RowHeadersWidth = 51;
            dataGridViewCellStyle5.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.acctask.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.acctask.RowTemplate.Height = 24;
            this.acctask.Size = new System.Drawing.Size(584, 514);
            this.acctask.TabIndex = 265;
            this.acctask.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.acctask.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.acctask.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.acctask.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.acctask.ThemeStyle.HeaderStyle.Height = 30;
            this.acctask.ThemeStyle.ReadOnly = true;
            this.acctask.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.acctask.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.acctask.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctask.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.ThemeStyle.RowsStyle.Height = 24;
            this.acctask.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.acctask.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.acctask.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.acctask_CellContentClick);
            // 
            // accPriority
            // 
            this.accPriority.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accPriority.BorderRadius = 5;
            this.accPriority.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accPriority.DefaultText = "";
            this.accPriority.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accPriority.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accPriority.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accPriority.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accPriority.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accPriority.Location = new System.Drawing.Point(195, 217);
            this.accPriority.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accPriority.Name = "accPriority";
            this.accPriority.PasswordChar = '\0';
            this.accPriority.PlaceholderText = "";
            this.accPriority.ReadOnly = true;
            this.accPriority.SelectedText = "";
            this.accPriority.Size = new System.Drawing.Size(232, 48);
            this.accPriority.TabIndex = 264;
            // 
            // cmbaccStatuss
            // 
            this.cmbaccStatuss.BackColor = System.Drawing.Color.Transparent;
            this.cmbaccStatuss.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbaccStatuss.BorderRadius = 5;
            this.cmbaccStatuss.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbaccStatuss.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbaccStatuss.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbaccStatuss.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbaccStatuss.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbaccStatuss.ItemHeight = 30;
            this.cmbaccStatuss.Items.AddRange(new object[] {
            "Pending",
            "Completed"});
            this.cmbaccStatuss.Location = new System.Drawing.Point(195, 276);
            this.cmbaccStatuss.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbaccStatuss.Name = "cmbaccStatuss";
            this.cmbaccStatuss.Size = new System.Drawing.Size(232, 36);
            this.cmbaccStatuss.TabIndex = 263;
            // 
            // accTaskNames
            // 
            this.accTaskNames.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accTaskNames.BorderRadius = 5;
            this.accTaskNames.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.accTaskNames.DefaultText = "";
            this.accTaskNames.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.accTaskNames.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.accTaskNames.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.accTaskNames.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accTaskNames.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.accTaskNames.Location = new System.Drawing.Point(195, 98);
            this.accTaskNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.accTaskNames.Name = "accTaskNames";
            this.accTaskNames.PasswordChar = '\0';
            this.accTaskNames.PlaceholderText = "";
            this.accTaskNames.ReadOnly = true;
            this.accTaskNames.SelectedText = "";
            this.accTaskNames.Size = new System.Drawing.Size(232, 48);
            this.accTaskNames.TabIndex = 262;
            // 
            // guna2HtmlLabel40
            // 
            this.guna2HtmlLabel40.AutoSize = false;
            this.guna2HtmlLabel40.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel40.Location = new System.Drawing.Point(51, 228);
            this.guna2HtmlLabel40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel40.Name = "guna2HtmlLabel40";
            this.guna2HtmlLabel40.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel40.TabIndex = 261;
            this.guna2HtmlLabel40.Text = "Priority";
            // 
            // guna2HtmlLabel38
            // 
            this.guna2HtmlLabel38.AutoSize = false;
            this.guna2HtmlLabel38.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel38.Location = new System.Drawing.Point(51, 286);
            this.guna2HtmlLabel38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel38.Name = "guna2HtmlLabel38";
            this.guna2HtmlLabel38.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel38.TabIndex = 260;
            this.guna2HtmlLabel38.Text = "Status";
            // 
            // guna2HtmlLabel37
            // 
            this.guna2HtmlLabel37.AutoSize = false;
            this.guna2HtmlLabel37.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel37.Location = new System.Drawing.Point(51, 110);
            this.guna2HtmlLabel37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel37.Name = "guna2HtmlLabel37";
            this.guna2HtmlLabel37.Size = new System.Drawing.Size(245, 34);
            this.guna2HtmlLabel37.TabIndex = 259;
            this.guna2HtmlLabel37.Text = "Task Name";
            // 
            // guna2HtmlLabel36
            // 
            this.guna2HtmlLabel36.AutoSize = false;
            this.guna2HtmlLabel36.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel36.Location = new System.Drawing.Point(51, 167);
            this.guna2HtmlLabel36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel36.Name = "guna2HtmlLabel36";
            this.guna2HtmlLabel36.Size = new System.Drawing.Size(245, 39);
            this.guna2HtmlLabel36.TabIndex = 258;
            this.guna2HtmlLabel36.Text = "Deadline";
            // 
            // updbtnacc
            // 
            this.updbtnacc.BorderRadius = 5;
            this.updbtnacc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updbtnacc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updbtnacc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.updbtnacc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updbtnacc.ForeColor = System.Drawing.Color.DarkGray;
            this.updbtnacc.Location = new System.Drawing.Point(281, 334);
            this.updbtnacc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updbtnacc.Name = "updbtnacc";
            this.updbtnacc.Size = new System.Drawing.Size(145, 46);
            this.updbtnacc.TabIndex = 257;
            this.updbtnacc.Text = "Update";
            this.updbtnacc.Click += new System.EventHandler(this.updbtnacc_Click);
            // 
            // guna2HtmlLabel42
            // 
            this.guna2HtmlLabel42.AutoSize = false;
            this.guna2HtmlLabel42.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel42.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel42.Location = new System.Drawing.Point(265, 17);
            this.guna2HtmlLabel42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel42.Name = "guna2HtmlLabel42";
            this.guna2HtmlLabel42.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel42.TabIndex = 256;
            this.guna2HtmlLabel42.Text = "My Tasks";
            this.guna2HtmlLabel42.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.guna2TileButton7);
            this.tabPage1.Controls.Add(this.guna2TileButton6);
            this.tabPage1.Location = new System.Drawing.Point(194, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1153, 671);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Meeting Management";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // guna2TileButton7
            // 
            this.guna2TileButton7.BorderRadius = 30;
            this.guna2TileButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton7.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton7.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton7.Location = new System.Drawing.Point(75, 394);
            this.guna2TileButton7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton7.Name = "guna2TileButton7";
            this.guna2TileButton7.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton7.TabIndex = 18;
            this.guna2TileButton7.Text = "Meeting Informations";
            this.guna2TileButton7.Click += new System.EventHandler(this.guna2TileButton7_Click);
            // 
            // guna2TileButton6
            // 
            this.guna2TileButton6.BorderRadius = 30;
            this.guna2TileButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold);
            this.guna2TileButton6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton6.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton6.Location = new System.Drawing.Point(75, 180);
            this.guna2TileButton6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton6.Name = "guna2TileButton6";
            this.guna2TileButton6.Size = new System.Drawing.Size(940, 158);
            this.guna2TileButton6.TabIndex = 17;
            this.guna2TileButton6.Text = "Meeting Schedule";
            this.guna2TileButton6.Click += new System.EventHandler(this.guna2TileButton6_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage4.Controls.Add(this.Feetbackdgv);
            this.tabPage4.Controls.Add(this.accsend);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel47);
            this.tabPage4.Controls.Add(this.cmbFeedbackType);
            this.tabPage4.Controls.Add(this.txtFeedback);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel41);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel44);
            this.tabPage4.Controls.Add(this.txtEmpName);
            this.tabPage4.Controls.Add(this.txtEmpId);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel27);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel24);
            this.tabPage4.Location = new System.Drawing.Point(194, 4);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1153, 671);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Feedback Management";
            // 
            // Feetbackdgv
            // 
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.Feetbackdgv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Feetbackdgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.Feetbackdgv.ColumnHeadersHeight = 30;
            this.Feetbackdgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Feetbackdgv.DefaultCellStyle = dataGridViewCellStyle8;
            this.Feetbackdgv.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.Location = new System.Drawing.Point(486, 97);
            this.Feetbackdgv.Name = "Feetbackdgv";
            this.Feetbackdgv.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Feetbackdgv.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.Feetbackdgv.RowHeadersVisible = false;
            this.Feetbackdgv.RowHeadersWidth = 51;
            dataGridViewCellStyle10.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.Feetbackdgv.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.Feetbackdgv.RowTemplate.Height = 24;
            this.Feetbackdgv.Size = new System.Drawing.Size(584, 514);
            this.Feetbackdgv.TabIndex = 255;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Feetbackdgv.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Feetbackdgv.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Feetbackdgv.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Feetbackdgv.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Feetbackdgv.ThemeStyle.HeaderStyle.Height = 30;
            this.Feetbackdgv.ThemeStyle.ReadOnly = true;
            this.Feetbackdgv.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Feetbackdgv.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Feetbackdgv.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Feetbackdgv.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Feetbackdgv.ThemeStyle.RowsStyle.Height = 24;
            this.Feetbackdgv.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Feetbackdgv.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Feetbackdgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Feetbackdgv_CellContentClick);
            // 
            // accsend
            // 
            this.accsend.BorderRadius = 5;
            this.accsend.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.accsend.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.accsend.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.accsend.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.accsend.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.accsend.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.accsend.ForeColor = System.Drawing.Color.DarkGray;
            this.accsend.Location = new System.Drawing.Point(295, 375);
            this.accsend.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.accsend.Name = "accsend";
            this.accsend.Size = new System.Drawing.Size(145, 46);
            this.accsend.TabIndex = 254;
            this.accsend.Text = "Send";
            this.accsend.Click += new System.EventHandler(this.accsend_Click);
            // 
            // guna2HtmlLabel47
            // 
            this.guna2HtmlLabel47.AutoSize = false;
            this.guna2HtmlLabel47.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel47.Location = new System.Drawing.Point(47, 167);
            this.guna2HtmlLabel47.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel47.Name = "guna2HtmlLabel47";
            this.guna2HtmlLabel47.Size = new System.Drawing.Size(272, 48);
            this.guna2HtmlLabel47.TabIndex = 253;
            this.guna2HtmlLabel47.Text = "Employee Name";
            // 
            // cmbFeedbackType
            // 
            this.cmbFeedbackType.BackColor = System.Drawing.Color.Transparent;
            this.cmbFeedbackType.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.cmbFeedbackType.BorderRadius = 5;
            this.cmbFeedbackType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbFeedbackType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFeedbackType.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbFeedbackType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbFeedbackType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbFeedbackType.ItemHeight = 30;
            this.cmbFeedbackType.Items.AddRange(new object[] {
            "Complaint",
            "Suggestion",
            "Inquiry"});
            this.cmbFeedbackType.Location = new System.Drawing.Point(208, 217);
            this.cmbFeedbackType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbFeedbackType.Name = "cmbFeedbackType";
            this.cmbFeedbackType.Size = new System.Drawing.Size(232, 36);
            this.cmbFeedbackType.TabIndex = 252;
            // 
            // txtFeedback
            // 
            this.txtFeedback.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtFeedback.BorderRadius = 5;
            this.txtFeedback.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFeedback.DefaultText = "";
            this.txtFeedback.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtFeedback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtFeedback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtFeedback.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtFeedback.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFeedback.Location = new System.Drawing.Point(208, 270);
            this.txtFeedback.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.PasswordChar = '\0';
            this.txtFeedback.PlaceholderText = "";
            this.txtFeedback.SelectedText = "";
            this.txtFeedback.Size = new System.Drawing.Size(232, 82);
            this.txtFeedback.TabIndex = 251;
            // 
            // guna2HtmlLabel41
            // 
            this.guna2HtmlLabel41.AutoSize = false;
            this.guna2HtmlLabel41.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel41.Location = new System.Drawing.Point(47, 225);
            this.guna2HtmlLabel41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel41.Name = "guna2HtmlLabel41";
            this.guna2HtmlLabel41.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel41.TabIndex = 250;
            this.guna2HtmlLabel41.Text = "Feedback Type";
            // 
            // guna2HtmlLabel44
            // 
            this.guna2HtmlLabel44.AutoSize = false;
            this.guna2HtmlLabel44.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel44.Location = new System.Drawing.Point(47, 111);
            this.guna2HtmlLabel44.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel44.Name = "guna2HtmlLabel44";
            this.guna2HtmlLabel44.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel44.TabIndex = 249;
            this.guna2HtmlLabel44.Text = "Employee Id";
            // 
            // txtEmpName
            // 
            this.txtEmpName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpName.BorderRadius = 5;
            this.txtEmpName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpName.DefaultText = "";
            this.txtEmpName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpName.Location = new System.Drawing.Point(208, 154);
            this.txtEmpName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.PasswordChar = '\0';
            this.txtEmpName.PlaceholderText = "";
            this.txtEmpName.ReadOnly = true;
            this.txtEmpName.SelectedText = "";
            this.txtEmpName.Size = new System.Drawing.Size(232, 48);
            this.txtEmpName.TabIndex = 248;
            // 
            // txtEmpId
            // 
            this.txtEmpId.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.txtEmpId.BorderRadius = 5;
            this.txtEmpId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpId.DefaultText = "";
            this.txtEmpId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmpId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmpId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmpId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmpId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmpId.Location = new System.Drawing.Point(208, 97);
            this.txtEmpId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.PasswordChar = '\0';
            this.txtEmpId.PlaceholderText = "";
            this.txtEmpId.ReadOnly = true;
            this.txtEmpId.SelectedText = "";
            this.txtEmpId.Size = new System.Drawing.Size(232, 48);
            this.txtEmpId.TabIndex = 247;
            // 
            // guna2HtmlLabel27
            // 
            this.guna2HtmlLabel27.AutoSize = false;
            this.guna2HtmlLabel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel27.Location = new System.Drawing.Point(47, 294);
            this.guna2HtmlLabel27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel27.Name = "guna2HtmlLabel27";
            this.guna2HtmlLabel27.Size = new System.Drawing.Size(245, 48);
            this.guna2HtmlLabel27.TabIndex = 246;
            this.guna2HtmlLabel27.Text = "Feedback";
            // 
            // guna2HtmlLabel24
            // 
            this.guna2HtmlLabel24.AutoSize = false;
            this.guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel24.Location = new System.Drawing.Point(300, 16);
            this.guna2HtmlLabel24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel24.Name = "guna2HtmlLabel24";
            this.guna2HtmlLabel24.Size = new System.Drawing.Size(700, 48);
            this.guna2HtmlLabel24.TabIndex = 245;
            this.guna2HtmlLabel24.Text = "Send Feedback";
            this.guna2HtmlLabel24.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // guna2CircleButton2
            // 
            this.guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton2.Image")));
            this.guna2CircleButton2.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton2.Location = new System.Drawing.Point(1187, 18);
            this.guna2CircleButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton2.TabIndex = 23;
            this.guna2CircleButton2.Click += new System.EventHandler(this.guna2CircleButton2_Click_1);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton1.Image")));
            this.guna2CircleButton1.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2CircleButton1.Location = new System.Drawing.Point(1261, 18);
            this.guna2CircleButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.Size = new System.Drawing.Size(77, 69);
            this.guna2CircleButton1.TabIndex = 22;
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click_1);
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2ImageButton3.Location = new System.Drawing.Point(99, 18);
            this.guna2ImageButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2ImageButton3.Size = new System.Drawing.Size(64, 59);
            this.guna2ImageButton3.TabIndex = 21;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click_1);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(52, 71);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(115, 32);
            this.guna2HtmlLabel2.TabIndex = 20;
            this.guna2HtmlLabel2.Text = "Secretary";
            this.guna2HtmlLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(471, 28);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(583, 75);
            this.guna2HtmlLabel1.TabIndex = 19;
            this.guna2HtmlLabel1.Text = "Kitchen & Bedroom";
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button2.Image")));
            this.guna2Button2.ImageSize = new System.Drawing.Size(33, 33);
            this.guna2Button2.Location = new System.Drawing.Point(44, 784);
            this.guna2Button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(152, 57);
            this.guna2Button2.TabIndex = 25;
            this.guna2Button2.Text = "  Logout";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click_1);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.DarkGray;
            this.guna2Panel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel3.Location = new System.Drawing.Point(253, 790);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(1097, 62);
            this.guna2Panel3.TabIndex = 24;
            // 
            // guna2HtmlToolTip1
            // 
            this.guna2HtmlToolTip1.AllowLinksHandling = true;
            this.guna2HtmlToolTip1.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip2
            // 
            this.guna2HtmlToolTip2.AllowLinksHandling = true;
            this.guna2HtmlToolTip2.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip3
            // 
            this.guna2HtmlToolTip3.AllowLinksHandling = true;
            this.guna2HtmlToolTip3.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip4
            // 
            this.guna2HtmlToolTip4.AllowLinksHandling = true;
            this.guna2HtmlToolTip4.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip5
            // 
            this.guna2HtmlToolTip5.AllowLinksHandling = true;
            this.guna2HtmlToolTip5.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlToolTip6
            // 
            this.guna2HtmlToolTip6.AllowLinksHandling = true;
            this.guna2HtmlToolTip6.MaximumSize = new System.Drawing.Size(0, 0);
            // 
            // guna2HtmlLabel48
            // 
            this.guna2HtmlLabel48.AutoSize = false;
            this.guna2HtmlLabel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel48.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel48.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel48.Location = new System.Drawing.Point(803, 212);
            this.guna2HtmlLabel48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel48.Name = "guna2HtmlLabel48";
            this.guna2HtmlLabel48.Size = new System.Drawing.Size(239, 44);
            this.guna2HtmlLabel48.TabIndex = 156;
            this.guna2HtmlLabel48.Text = "Salary";
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.AutoSize = false;
            this.guna2TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox2.Location = new System.Drawing.Point(901, 170);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.Size = new System.Drawing.Size(194, 98);
            this.guna2TextBox2.TabIndex = 155;
            this.guna2TextBox2.Text = null;
            // 
            // guna2HtmlLabel46
            // 
            this.guna2HtmlLabel46.AutoSize = false;
            this.guna2HtmlLabel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel46.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel46.Location = new System.Drawing.Point(810, 499);
            this.guna2HtmlLabel46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel46.Name = "guna2HtmlLabel46";
            this.guna2HtmlLabel46.Size = new System.Drawing.Size(122, 44);
            this.guna2HtmlLabel46.TabIndex = 154;
            this.guna2HtmlLabel46.Text = "Tasks";
            // 
            // guna2HtmlLabel52
            // 
            this.guna2HtmlLabel52.AutoSize = false;
            this.guna2HtmlLabel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel52.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel52.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel52.Location = new System.Drawing.Point(146, 530);
            this.guna2HtmlLabel52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel52.Name = "guna2HtmlLabel52";
            this.guna2HtmlLabel52.Size = new System.Drawing.Size(327, 44);
            this.guna2HtmlLabel52.TabIndex = 153;
            this.guna2HtmlLabel52.Text = "Alert";
            // 
            // guna2HtmlLabel49
            // 
            this.guna2HtmlLabel49.AutoSize = false;
            this.guna2HtmlLabel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel49.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel49.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel49.Location = new System.Drawing.Point(137, 500);
            this.guna2HtmlLabel49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel49.Name = "guna2HtmlLabel49";
            this.guna2HtmlLabel49.Size = new System.Drawing.Size(349, 44);
            this.guna2HtmlLabel49.TabIndex = 152;
            this.guna2HtmlLabel49.Text = "Meeting";
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.AutoSize = false;
            this.guna2TextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox6.Location = new System.Drawing.Point(258, 456);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.Size = new System.Drawing.Size(785, 82);
            this.guna2TextBox6.TabIndex = 151;
            this.guna2TextBox6.Text = null;
            // 
            // guna2TextBox10
            // 
            this.guna2TextBox10.AutoSize = false;
            this.guna2TextBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox10.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox10.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox10.Location = new System.Drawing.Point(920, 435);
            this.guna2TextBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox10.Name = "guna2TextBox10";
            this.guna2TextBox10.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox10.TabIndex = 150;
            this.guna2TextBox10.Text = null;
            // 
            // guna2Button8
            // 
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button8.Image")));
            this.guna2Button8.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button8.Location = new System.Drawing.Point(806, 403);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.Size = new System.Drawing.Size(72, 88);
            this.guna2Button8.TabIndex = 149;
            // 
            // guna2Button4
            // 
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button4.Image")));
            this.guna2Button4.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button4.Location = new System.Drawing.Point(123, 409);
            this.guna2Button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.Size = new System.Drawing.Size(105, 89);
            this.guna2Button4.TabIndex = 148;
            // 
            // guna2TileButton5
            // 
            this.guna2TileButton5.BorderRadius = 30;
            this.guna2TileButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton5.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton5.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton5.Location = new System.Drawing.Point(99, 362);
            this.guna2TileButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton5.Name = "guna2TileButton5";
            this.guna2TileButton5.Size = new System.Drawing.Size(635, 226);
            this.guna2TileButton5.TabIndex = 147;
            this.guna2TileButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // guna2TileButton4
            // 
            this.guna2TileButton4.BorderRadius = 30;
            this.guna2TileButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton4.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton4.Location = new System.Drawing.Point(764, 362);
            this.guna2TileButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton4.Name = "guna2TileButton4";
            this.guna2TileButton4.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton4.TabIndex = 146;
            // 
            // guna2HtmlLabel45
            // 
            this.guna2HtmlLabel45.AutoSize = false;
            this.guna2HtmlLabel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel45.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel45.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel45.Location = new System.Drawing.Point(466, 210);
            this.guna2HtmlLabel45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel45.Name = "guna2HtmlLabel45";
            this.guna2HtmlLabel45.Size = new System.Drawing.Size(213, 44);
            this.guna2HtmlLabel45.TabIndex = 145;
            this.guna2HtmlLabel45.Text = "Suppliers\r\n";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.AutoSize = false;
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(123, 210);
            this.guna2HtmlLabel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(215, 44);
            this.guna2HtmlLabel3.TabIndex = 144;
            this.guna2HtmlLabel3.Text = "Employees";
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.AutoSize = false;
            this.guna2TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox1.Location = new System.Drawing.Point(610, 148);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox1.TabIndex = 143;
            this.guna2TextBox1.Text = null;
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.AutoSize = false;
            this.guna2TextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TextBox4.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2TextBox4.Location = new System.Drawing.Point(257, 148);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.Size = new System.Drawing.Size(109, 98);
            this.guna2TextBox4.TabIndex = 142;
            this.guna2TextBox4.Text = null;
            // 
            // guna2Button6
            // 
            this.guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button6.Image")));
            this.guna2Button6.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button6.Location = new System.Drawing.Point(784, 121);
            this.guna2Button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.Size = new System.Drawing.Size(87, 89);
            this.guna2Button6.TabIndex = 141;
            // 
            // guna2TileButton3
            // 
            this.guna2TileButton3.BorderRadius = 30;
            this.guna2TileButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton3.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton3.Location = new System.Drawing.Point(766, 83);
            this.guna2TileButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton3.Name = "guna2TileButton3";
            this.guna2TileButton3.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton3.TabIndex = 140;
            // 
            // guna2Button3
            // 
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.guna2Button3.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button3.Image")));
            this.guna2Button3.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button3.Location = new System.Drawing.Point(141, 117);
            this.guna2Button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(71, 89);
            this.guna2Button3.TabIndex = 139;
            this.guna2Button3.UseTransparentBackground = true;
            // 
            // guna2TileButton1
            // 
            this.guna2TileButton1.BorderRadius = 30;
            this.guna2TileButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton1.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton1.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton1.Location = new System.Drawing.Point(101, 83);
            this.guna2TileButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton1.Name = "guna2TileButton1";
            this.guna2TileButton1.Size = new System.Drawing.Size(268, 226);
            this.guna2TileButton1.TabIndex = 138;
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button1.Location = new System.Drawing.Point(455, 121);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(120, 89);
            this.guna2Button1.TabIndex = 137;
            // 
            // guna2TileButton2
            // 
            this.guna2TileButton2.BorderRadius = 30;
            this.guna2TileButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TileButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton2.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton2.ImageSize = new System.Drawing.Size(70, 70);
            this.guna2TileButton2.Location = new System.Drawing.Point(442, 86);
            this.guna2TileButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2TileButton2.Name = "guna2TileButton2";
            this.guna2TileButton2.Size = new System.Drawing.Size(281, 226);
            this.guna2TileButton2.TabIndex = 136;
            // 
            // Payments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(1349, 850);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2CircleButton2);
            this.Controls.Add(this.guna2CircleButton1);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.guna2TabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Payments";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SEC";
            this.Load += new System.EventHandler(this.Payments_Load);
            this.guna2TabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.acctask)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Feetbackdgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton7;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton6;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2DataGridView Feetbackdgv;
        private Guna.UI2.WinForms.Guna2Button accsend;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel47;
        private Guna.UI2.WinForms.Guna2ComboBox cmbFeedbackType;
        private Guna.UI2.WinForms.Guna2TextBox txtFeedback;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel41;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel44;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpName;
        private Guna.UI2.WinForms.Guna2TextBox txtEmpId;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel27;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel24;
        private Guna.UI2.WinForms.Guna2TextBox accDeadline;
        private Guna.UI2.WinForms.Guna2DataGridView acctask;
        private Guna.UI2.WinForms.Guna2TextBox accPriority;
        private Guna.UI2.WinForms.Guna2ComboBox cmbaccStatuss;
        private Guna.UI2.WinForms.Guna2TextBox accTaskNames;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel40;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel38;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel37;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel36;
        private Guna.UI2.WinForms.Guna2Button updbtnacc;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel42;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip1;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip2;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip3;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip4;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip5;
        private Guna.UI2.WinForms.Guna2HtmlToolTip guna2HtmlToolTip6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel48;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel46;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel52;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel49;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox10;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton5;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel45;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2TextBox4;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton3;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton2;
    }
}